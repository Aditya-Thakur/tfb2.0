(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["sidePanel-delivery-policy-delivery-policy-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/sidePanel/delivery-policy/delivery-policy.page.html":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/sidePanel/delivery-policy/delivery-policy.page.html ***!
  \*****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>DeliveryPolicy</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"container myContainer\">\n    <ion-row class=\"header justify-content-center text-center\">\n      <h3>Delivery\n      </h3>\n    </ion-row>\n    <ion-row class=\"content justify-content\">\n    <p>\n      Delivery:<br>\n      You can order 24*7 in website & mobile application. Our delivery timings are between 08:30 AM TO 12:00 AM. Order before 07:30 AM for Same day delivery.<br>\n      Other Delivery Conditions<br>\n      Delivery is not executed during first attempt if in the event that, No one is at home, Wrong Address or insufficient address, Premises Locked, or refusal to accept, Wrong Mobile or Landline Number, no reply, not reachable, Then the customer may be charged for the order. \n     <br> Therefore, refunds, discounts, cancellations and re-delivery would not be applicable in such a case. In case of Natural calamities like Earthquake, / heavy rains / Emergency Strikes / Curfew or any other anti-social event, we reserve the right to reschedule the delivery to the next most probable date.\n  <br>\n   Delivery will be free for total cart value of Rs.300 or more.\n   <br>Below Rs.300 cart value delivery charge will be twenty rupees.\n  \n    </p>\n    </ion-row>\n  </div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/sidePanel/delivery-policy/delivery-policy-routing.module.ts":
/*!***********************************************************************************!*\
  !*** ./src/app/pages/sidePanel/delivery-policy/delivery-policy-routing.module.ts ***!
  \***********************************************************************************/
/*! exports provided: DeliveryPolicyPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DeliveryPolicyPageRoutingModule", function() { return DeliveryPolicyPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _delivery_policy_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./delivery-policy.page */ "./src/app/pages/sidePanel/delivery-policy/delivery-policy.page.ts");




const routes = [
    {
        path: '',
        component: _delivery_policy_page__WEBPACK_IMPORTED_MODULE_3__["DeliveryPolicyPage"]
    }
];
let DeliveryPolicyPageRoutingModule = class DeliveryPolicyPageRoutingModule {
};
DeliveryPolicyPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], DeliveryPolicyPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/sidePanel/delivery-policy/delivery-policy.module.ts":
/*!***************************************************************************!*\
  !*** ./src/app/pages/sidePanel/delivery-policy/delivery-policy.module.ts ***!
  \***************************************************************************/
/*! exports provided: DeliveryPolicyPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DeliveryPolicyPageModule", function() { return DeliveryPolicyPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _delivery_policy_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./delivery-policy-routing.module */ "./src/app/pages/sidePanel/delivery-policy/delivery-policy-routing.module.ts");
/* harmony import */ var _delivery_policy_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./delivery-policy.page */ "./src/app/pages/sidePanel/delivery-policy/delivery-policy.page.ts");







let DeliveryPolicyPageModule = class DeliveryPolicyPageModule {
};
DeliveryPolicyPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _delivery_policy_routing_module__WEBPACK_IMPORTED_MODULE_5__["DeliveryPolicyPageRoutingModule"]
        ],
        declarations: [_delivery_policy_page__WEBPACK_IMPORTED_MODULE_6__["DeliveryPolicyPage"]]
    })
], DeliveryPolicyPageModule);



/***/ }),

/***/ "./src/app/pages/sidePanel/delivery-policy/delivery-policy.page.scss":
/*!***************************************************************************!*\
  !*** ./src/app/pages/sidePanel/delivery-policy/delivery-policy.page.scss ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".myContainer {\n  border: 2px solid black;\n}\n\n.header, .content {\n  margin-top: 10px;\n  margin-right: 10px;\n  margin-left: 10px;\n  margin-bottom: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9hcHBsZS9EZXNrdG9wL1Nob3BwaW5nL3RmYl92Mi4wL3RoZWZseWluZ2Jhc2tldC9zcmMvYXBwL3BhZ2VzL3NpZGVQYW5lbC9kZWxpdmVyeS1wb2xpY3kvZGVsaXZlcnktcG9saWN5LnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGFnZXMvc2lkZVBhbmVsL2RlbGl2ZXJ5LXBvbGljeS9kZWxpdmVyeS1wb2xpY3kucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksdUJBQUE7QUNDSjs7QURFQTtFQUNJLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0FDQ0oiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9zaWRlUGFuZWwvZGVsaXZlcnktcG9saWN5L2RlbGl2ZXJ5LXBvbGljeS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubXlDb250YWluZXIge1xuICAgIGJvcmRlcjogMnB4IHNvbGlkIGJsYWNrO1xufVxuXG4uaGVhZGVyLCAuY29udGVudCB7XG4gICAgbWFyZ2luLXRvcDogMTBweDtcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gICAgbWFyZ2luLWJvdHRvbTogMTBweDtcbn0iLCIubXlDb250YWluZXIge1xuICBib3JkZXI6IDJweCBzb2xpZCBibGFjaztcbn1cblxuLmhlYWRlciwgLmNvbnRlbnQge1xuICBtYXJnaW4tdG9wOiAxMHB4O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/pages/sidePanel/delivery-policy/delivery-policy.page.ts":
/*!*************************************************************************!*\
  !*** ./src/app/pages/sidePanel/delivery-policy/delivery-policy.page.ts ***!
  \*************************************************************************/
/*! exports provided: DeliveryPolicyPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DeliveryPolicyPage", function() { return DeliveryPolicyPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let DeliveryPolicyPage = class DeliveryPolicyPage {
    constructor() { }
    ngOnInit() {
    }
};
DeliveryPolicyPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-delivery-policy',
        template: __webpack_require__(/*! raw-loader!./delivery-policy.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/sidePanel/delivery-policy/delivery-policy.page.html"),
        styles: [__webpack_require__(/*! ./delivery-policy.page.scss */ "./src/app/pages/sidePanel/delivery-policy/delivery-policy.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], DeliveryPolicyPage);



/***/ })

}]);
//# sourceMappingURL=sidePanel-delivery-policy-delivery-policy-module-es2015.js.map