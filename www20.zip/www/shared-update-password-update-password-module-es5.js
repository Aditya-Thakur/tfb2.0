(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["shared-update-password-update-password-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/shared/update-password/update-password.page.html":
/*!**************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/shared/update-password/update-password.page.html ***!
  \**************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>Update Password</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n  <form #form=\"ngForm\" [formGroup]=\"loginForm\">\n    <ion-grid>\n      <ion-row justify-content-center>\n        <ion-col align-self-center size-md=\"6\" size-lg=\"5\" size-xs=\"12\">\n          <div text-center>\n            <h3>Update Password</h3>\n          </div>\n          <div padding>\n            <ion-item>\n              <ion-input formControlName=\"email\" name=\"email\" type=\"email\" placeholder=\"your@email.com\" ngModel required></ion-input>\n            </ion-item>\n            <div\n                 *ngIf=\"loginForm.controls.email.invalid && (loginForm.controls.email.dirty || loginForm.controls.email.touched)\"\n                 class=\"alert alert-danger\">\n                 <div *ngIf=\"loginForm.controls.email.errors.required\">\n                   Email is required.\n                 </div>\n                 <div *ngIf=\"loginForm.controls.email.errors.pattern\">\n                   Email must be valid.\n                 </div>\n                </div>\n                <ion-item>\n                  <ion-button (click)=\"sendOTP()\">Get OTP</ion-button>\n                </ion-item>\n                <ion-item>\n                  <ion-input formControlName=\"otp\" name=\"otp\" type=\"number\" placeholder=\"Enter OTP\" ngModel required></ion-input>\n                </ion-item>\n                <div\n                     *ngIf=\"loginForm.controls.otp.invalid && (loginForm.controls.otp.dirty || loginForm.controls.otp.touched)\"\n                     class=\"alert alert-danger\">\n                     <div *ngIf=\"loginForm.controls.otp.errors.required\">\n                       OTP is required.\n                     </div>\n                     <div *ngIf=\"loginForm.controls.otp.errors.pattern\">\n                       OTP will be 6 digit numeric character.\n                     </div>\n                   </div>\n            <ion-item>\n              <ion-input formControlName=\"password\" name=\"password\" type=\"password\" placeholder=\"Password\" ngModel required></ion-input>\n            </ion-item>\n            <div\n                 *ngIf=\"loginForm.controls.password.invalid && (loginForm.controls.password.dirty || loginForm.controls.password.touched)\"\n                 class=\"alert alert-danger\">\n                 <div *ngIf=\"loginForm.controls.password.errors.required\">\n                   Password is required.\n                 </div>\n                 <div *ngIf=\"loginForm.controls.password.errors.pattern\">\n                   Password should be atleast 6 characters long and of valid characters.\n                 </div>\n               </div>\n          </div>\n          <div padding>\n            <ion-button size=\"large\" type=\"submit\" [disabled]=\"form.invalid\" expand=\"block\" (click)=\"login()\">Update Password</ion-button>\n          </div>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </form>\n  <ion-row>\n    <div text-center>\n  If you don't have an account, please <a (click)=\"openRegister()\" style=\"color: red; text-decoration: underline;\">\n    register</a> first!\n    </div>\n</ion-row>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/shared/update-password/update-password-routing.module.ts":
/*!********************************************************************************!*\
  !*** ./src/app/pages/shared/update-password/update-password-routing.module.ts ***!
  \********************************************************************************/
/*! exports provided: UpdatePasswordPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UpdatePasswordPageRoutingModule", function() { return UpdatePasswordPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _update_password_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./update-password.page */ "./src/app/pages/shared/update-password/update-password.page.ts");




var routes = [
    {
        path: '',
        component: _update_password_page__WEBPACK_IMPORTED_MODULE_3__["UpdatePasswordPage"]
    }
];
var UpdatePasswordPageRoutingModule = /** @class */ (function () {
    function UpdatePasswordPageRoutingModule() {
    }
    UpdatePasswordPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], UpdatePasswordPageRoutingModule);
    return UpdatePasswordPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/pages/shared/update-password/update-password.module.ts":
/*!************************************************************************!*\
  !*** ./src/app/pages/shared/update-password/update-password.module.ts ***!
  \************************************************************************/
/*! exports provided: UpdatePasswordPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UpdatePasswordPageModule", function() { return UpdatePasswordPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _update_password_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./update-password-routing.module */ "./src/app/pages/shared/update-password/update-password-routing.module.ts");
/* harmony import */ var _update_password_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./update-password.page */ "./src/app/pages/shared/update-password/update-password.page.ts");







var UpdatePasswordPageModule = /** @class */ (function () {
    function UpdatePasswordPageModule() {
    }
    UpdatePasswordPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _update_password_routing_module__WEBPACK_IMPORTED_MODULE_5__["UpdatePasswordPageRoutingModule"]
            ],
            declarations: [_update_password_page__WEBPACK_IMPORTED_MODULE_6__["UpdatePasswordPage"]]
        })
    ], UpdatePasswordPageModule);
    return UpdatePasswordPageModule;
}());



/***/ }),

/***/ "./src/app/pages/shared/update-password/update-password.page.scss":
/*!************************************************************************!*\
  !*** ./src/app/pages/shared/update-password/update-password.page.scss ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3NoYXJlZC91cGRhdGUtcGFzc3dvcmQvdXBkYXRlLXBhc3N3b3JkLnBhZ2Uuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/shared/update-password/update-password.page.ts":
/*!**********************************************************************!*\
  !*** ./src/app/pages/shared/update-password/update-password.page.ts ***!
  \**********************************************************************/
/*! exports provided: UpdatePasswordPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UpdatePasswordPage", function() { return UpdatePasswordPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_native_google_plus_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/google-plus/ngx */ "./node_modules/@ionic-native/google-plus/ngx/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var src_app_services_login_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/login.service */ "./src/app/services/login.service.ts");
/* harmony import */ var src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");








var UpdatePasswordPage = /** @class */ (function () {
    function UpdatePasswordPage(router, googlePlus, toastController, loginService, storage
    // private fb: Facebook
    ) {
        this.router = router;
        this.googlePlus = googlePlus;
        this.toastController = toastController;
        this.loginService = loginService;
        this.storage = storage;
        this.loginForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormGroup"]({
            email: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [
                _angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required,
                _angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].pattern('[a-z0-9._]+@[a-z]+.com|.co.in')
            ]),
            otp: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [
                _angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required,
                _angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].pattern('[0-9]{6}')
            ]),
            password: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [
                _angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required,
                _angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].pattern('[A-Za-z0-9!@#$%^&*()-=_+]{6,20}')
            ])
        });
    }
    UpdatePasswordPage.prototype.presentToast = function (toastMessage) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var toast;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastController.create({
                            message: toastMessage,
                            duration: 2000
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    UpdatePasswordPage.prototype.sendOTP = function () {
        var _this = this;
        this.loginService.sendOTP(this.loginForm.value).subscribe(function (res) {
            // tslint:disable: no-string-literal
            if (res['message'] != null) {
                _this.presentToast(res['message']);
            }
        }, function (err) {
            _this.error = err;
        });
    };
    UpdatePasswordPage.prototype.login = function () {
        var _this = this;
        this.loginService.updatePassword(this.loginForm.value).subscribe(function (res) {
            if (res.resCode === 356475) {
                _this.presentToast(res['message']);
                _this.router.navigateByUrl("/tabs/login");
            }
            else {
                // tslint:disable-next-line: no-string-literal
                _this.presentToast(res['message']);
            }
        }, function (err) {
            _this.error = err;
        });
    };
    UpdatePasswordPage.prototype.googleLogin = function () {
        this.googlePlus.login({})
            .then(function (res) { return console.log(res); })
            .catch(function (err) { return console.error(err); });
    };
    UpdatePasswordPage.prototype.ngOnInit = function () {
    };
    UpdatePasswordPage.prototype.openRegister = function () {
        this.router.navigateByUrl("/tabs/register");
    };
    UpdatePasswordPage.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: _ionic_native_google_plus_ngx__WEBPACK_IMPORTED_MODULE_3__["GooglePlus"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"] },
        { type: src_app_services_login_service__WEBPACK_IMPORTED_MODULE_5__["LoginService"] },
        { type: src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_6__["StorageService"] }
    ]; };
    UpdatePasswordPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-update-password',
            template: __webpack_require__(/*! raw-loader!./update-password.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/shared/update-password/update-password.page.html"),
            styles: [__webpack_require__(/*! ./update-password.page.scss */ "./src/app/pages/shared/update-password/update-password.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _ionic_native_google_plus_ngx__WEBPACK_IMPORTED_MODULE_3__["GooglePlus"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"],
            src_app_services_login_service__WEBPACK_IMPORTED_MODULE_5__["LoginService"],
            src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_6__["StorageService"]
            // private fb: Facebook
        ])
    ], UpdatePasswordPage);
    return UpdatePasswordPage;
}());



/***/ })

}]);
//# sourceMappingURL=shared-update-password-update-password-module-es5.js.map