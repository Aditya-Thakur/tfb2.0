(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["sidePanel-my-profile-my-profile-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/sidePanel/my-profile/my-profile.page.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/sidePanel/my-profile/my-profile.page.html ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>MyProfile</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div *ngIf=\"globalVariable.loggedIn\">\n    <ion-text>Checkout your orders here..<a (click)=\"myOrders()\">My Orders</a> </ion-text>\n    <form (ngSubmit)=\"logForm()\">\n      <ion-list>\n  \n        <ion-item>\n          <ion-label floating>Name: </ion-label>\n          <ion-input type=\"text\" value=\"\" name=\"name\" [(ngModel)]=\"globalVariable.loggedInUser.name\"></ion-input>\n        </ion-item>\n\n        <ion-item>\n          <ion-label floating>Contact No: </ion-label>\n          <ion-input type=\"text\" value=\"\" name=\"contactno\" [(ngModel)]=\"globalVariable.loggedInUser.contactno\"></ion-input>\n        </ion-item>\n\n        <ion-item>\n          <ion-label floating>Email: </ion-label>\n          <ion-input type=\"text\" value=\"\" name=\"email\" [(ngModel)]=\"globalVariable.loggedInUser.email\"></ion-input>\n        </ion-item>\n  \n        <ion-item>\n          <ion-label floating>Shipping Address: </ion-label>\n          <ion-input name=\"shippingAddress\" type=\"text\"\n            [(ngModel)]=\"globalVariable.loggedInUser.shippingAddress\"></ion-input>\n        </ion-item>\n  \n        <ion-item>\n          <ion-label floating>Landmark: </ion-label>\n          <ion-input type=\"text\" name=\"landMark\" [(ngModel)]=\"globalVariable.loggedInUser.landMark\">\n          </ion-input>\n        </ion-item>\n  \n        <ion-item>\n          <ion-label floating>City: </ion-label>\n          <ion-input type=\"text\" name=\"shippingCity\" [(ngModel)]=\"globalVariable.loggedInUser.shippingCity\">\n          </ion-input>\n        </ion-item>\n  \n        <ion-item>\n          <ion-label floating>State: </ion-label>\n          <ion-input type=\"text\" name=\"shippingState\" [(ngModel)]=\"globalVariable.loggedInUser.shippingState\">\n          </ion-input>\n        </ion-item>\n  \n        <ion-item>\n          <ion-label floating>Pincode: </ion-label>\n          <ion-input type=\"number\" name=\"shippingPincode\"\n            [(ngModel)]=\"globalVariable.loggedInUser.shippingPincode\"></ion-input>\n        </ion-item>\n        <ion-item-divider slot=\"end\">\n          <ion-button shape=\"round\" type=\"submit\" color=\"success\">Update Details</ion-button>\n        </ion-item-divider>\n      </ion-list>\n    </form>\n  </div>\n  <ion-card *ngIf=\"globalVariable.loggedInUser.id == 0\" class=\"container justify-content-center text-center\">\n    <ion-item>\n      <ion-img src=\"../../assets/images/please-login.png\" (click)=\"openLogin()\" routerLinkActive=\"active\"\n      class=\"productImage\"></ion-img>\n    </ion-item>\n    <ion-item><p>\n      Please login before viewing this page!\n    </p></ion-item>\n    <ion-item>\n      <ion-button class=\"btn btn-primary\" (click)=\"openLogin()\" routerLinkActive=\"active\">Login/Signup</ion-button>\n    </ion-item>\n  </ion-card>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/sidePanel/my-profile/my-profile-routing.module.ts":
/*!*************************************************************************!*\
  !*** ./src/app/pages/sidePanel/my-profile/my-profile-routing.module.ts ***!
  \*************************************************************************/
/*! exports provided: MyProfilePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyProfilePageRoutingModule", function() { return MyProfilePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _my_profile_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./my-profile.page */ "./src/app/pages/sidePanel/my-profile/my-profile.page.ts");




const routes = [
    {
        path: '',
        component: _my_profile_page__WEBPACK_IMPORTED_MODULE_3__["MyProfilePage"]
    }
];
let MyProfilePageRoutingModule = class MyProfilePageRoutingModule {
};
MyProfilePageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], MyProfilePageRoutingModule);



/***/ }),

/***/ "./src/app/pages/sidePanel/my-profile/my-profile.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/pages/sidePanel/my-profile/my-profile.module.ts ***!
  \*****************************************************************/
/*! exports provided: MyProfilePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyProfilePageModule", function() { return MyProfilePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _my_profile_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./my-profile-routing.module */ "./src/app/pages/sidePanel/my-profile/my-profile-routing.module.ts");
/* harmony import */ var _my_profile_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./my-profile.page */ "./src/app/pages/sidePanel/my-profile/my-profile.page.ts");







let MyProfilePageModule = class MyProfilePageModule {
};
MyProfilePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _my_profile_routing_module__WEBPACK_IMPORTED_MODULE_5__["MyProfilePageRoutingModule"]
        ],
        declarations: [_my_profile_page__WEBPACK_IMPORTED_MODULE_6__["MyProfilePage"]]
    })
], MyProfilePageModule);



/***/ }),

/***/ "./src/app/pages/sidePanel/my-profile/my-profile.page.scss":
/*!*****************************************************************!*\
  !*** ./src/app/pages/sidePanel/my-profile/my-profile.page.scss ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3NpZGVQYW5lbC9teS1wcm9maWxlL215LXByb2ZpbGUucGFnZS5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/pages/sidePanel/my-profile/my-profile.page.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/sidePanel/my-profile/my-profile.page.ts ***!
  \***************************************************************/
/*! exports provided: MyProfilePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyProfilePage", function() { return MyProfilePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var src_app_global__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/global */ "./src/app/global.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");





let MyProfilePage = class MyProfilePage {
    constructor(router, toastController) {
        this.router = router;
        this.toastController = toastController;
        this.globalVariable = src_app_global__WEBPACK_IMPORTED_MODULE_3__["Global"];
    }
    ngOnInit() {
        if (this.globalVariable.loggedIn) {
            console.log('bla bla in my-profile');
        }
        else {
            this.presentToast('Please login first to view your profile.');
            this.router.navigateByUrl(`/tabs/login`);
        }
    }
    presentToast(toastMessage) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: toastMessage,
                duration: 2000
            });
            toast.present();
        });
    }
    openLogin() {
        this.router.navigateByUrl(`/tabs/login`);
    }
    myOrders() {
        this.router.navigateByUrl(`/tabs/myOrders`);
    }
};
MyProfilePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"] }
];
MyProfilePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-my-profile',
        template: __webpack_require__(/*! raw-loader!./my-profile.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/sidePanel/my-profile/my-profile.page.html"),
        styles: [__webpack_require__(/*! ./my-profile.page.scss */ "./src/app/pages/sidePanel/my-profile/my-profile.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"]])
], MyProfilePage);



/***/ })

}]);
//# sourceMappingURL=sidePanel-my-profile-my-profile-module-es2015.js.map