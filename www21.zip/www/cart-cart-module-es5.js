(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["cart-cart-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/components/product-card-order-item/product-card-order-item.component.html":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/product-card-order-item/product-card-order-item.component.html ***!
  \*********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-card>\n  <ion-item>\n    <ion-grid>\n      <ion-row>\n        <ion-col>\n          <!-- <ion-badge *ngIf=\"(cartItem.product.productPriceBeforeDiscount - cartItem.product.productPrice) >= 0\" color=\"danger\">{{cartItem.product.productPriceBeforeDiscount | discount:cartItem.product.productPrice}}</ion-badge> -->\n          <ion-img width=\"80\" height=\"80\"\n            src=\"https://theflyingbasket.com/assets/productimages/{{cartItem.product.id}}/{{cartItem.product.productImage1}}\"\n            (click)=\"showDetails(cartItem.product.id)\"></ion-img>\n        </ion-col>\n        <ion-col>\n          <ion-grid>\n              <ion-row\n                *ngIf=\"cartItem.productVariety.id == 0  && cartItem.product.productPriceBeforeDiscount!=cartItem.product.productPrice\"\n                class=\"ion-text-center\">\n                <span class=\"productPrice\" style=\"text-decoration: line-through;\">Rs.\n                  {{cartItem.product.productPriceBeforeDiscount}}/-</span>\n              </ion-row>\n              <ion-row *ngIf=\"cartItem.productVariety.id != 0; else priceActual\">\n                {{cartItem.productVariety.productQuantity}} {{cartItem.productVariety.quantityType}} - Rs.&nbsp;\n                {{cartItem.productVariety.productPrice}}\n              </ion-row>\n              <ng-template #priceActual>\n                <ion-row class=\"ion-text-center\">\n                  Rs. {{cartItem.product.productPrice}}/-\n                </ion-row>\n              </ng-template>\n            <!-- <ion-row *ngIf=\"cartItem.quantity == 1; else inCart\">\n              <ion-button color=\"danger\" (click)=\"removeFromBasket()\">Remove from &nbsp;<ion-icon name=\"basket\">\n                </ion-icon>\n              </ion-button>\n            </ion-row> -->\n              <ion-row>\n                <ion-button (click)=\"changeQuantity(-1)\" color=\"warning\">\n                  <ion-text color=\"dark\">-</ion-text>\n                </ion-button>\n                <ion-text>\n                  {{cartItem.quantity}} in &nbsp;\n                  <ion-icon name=\"basket\"></ion-icon>\n                </ion-text>\n                <ion-button (click)=\"changeQuantity(1)\" color=\"secondary\">\n                  <ion-text color=\"dark\">+</ion-text>\n                </ion-button>\n              </ion-row>\n          </ion-grid>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-item>\n\n  <ion-card-content (click)=\"showDetails(product.id)\">\n    {{cartItem.product.productName}}\n  </ion-card-content>\n</ion-card>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/cart/cart.page.html":
/*!*********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/cart/cart.page.html ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>cart</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-header>\n      <ion-button expand=\"full\" color=\"secondary\">Cart Items</ion-button>\n  </ion-header>\n\n  <ion-grid>\n    <ion-row *ngFor=\"let cartItem of globalVariable.myCart.myCartItems\">\n        <app-product-card-order-item [cartItem]=\"cartItem\">\n          </app-product-card-order-item>\n    </ion-row>\n  </ion-grid>\n\n</ion-content>\n\n<ion-footer>\n  <ion-toolbar>\n    <ion-grid>\n      <ion-row>\n      <ion-col>\n        <ion-row>Total Cart Price: Rs: {{globalVariable.myCart.getTotalCartPriceWithoutShippingCharge()}}</ion-row>\n        <ion-row>Shipping Charge: \n          <span *ngIf=\"globalVariable.myCart.getTotalCartPriceWithoutShippingCharge() < 300; else shippingFree\">Rs. 20</span>\n          <span *ngIf=\"globalVariable.myCart.getTotalCartPriceWithoutShippingCharge() < 300\" style=\"font-size: xx-small; color: orangered\">Rs 20 delivery charge for cart value less than Rs. 300</span>\n          <ng-template #shippingFree>\n            <span style=\"color: green\">\n              Free\n            </span>\n          </ng-template>\n        </ion-row>\n        <ion-row style=\"color: green\">You saved : Rs: {{globalVariable.myCart.getTotalDiscountPrice()}}</ion-row>\n        <ion-row>Total Amount Payable : Rs: {{globalVariable.myCart.getTotalCartPrice()}}</ion-row>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col size=6>\n        <ion-button size=\"small\" (click)=\"clearCart()\">Clear Cart</ion-button>\n      </ion-col>\n      <ion-col size=6>\n        <ion-button size=\"medium\" (click)=\"checkout()\">CheckOut</ion-button>\n      </ion-col>\n    </ion-row>\n    </ion-grid>\n  </ion-toolbar>\n</ion-footer>\n"

/***/ }),

/***/ "./src/app/components/product-card-order-item/product-card-order-item.component.scss":
/*!*******************************************************************************************!*\
  !*** ./src/app/components/product-card-order-item/product-card-order-item.component.scss ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvcHJvZHVjdC1jYXJkLW9yZGVyLWl0ZW0vcHJvZHVjdC1jYXJkLW9yZGVyLWl0ZW0uY29tcG9uZW50LnNjc3MifQ== */"

/***/ }),

/***/ "./src/app/components/product-card-order-item/product-card-order-item.component.ts":
/*!*****************************************************************************************!*\
  !*** ./src/app/components/product-card-order-item/product-card-order-item.component.ts ***!
  \*****************************************************************************************/
/*! exports provided: ProductCardOrderItemComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductCardOrderItemComponent", function() { return ProductCardOrderItemComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_global__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/global */ "./src/app/global.ts");
/* harmony import */ var src_app_services_cart_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/cart.service */ "./src/app/services/cart.service.ts");




var ProductCardOrderItemComponent = /** @class */ (function () {
    function ProductCardOrderItemComponent(cart) {
        this.cart = cart;
        this.globalVariable = src_app_global__WEBPACK_IMPORTED_MODULE_2__["Global"];
    }
    ProductCardOrderItemComponent.prototype.ngOnInit = function () { };
    ProductCardOrderItemComponent.prototype.removeFromBasket = function () {
    };
    ProductCardOrderItemComponent.prototype.changeQuantity = function (change) {
        this.cart.changeQuantity(this.cartItem.product.id, this.cartItem.productVariety.id, change);
    };
    ProductCardOrderItemComponent.ctorParameters = function () { return [
        { type: src_app_services_cart_service__WEBPACK_IMPORTED_MODULE_3__["CartService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('cartItem'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], ProductCardOrderItemComponent.prototype, "cartItem", void 0);
    ProductCardOrderItemComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-product-card-order-item',
            template: __webpack_require__(/*! raw-loader!./product-card-order-item.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/product-card-order-item/product-card-order-item.component.html"),
            styles: [__webpack_require__(/*! ./product-card-order-item.component.scss */ "./src/app/components/product-card-order-item/product-card-order-item.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_cart_service__WEBPACK_IMPORTED_MODULE_3__["CartService"]])
    ], ProductCardOrderItemComponent);
    return ProductCardOrderItemComponent;
}());



/***/ }),

/***/ "./src/app/components/product-card-order-item/product-card-order-item.module.ts":
/*!**************************************************************************************!*\
  !*** ./src/app/components/product-card-order-item/product-card-order-item.module.ts ***!
  \**************************************************************************************/
/*! exports provided: ProductCardOrderItemModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductCardOrderItemModule", function() { return ProductCardOrderItemModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _material_material_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../material/material.module */ "./src/app/material/material.module.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");





var ProductCardOrderItemModule = /** @class */ (function () {
    function ProductCardOrderItemModule() {
    }
    ProductCardOrderItemModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _material_material_module__WEBPACK_IMPORTED_MODULE_3__["MaterialModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ReactiveFormsModule"]
            ],
            exports: [
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ReactiveFormsModule"],
                _material_material_module__WEBPACK_IMPORTED_MODULE_3__["MaterialModule"]
            ]
        })
    ], ProductCardOrderItemModule);
    return ProductCardOrderItemModule;
}());



/***/ }),

/***/ "./src/app/pages/cart/cart-routing.module.ts":
/*!***************************************************!*\
  !*** ./src/app/pages/cart/cart-routing.module.ts ***!
  \***************************************************/
/*! exports provided: CartPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CartPageRoutingModule", function() { return CartPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _cart_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./cart.page */ "./src/app/pages/cart/cart.page.ts");




var routes = [
    {
        path: '',
        component: _cart_page__WEBPACK_IMPORTED_MODULE_3__["CartPage"]
    }
];
var CartPageRoutingModule = /** @class */ (function () {
    function CartPageRoutingModule() {
    }
    CartPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], CartPageRoutingModule);
    return CartPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/pages/cart/cart.module.ts":
/*!*******************************************!*\
  !*** ./src/app/pages/cart/cart.module.ts ***!
  \*******************************************/
/*! exports provided: CartPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CartPageModule", function() { return CartPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _cart_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./cart-routing.module */ "./src/app/pages/cart/cart-routing.module.ts");
/* harmony import */ var _cart_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./cart.page */ "./src/app/pages/cart/cart.page.ts");
/* harmony import */ var _products_products_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../products/products.module */ "./src/app/pages/products/products.module.ts");
/* harmony import */ var _components_product_card_order_item_product_card_order_item_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../components/product-card-order-item/product-card-order-item.component */ "./src/app/components/product-card-order-item/product-card-order-item.component.ts");
/* harmony import */ var src_app_components_product_card_order_item_product_card_order_item_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/components/product-card-order-item/product-card-order-item.module */ "./src/app/components/product-card-order-item/product-card-order-item.module.ts");










var CartPageModule = /** @class */ (function () {
    function CartPageModule() {
    }
    CartPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _cart_routing_module__WEBPACK_IMPORTED_MODULE_5__["CartPageRoutingModule"],
                _products_products_module__WEBPACK_IMPORTED_MODULE_7__["ProductsPageModule"],
                src_app_components_product_card_order_item_product_card_order_item_module__WEBPACK_IMPORTED_MODULE_9__["ProductCardOrderItemModule"]
            ],
            declarations: [_cart_page__WEBPACK_IMPORTED_MODULE_6__["CartPage"], _components_product_card_order_item_product_card_order_item_component__WEBPACK_IMPORTED_MODULE_8__["ProductCardOrderItemComponent"]],
            exports: [_products_products_module__WEBPACK_IMPORTED_MODULE_7__["ProductsPageModule"]]
        })
    ], CartPageModule);
    return CartPageModule;
}());



/***/ }),

/***/ "./src/app/pages/cart/cart.page.scss":
/*!*******************************************!*\
  !*** ./src/app/pages/cart/cart.page.scss ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2NhcnQvY2FydC5wYWdlLnNjc3MifQ== */"

/***/ }),

/***/ "./src/app/pages/cart/cart.page.ts":
/*!*****************************************!*\
  !*** ./src/app/pages/cart/cart.page.ts ***!
  \*****************************************/
/*! exports provided: CartPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CartPage", function() { return CartPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_cart_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/cart.service */ "./src/app/services/cart.service.ts");
/* harmony import */ var src_app_global__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/global */ "./src/app/global.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");






var CartPage = /** @class */ (function () {
    function CartPage(cartService, toastController, router) {
        this.cartService = cartService;
        this.toastController = toastController;
        this.router = router;
        this.globalVariable = src_app_global__WEBPACK_IMPORTED_MODULE_3__["Global"];
        this.shippingCharge = false;
    }
    CartPage.prototype.ngOnInit = function () {
        if (this.globalVariable.myCart.getTotalCartPrice() === 0) {
            this.presentToast('Let\'s add few item to cart first (-.-)');
            this.router.navigate(['']);
        }
    };
    CartPage.prototype.presentToast = function (toastMessage) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var toast;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastController.create({
                            message: toastMessage,
                            duration: 2000
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    CartPage.prototype.checkout = function () {
        if (this.globalVariable.loggedIn) {
            this.router.navigateByUrl("/tabs/checkout");
        }
        else {
            this.presentToast('Please login before checking out');
            this.router.navigateByUrl("/tabs/login");
        }
    };
    CartPage.prototype.clearCart = function () {
        this.cartService.clearCart();
    };
    CartPage.ctorParameters = function () { return [
        { type: src_app_services_cart_service__WEBPACK_IMPORTED_MODULE_2__["CartService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] }
    ]; };
    CartPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-cart',
            template: __webpack_require__(/*! raw-loader!./cart.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/cart/cart.page.html"),
            styles: [__webpack_require__(/*! ./cart.page.scss */ "./src/app/pages/cart/cart.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_cart_service__WEBPACK_IMPORTED_MODULE_2__["CartService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]])
    ], CartPage);
    return CartPage;
}());



/***/ })

}]);
//# sourceMappingURL=cart-cart-module-es5.js.map