(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~cart-cart-module~product-details-product-details-module~products-products-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/components/product-card/product-card.component.html":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/product-card/product-card.component.html ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-card>\n  <ion-item>\n    <ion-grid>\n      <ion-row>\n        <ion-col>\n          <ion-badge *ngIf=\"(product.productPriceBeforeDiscount - product.productPrice) >= 0\" color=\"danger\">{{product.productPriceBeforeDiscount | discount:product.productPrice}}</ion-badge>\n          <ion-img width=\"80\" height=\"80\"\n            src=\"https://theflyingbasket.com/assets/productimages/{{product.id}}/{{product.productImage1}}\"\n            (click)=\"showDetails(product.id)\"></ion-img>\n        </ion-col>\n        <ion-col>\n          <ion-grid>\n            <ion-row>\n            </ion-row>\n            <ion-row *ngIf=\"productVarieties.length == 0  && product.productPriceBeforeDiscount!=product.productPrice\" class=\"ion-text-center\">\n              <span class=\"productPrice\" style=\"text-decoration: line-through;\">Rs.\n                {{product.productPriceBeforeDiscount}}/-</span>\n            </ion-row>\n            <ion-row *ngIf=\"productVarieties.length != 0; else priceActual\">\n              <form (ngSubmit)=\"quantityForm()\">\n                <ion-select class=\"custom-select\" style=\"width:200px;\" name=\"choosedProductVariety\" [(ngModel)]=\"choosedProductVariety\" okText=\"Okay\" cancelText=\"Cancel\" placeholder=\"change\">\n                  <ion-select-option *ngFor=\"let productVariety of productVarieties;\"  value=\"{{productVariety.id}}\" [selected]=\"productVariety.id == productVarieties[0].id\">\n                    {{productVariety.productQuantity}} {{productVariety.quantityType}} - Rs. {{productVariety.productPrice}}/-\n                  </ion-select-option>\n                </ion-select>\n              </form>\n            <ion-text>\n              {{quantityDict.get(choosedProductVariety).productQuantity}} {{quantityDict.get(choosedProductVariety).quantityType}} - Rs. {{quantityDict.get(choosedProductVariety).productPrice}}/-\n            </ion-text>\n            </ion-row>\n            <ng-template #priceActual>\n              <ion-row class=\"ion-text-center\">\n                Rs. {{product.productPrice}}/-\n              </ion-row>\n            </ng-template>\n            <!-- <ion-row *ngIf=\"globalVariable.myCart.getQuantity(product, quantityDict.get(choosedProductVariety)) == 0; else inCart\">\n              <ion-button (click)=\"addToBasket()\">Add to basket <ion-icon name=\"basket\"></ion-icon>\n              </ion-button>\n            </ion-row> -->\n            <ion-row *ngIf=\"globalVariable.myCart.getQuantity(product, quantityDict.get(choosedProductVariety)) == 0; else inCart\">\n              <ion-button color=\"primary\" *ngIf=\"product.productAvailability === 'In Stock'\" (click)=\"addToBasket()\">\n                \n                  Add to basket <ion-icon name=\"basket\"></ion-icon>\n            \n              </ion-button>\n              <ion-button color=\"medium\" *ngIf=\"product.productAvailability === 'Out of Stock'\" (click)=\"outOfStock()\">\n                \n                Out of Stock\n          \n            </ion-button>\n            </ion-row>\n\n            <ng-template #inCart>\n              <ion-row>\n                <ion-button (click)=\"changeQuantity(-1)\" color=\"warning\"><ion-text color=\"dark\">-</ion-text></ion-button>\n                <ion-text>{{globalVariable.myCart.getQuantity(product,quantityDict.get(choosedProductVariety))}} in &nbsp;<ion-icon name=\"basket\"></ion-icon></ion-text>\n                <ion-button (click)=\"changeQuantity(1)\" color=\"secondary\"><ion-text color=\"dark\">+</ion-text></ion-button>\n              </ion-row>\n            </ng-template>\n          </ion-grid>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-item>\n\n  <ion-card-content (click)=\"showDetails(product.id)\">\n    {{product.productName}}\n  </ion-card-content>\n</ion-card>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/products/products.page.html":
/*!*****************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/products/products.page.html ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>products</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <ion-grid>\n      <ion-row>\n        <ion-img width=\"80\" height=\"80\"\n            src=\"{{imgsrc}}\" alt=\"{{altText}}\"></ion-img>\n      </ion-row>\n        <ion-row *ngFor=\"let product of products;let i = index\">\n          <ion-item *ngIf=\"i !=0 && products[i].subCategory!=products[i-1].subCategory\">\n            <ion-img width=\"80\" height=\"80\"\n            src=\"../assets/subpic/{{products[i].subCategory}}.png\"></ion-img>\n          </ion-item>\n            <app-product-card [product]=\"product\">\n              </app-product-card>\n        </ion-row>\n      </ion-grid>\n\n      <p class=\"ion-padding-start ion-padding-end\"><ion-item (click)=\"scrollToTop()\" expand=\"block\" fill=\"outline\">That's all for now!</ion-item></p>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/components/product-card/product-card.component.scss":
/*!*********************************************************************!*\
  !*** ./src/app/components/product-card/product-card.component.scss ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".productImage {\n  cursor: pointer;\n  -o-object-fit: contain;\n     object-fit: contain;\n  max-width: 100%;\n  height: 50px;\n}\n\n.custom-select {\n  position: relative;\n  font-family: Arial;\n}\n\n.custom-select select {\n  display: none;\n  /*hide original SELECT element:*/\n}\n\n.select-selected {\n  background-color: DodgerBlue;\n}\n\n/*style the arrow inside the select element:*/\n\n.select-selected:after {\n  position: absolute;\n  content: \"\";\n  top: 14px;\n  right: 10px;\n  width: 0;\n  height: 0;\n  border: 6px solid transparent;\n  border-color: #fff transparent transparent transparent;\n}\n\n/*point the arrow upwards when the select box is open (active):*/\n\n.select-selected.select-arrow-active:after {\n  border-color: transparent transparent #fff transparent;\n  top: 7px;\n}\n\n/*style the items (options), including the selected item:*/\n\n.select-items div, .select-selected {\n  color: #ffffff;\n  padding: 8px 16px;\n  border: 1px solid transparent;\n  border-color: transparent transparent rgba(0, 0, 0, 0.1) transparent;\n  cursor: pointer;\n  -webkit-user-select: none;\n     -moz-user-select: none;\n      -ms-user-select: none;\n          user-select: none;\n}\n\n/*style items (options):*/\n\n.select-items {\n  position: absolute;\n  background-color: DodgerBlue;\n  top: 100%;\n  left: 0;\n  right: 0;\n  z-index: 99;\n}\n\n/*hide the items when the select box is closed:*/\n\n.select-hide {\n  display: none;\n}\n\n.select-items div:hover, .same-as-selected {\n  background-color: rgba(0, 0, 0, 0.1);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9hcHBsZS9EZXNrdG9wL1Nob3BwaW5nL3RmYl92Mi4wL3RoZWZseWluZ2Jhc2tldC9zcmMvYXBwL2NvbXBvbmVudHMvcHJvZHVjdC1jYXJkL3Byb2R1Y3QtY2FyZC5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvY29tcG9uZW50cy9wcm9kdWN0LWNhcmQvcHJvZHVjdC1jYXJkLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZUFBQTtFQUNGLHNCQUFBO0tBQUEsbUJBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtBQ0NGOztBREVBO0VBQ0Usa0JBQUE7RUFDQSxrQkFBQTtBQ0NGOztBREVBO0VBQ0UsYUFBQTtFQUFlLGdDQUFBO0FDRWpCOztBRENBO0VBQ0UsNEJBQUE7QUNFRjs7QURDQSw2Q0FBQTs7QUFDQTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7RUFDQSxXQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSw2QkFBQTtFQUNBLHNEQUFBO0FDRUY7O0FEQ0EsZ0VBQUE7O0FBQ0E7RUFDRSxzREFBQTtFQUNBLFFBQUE7QUNFRjs7QURDQSwwREFBQTs7QUFDQTtFQUNFLGNBQUE7RUFDQSxpQkFBQTtFQUNBLDZCQUFBO0VBQ0Esb0VBQUE7RUFDQSxlQUFBO0VBQ0EseUJBQUE7S0FBQSxzQkFBQTtNQUFBLHFCQUFBO1VBQUEsaUJBQUE7QUNFRjs7QURDQSx5QkFBQTs7QUFDQTtFQUNFLGtCQUFBO0VBQ0EsNEJBQUE7RUFDQSxTQUFBO0VBQ0EsT0FBQTtFQUNBLFFBQUE7RUFDQSxXQUFBO0FDRUY7O0FEQ0EsZ0RBQUE7O0FBQ0E7RUFDRSxhQUFBO0FDRUY7O0FEQ0E7RUFDRSxvQ0FBQTtBQ0VGIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50cy9wcm9kdWN0LWNhcmQvcHJvZHVjdC1jYXJkLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnByb2R1Y3RJbWFnZSB7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICBvYmplY3QtZml0OiBjb250YWluO1xuICBtYXgtd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogNTBweDtcbn1cblxuLmN1c3RvbS1zZWxlY3Qge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGZvbnQtZmFtaWx5OiBBcmlhbDtcbn1cblxuLmN1c3RvbS1zZWxlY3Qgc2VsZWN0IHtcbiAgZGlzcGxheTogbm9uZTsgLypoaWRlIG9yaWdpbmFsIFNFTEVDVCBlbGVtZW50OiovXG59XG5cbi5zZWxlY3Qtc2VsZWN0ZWQge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBEb2RnZXJCbHVlO1xufVxuXG4vKnN0eWxlIHRoZSBhcnJvdyBpbnNpZGUgdGhlIHNlbGVjdCBlbGVtZW50OiovXG4uc2VsZWN0LXNlbGVjdGVkOmFmdGVyIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBjb250ZW50OiBcIlwiO1xuICB0b3A6IDE0cHg7XG4gIHJpZ2h0OiAxMHB4O1xuICB3aWR0aDogMDtcbiAgaGVpZ2h0OiAwO1xuICBib3JkZXI6IDZweCBzb2xpZCB0cmFuc3BhcmVudDtcbiAgYm9yZGVyLWNvbG9yOiAjZmZmIHRyYW5zcGFyZW50IHRyYW5zcGFyZW50IHRyYW5zcGFyZW50O1xufVxuXG4vKnBvaW50IHRoZSBhcnJvdyB1cHdhcmRzIHdoZW4gdGhlIHNlbGVjdCBib3ggaXMgb3BlbiAoYWN0aXZlKToqL1xuLnNlbGVjdC1zZWxlY3RlZC5zZWxlY3QtYXJyb3ctYWN0aXZlOmFmdGVyIHtcbiAgYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudCB0cmFuc3BhcmVudCAjZmZmIHRyYW5zcGFyZW50O1xuICB0b3A6IDdweDtcbn1cblxuLypzdHlsZSB0aGUgaXRlbXMgKG9wdGlvbnMpLCBpbmNsdWRpbmcgdGhlIHNlbGVjdGVkIGl0ZW06Ki9cbi5zZWxlY3QtaXRlbXMgZGl2LC5zZWxlY3Qtc2VsZWN0ZWQge1xuICBjb2xvcjogI2ZmZmZmZjtcbiAgcGFkZGluZzogOHB4IDE2cHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkIHRyYW5zcGFyZW50O1xuICBib3JkZXItY29sb3I6IHRyYW5zcGFyZW50IHRyYW5zcGFyZW50IHJnYmEoMCwgMCwgMCwgMC4xKSB0cmFuc3BhcmVudDtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICB1c2VyLXNlbGVjdDogbm9uZTtcbn1cblxuLypzdHlsZSBpdGVtcyAob3B0aW9ucyk6Ki9cbi5zZWxlY3QtaXRlbXMge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGJhY2tncm91bmQtY29sb3I6IERvZGdlckJsdWU7XG4gIHRvcDogMTAwJTtcbiAgbGVmdDogMDtcbiAgcmlnaHQ6IDA7XG4gIHotaW5kZXg6IDk5O1xufVxuXG4vKmhpZGUgdGhlIGl0ZW1zIHdoZW4gdGhlIHNlbGVjdCBib3ggaXMgY2xvc2VkOiovXG4uc2VsZWN0LWhpZGUge1xuICBkaXNwbGF5OiBub25lO1xufVxuXG4uc2VsZWN0LWl0ZW1zIGRpdjpob3ZlciwgLnNhbWUtYXMtc2VsZWN0ZWQge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuMSk7XG59IiwiLnByb2R1Y3RJbWFnZSB7XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgb2JqZWN0LWZpdDogY29udGFpbjtcbiAgbWF4LXdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDUwcHg7XG59XG5cbi5jdXN0b20tc2VsZWN0IHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBmb250LWZhbWlseTogQXJpYWw7XG59XG5cbi5jdXN0b20tc2VsZWN0IHNlbGVjdCB7XG4gIGRpc3BsYXk6IG5vbmU7XG4gIC8qaGlkZSBvcmlnaW5hbCBTRUxFQ1QgZWxlbWVudDoqL1xufVxuXG4uc2VsZWN0LXNlbGVjdGVkIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogRG9kZ2VyQmx1ZTtcbn1cblxuLypzdHlsZSB0aGUgYXJyb3cgaW5zaWRlIHRoZSBzZWxlY3QgZWxlbWVudDoqL1xuLnNlbGVjdC1zZWxlY3RlZDphZnRlciB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgY29udGVudDogXCJcIjtcbiAgdG9wOiAxNHB4O1xuICByaWdodDogMTBweDtcbiAgd2lkdGg6IDA7XG4gIGhlaWdodDogMDtcbiAgYm9yZGVyOiA2cHggc29saWQgdHJhbnNwYXJlbnQ7XG4gIGJvcmRlci1jb2xvcjogI2ZmZiB0cmFuc3BhcmVudCB0cmFuc3BhcmVudCB0cmFuc3BhcmVudDtcbn1cblxuLypwb2ludCB0aGUgYXJyb3cgdXB3YXJkcyB3aGVuIHRoZSBzZWxlY3QgYm94IGlzIG9wZW4gKGFjdGl2ZSk6Ki9cbi5zZWxlY3Qtc2VsZWN0ZWQuc2VsZWN0LWFycm93LWFjdGl2ZTphZnRlciB7XG4gIGJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQgdHJhbnNwYXJlbnQgI2ZmZiB0cmFuc3BhcmVudDtcbiAgdG9wOiA3cHg7XG59XG5cbi8qc3R5bGUgdGhlIGl0ZW1zIChvcHRpb25zKSwgaW5jbHVkaW5nIHRoZSBzZWxlY3RlZCBpdGVtOiovXG4uc2VsZWN0LWl0ZW1zIGRpdiwgLnNlbGVjdC1zZWxlY3RlZCB7XG4gIGNvbG9yOiAjZmZmZmZmO1xuICBwYWRkaW5nOiA4cHggMTZweDtcbiAgYm9yZGVyOiAxcHggc29saWQgdHJhbnNwYXJlbnQ7XG4gIGJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQgdHJhbnNwYXJlbnQgcmdiYSgwLCAwLCAwLCAwLjEpIHRyYW5zcGFyZW50O1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIHVzZXItc2VsZWN0OiBub25lO1xufVxuXG4vKnN0eWxlIGl0ZW1zIChvcHRpb25zKToqL1xuLnNlbGVjdC1pdGVtcyB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgYmFja2dyb3VuZC1jb2xvcjogRG9kZ2VyQmx1ZTtcbiAgdG9wOiAxMDAlO1xuICBsZWZ0OiAwO1xuICByaWdodDogMDtcbiAgei1pbmRleDogOTk7XG59XG5cbi8qaGlkZSB0aGUgaXRlbXMgd2hlbiB0aGUgc2VsZWN0IGJveCBpcyBjbG9zZWQ6Ki9cbi5zZWxlY3QtaGlkZSB7XG4gIGRpc3BsYXk6IG5vbmU7XG59XG5cbi5zZWxlY3QtaXRlbXMgZGl2OmhvdmVyLCAuc2FtZS1hcy1zZWxlY3RlZCB7XG4gIGJhY2tncm91bmQtY29sb3I6IHJnYmEoMCwgMCwgMCwgMC4xKTtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/components/product-card/product-card.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/components/product-card/product-card.component.ts ***!
  \*******************************************************************/
/*! exports provided: ProductCardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductCardComponent", function() { return ProductCardComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_app_services_shopping_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/shopping.service */ "./src/app/services/shopping.service.ts");
/* harmony import */ var src_app_services_cart_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/cart.service */ "./src/app/services/cart.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var src_app_global__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/global */ "./src/app/global.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");







let ProductCardComponent = class ProductCardComponent {
    constructor(shoppingService, toastController, cart, router) {
        this.shoppingService = shoppingService;
        this.toastController = toastController;
        this.cart = cart;
        this.router = router;
        this.globalVariable = src_app_global__WEBPACK_IMPORTED_MODULE_5__["Global"];
        this.productVarieties = [];
        this.quantityDict = new Map();
        this.cartItem = {
            product: {
                id: 0,
                category: 0,
                subCategory: 0,
                productName: '',
                productCompany: '',
                productPrice: 0,
                productPriceBeforeDiscount: 0,
                productDescription: '',
                productImage1: '',
                productImage2: '',
                productImage3: '',
                shippingCharge: 0,
                productAvailability: '',
                postingDate: new Date(),
                updationDate: new Date(),
                priceVarietyAvailable: false
            },
            productVariety: {
                id: 0,
                productId: 0,
                quantityType: '',
                productQuantity: 0,
                productPrice: 0
            },
            quantity: 0
        };
        this.choosedProductVariety = 0;
    }
    ngOnInit() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            yield this.getProductVariety();
            if (this.productVarieties.length !== 0) {
                this.choosedProductVariety = this.productVarieties[0].id;
            }
        });
    }
    getProductVariety() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.productVarieties = yield this.shoppingService.getProductVarietyByProductId(this.product.id);
            this.productVarieties.forEach(element => {
                console.log(this.product.productName, element.id + '****', element.productQuantity, element.quantityType);
                this.quantityDict.set(element.id, element);
            });
        });
    }
    presentToast(toastMessage) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: toastMessage,
                duration: 2000
            });
            toast.present();
        });
    }
    outOfStock() {
        this.presentToast('This item is currently unavailable :(');
    }
    addToBasket() {
        // tslint:disable-next-line: prefer-const
        let cartItemToAdd = {
            product: {
                id: 0,
                category: 0,
                subCategory: 0,
                productName: '',
                productCompany: '',
                productPrice: 0,
                productPriceBeforeDiscount: 0,
                productDescription: '',
                productImage1: '',
                productImage2: '',
                productImage3: '',
                shippingCharge: 0,
                productAvailability: '',
                postingDate: new Date(),
                updationDate: new Date(),
                priceVarietyAvailable: false
            },
            productVariety: {
                id: 0,
                productId: 0,
                quantityType: '',
                productQuantity: 0,
                productPrice: 0
            },
            quantity: 0
        };
        if (this.productVarieties.length !== 0 || this.choosedProductVariety === null || this.choosedProductVariety === undefined) {
            // console.log('************ showing basket details ************' + this.choosedProductVariety);
            cartItemToAdd.productVariety = this.quantityDict.get(this.choosedProductVariety);
        }
        else {
            cartItemToAdd.productVariety.id = 0;
            cartItemToAdd.productVariety.productId = this.product.id;
            cartItemToAdd.productVariety.productPrice = this.product.productPrice;
            cartItemToAdd.productVariety.productQuantity = 0;
            cartItemToAdd.productVariety.quantityType = 'default';
            this.choosedProductVariety = 1000;
        }
        cartItemToAdd.product = this.product;
        cartItemToAdd.quantity = 1;
        if (this.choosedProductVariety === 0) {
            // toast message
            this.presentToast('Please choose quantity of item');
            // console.log('Please choose quantity for the item.');
        }
        else {
            this.cart.addToCart(cartItemToAdd);
        }
    }
    onQuantitySelection() {
        if (this.productVarieties.length !== 0) {
            // console.log(this.choosedProductVariety);
        }
    }
    changeQuantity(change) {
        // if (this.productVarieties != null) {
        //   this.choosedProductVariety = this.quantityForm.value.quantity;
        // }
        this.cart.changeQuantity(this.product.id, this.quantityDict.get(this.choosedProductVariety).id, change);
    }
    // changeQuantityType(id) {
    //   const index = this.globalVariable.myCart.myCartItems.findIndex((e) => e.product.id === id);
    //   this.globalVariable.myCart.myCartItems.splice(index, 1);
    // }
    showDetails(productId) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            // console.log('************ showing details ************');
            yield this.switchPage(productId);
            // this.router.navigate(['/tabs/details'], { queryParams: { thisId: productId } });
            // this.router.navigate(['/tabs/details', {item: product}]);
        });
    }
    switchPage(productId) {
        // this.router.navigate(['/tabs/details'], { queryParams: { thisId: productId } });
    }
};
ProductCardComponent.ctorParameters = () => [
    { type: src_app_services_shopping_service__WEBPACK_IMPORTED_MODULE_2__["ShoppingService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] },
    { type: src_app_services_cart_service__WEBPACK_IMPORTED_MODULE_3__["CartService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('product'),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ProductCardComponent.prototype, "product", void 0);
ProductCardComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-product-card',
        template: __webpack_require__(/*! raw-loader!./product-card.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/product-card/product-card.component.html"),
        styles: [__webpack_require__(/*! ./product-card.component.scss */ "./src/app/components/product-card/product-card.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_shopping_service__WEBPACK_IMPORTED_MODULE_2__["ShoppingService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"],
        src_app_services_cart_service__WEBPACK_IMPORTED_MODULE_3__["CartService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]])
], ProductCardComponent);



/***/ }),

/***/ "./src/app/components/product-card/product-card.module.ts":
/*!****************************************************************!*\
  !*** ./src/app/components/product-card/product-card.module.ts ***!
  \****************************************************************/
/*! exports provided: ProductCardModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductCardModule", function() { return ProductCardModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _material_material_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../material/material.module */ "./src/app/material/material.module.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");





let ProductCardModule = class ProductCardModule {
};
ProductCardModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _material_material_module__WEBPACK_IMPORTED_MODULE_3__["MaterialModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ReactiveFormsModule"]
        ],
        exports: [
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ReactiveFormsModule"],
            _material_material_module__WEBPACK_IMPORTED_MODULE_3__["MaterialModule"]
        ]
    })
], ProductCardModule);



/***/ }),

/***/ "./src/app/pages/products/products-routing.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/pages/products/products-routing.module.ts ***!
  \***********************************************************/
/*! exports provided: ProductsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductsPageRoutingModule", function() { return ProductsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _products_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./products.page */ "./src/app/pages/products/products.page.ts");




const routes = [
    {
        path: '',
        component: _products_page__WEBPACK_IMPORTED_MODULE_3__["ProductsPage"]
    }
];
let ProductsPageRoutingModule = class ProductsPageRoutingModule {
};
ProductsPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ProductsPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/products/products.module.ts":
/*!***************************************************!*\
  !*** ./src/app/pages/products/products.module.ts ***!
  \***************************************************/
/*! exports provided: ProductsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductsPageModule", function() { return ProductsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _products_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./products-routing.module */ "./src/app/pages/products/products-routing.module.ts");
/* harmony import */ var _products_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./products.page */ "./src/app/pages/products/products.page.ts");
/* harmony import */ var _pipes_discount_pipe__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../pipes/discount.pipe */ "./src/app/pipes/discount.pipe.ts");
/* harmony import */ var _components_product_card_product_card_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../components/product-card/product-card.component */ "./src/app/components/product-card/product-card.component.ts");
/* harmony import */ var src_app_components_product_card_product_card_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/components/product-card/product-card.module */ "./src/app/components/product-card/product-card.module.ts");










let ProductsPageModule = class ProductsPageModule {
};
ProductsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _products_routing_module__WEBPACK_IMPORTED_MODULE_5__["ProductsPageRoutingModule"],
            src_app_components_product_card_product_card_module__WEBPACK_IMPORTED_MODULE_9__["ProductCardModule"]
        ],
        declarations: [_products_page__WEBPACK_IMPORTED_MODULE_6__["ProductsPage"], _pipes_discount_pipe__WEBPACK_IMPORTED_MODULE_7__["DiscountPipe"], _components_product_card_product_card_component__WEBPACK_IMPORTED_MODULE_8__["ProductCardComponent"]],
        exports: [
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            src_app_components_product_card_product_card_module__WEBPACK_IMPORTED_MODULE_9__["ProductCardModule"],
            _components_product_card_product_card_component__WEBPACK_IMPORTED_MODULE_8__["ProductCardComponent"]
        ]
    })
], ProductsPageModule);



/***/ }),

/***/ "./src/app/pages/products/products.page.scss":
/*!***************************************************!*\
  !*** ./src/app/pages/products/products.page.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3Byb2R1Y3RzL3Byb2R1Y3RzLnBhZ2Uuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/products/products.page.ts":
/*!*************************************************!*\
  !*** ./src/app/pages/products/products.page.ts ***!
  \*************************************************/
/*! exports provided: ProductsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductsPage", function() { return ProductsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var src_app_services_shopping_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/shopping.service */ "./src/app/services/shopping.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");





let ProductsPage = class ProductsPage {
    constructor(route, shoppingService, loading) {
        this.route = route;
        this.shoppingService = shoppingService;
        this.loading = loading;
        this.altText = '';
    }
    ngOnInit() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = yield this.loading.create({
                message: 'Getting products',
            });
            yield loading.present();
            yield this.route.queryParams.subscribe((queryParams) => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
                this.error = false;
                // console.log(queryParams);
                // tslint:disable: no-string-literal
                this.pid = Number(queryParams['pid']);
                this.pSearch = queryParams['pSearch'];
                this.subid = queryParams['subid'];
                this.subid1 = queryParams['subid1'];
                this.subid2 = queryParams['subid2'];
                this.products = [];
                if (this.pid) {
                    this.products = yield this.shoppingService.getProductsByCategoryId(this.pid);
                }
                else if (this.pSearch) {
                    this.products = yield this.shoppingService.getProductsBySearch(this.pSearch);
                }
                else if (this.subid1 && this.subid2) {
                    this.products = yield this.shoppingService.getProductsBySubcategoryId2(this.subid1, this.subid2);
                }
                else {
                    this.products = yield this.shoppingService.getProductsBySubcategoryId(this.subid);
                }
                if (this.products.length === 0) {
                    this.error = true;
                }
                this.imgsrc = '../assets/subpic/' + this.products[0].subCategory + '.png';
                this.altText = 'This is what we found in ' +
                    (yield this.shoppingService.getSubcategoryByID(this.products[0].subCategory)).subcategory;
            }));
            loading.dismiss();
        });
    }
};
ProductsPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: src_app_services_shopping_service__WEBPACK_IMPORTED_MODULE_3__["ShoppingService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"] }
];
ProductsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-products',
        template: __webpack_require__(/*! raw-loader!./products.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/products/products.page.html"),
        styles: [__webpack_require__(/*! ./products.page.scss */ "./src/app/pages/products/products.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], src_app_services_shopping_service__WEBPACK_IMPORTED_MODULE_3__["ShoppingService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"]])
], ProductsPage);



/***/ }),

/***/ "./src/app/pipes/discount.pipe.ts":
/*!****************************************!*\
  !*** ./src/app/pipes/discount.pipe.ts ***!
  \****************************************/
/*! exports provided: DiscountPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DiscountPipe", function() { return DiscountPipe; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let DiscountPipe = class DiscountPipe {
    transform(mp, sp) {
        let discount = ((mp - sp) / mp) * 100;
        discount = Math.trunc(discount);
        const toReturn = discount + '% off';
        if (discount * 1 === 0) {
            return '';
        }
        else {
            return toReturn;
        }
    }
};
DiscountPipe = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
        name: 'discount'
    })
], DiscountPipe);



/***/ }),

/***/ "./src/app/services/cart.service.ts":
/*!******************************************!*\
  !*** ./src/app/services/cart.service.ts ***!
  \******************************************/
/*! exports provided: CartService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CartService", function() { return CartService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _models_cart__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../models/cart */ "./src/app/models/cart.ts");
/* harmony import */ var src_app_global__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/global */ "./src/app/global.ts");
/* harmony import */ var _storage_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./storage.service */ "./src/app/services/storage.service.ts");





let CartService = 
// tslint:disable: no-string-literal
class CartService {
    constructor(storage) {
        this.storage = storage;
        this.data = [];
        this.globalVariable = src_app_global__WEBPACK_IMPORTED_MODULE_3__["Global"];
        // private myCartItems: CartItem[] = [];
        this.myCartItems = new Set([]);
    }
    addToCart(cartItem) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            try {
                console.log('Adding ', cartItem.product.productName, cartItem.productVariety.productQuantity, cartItem.productVariety.quantityType);
                this.myCartItems.forEach(element => {
                    console.log('%%%%%', element);
                });
                this.myCartItems.add(cartItem);
                this.myCartItems.forEach(element => {
                    console.log(element);
                });
                this.globalVariable.myCart = new _models_cart__WEBPACK_IMPORTED_MODULE_2__["Cart"](this.myCartItems);
                this.storage.saveInLocal('myCart', this.globalVariable.myCart);
            }
            catch (e) {
                console.log(e);
            }
        });
    }
    clearCart() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            try {
                const myCartItems2 = new Set([]);
                this.myCartItems = myCartItems2;
                this.globalVariable.myCart = new _models_cart__WEBPACK_IMPORTED_MODULE_2__["Cart"](this.myCartItems);
                this.storage.saveInLocal('myCart', this.globalVariable.myCart);
            }
            catch (e) {
                console.log(e);
            }
        });
    }
    changeQuantity(cartItemProductId, cartItemProductVarietyId, change) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            try {
                // const index = this.globalVariable.myCart.myCartItems.findIndex(e =>
                //   (e.product.id === cartItemProductId) && (e.productVariety.id === cartItemProductVarietyId));
                // this.globalVariable.myCart.myCartItems[index].quantity += change;
                // const quantity = this.globalVariable.myCart.myCartItems[index].quantity;
                let quantity = 0;
                let itemToDel;
                this.myCartItems.forEach(item => {
                    if (item.product.id === cartItemProductId && item.productVariety.id === cartItemProductVarietyId) {
                        item.quantity += change;
                        quantity = item.quantity;
                        itemToDel = item;
                    }
                });
                if (quantity === 0) {
                    console.log('deleting**************************', itemToDel.product.productName);
                    this.globalVariable.myCart.myCartItems.delete(itemToDel);
                }
                const myCartItems2 = this.globalVariable.myCart.myCartItems;
                this.globalVariable.myCart = new _models_cart__WEBPACK_IMPORTED_MODULE_2__["Cart"](myCartItems2);
                this.storage.saveInLocal('myCart', this.globalVariable.myCart);
            }
            catch (e) {
                console.log(e);
            }
        });
    }
};
CartService.ctorParameters = () => [
    { type: _storage_service__WEBPACK_IMPORTED_MODULE_4__["StorageService"] }
];
CartService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
    // tslint:disable: no-string-literal
    ,
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_storage_service__WEBPACK_IMPORTED_MODULE_4__["StorageService"]])
], CartService);



/***/ }),

/***/ "./src/app/services/shopping.service.ts":
/*!**********************************************!*\
  !*** ./src/app/services/shopping.service.ts ***!
  \**********************************************/
/*! exports provided: ShoppingService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ShoppingService", function() { return ShoppingService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");




let ShoppingService = 
// tslint:disable: no-string-literal
class ShoppingService {
    constructor(http) {
        this.http = http;
    }
    // Get all categories
    getAllCategories() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            try {
                console.log('hi');
                const response = yield this.http.get(`https://theflyingbasket.com/backend/api/getCategories.php`).toPromise();
                return response['categoryData'];
            }
            catch (error) {
                yield this.handleError(error);
            }
        });
    }
    // Get all subcategories for a category
    getAllSubcategories(categoryid) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            try {
                const response = yield this.http.post(`https://theflyingbasket.com/backend/api/getSubcategoryByCategory.php`, categoryid)
                    .toPromise();
                return response['subcategoryData'];
            }
            catch (error) {
                yield this.handleError(error);
            }
        });
    }
    // Get subcategory by id
    getSubcategoryByID(subcategoryid) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            try {
                const response = yield this.http.post(`https://theflyingbasket.com/backend/api/getSubcategoryNameById.php`, subcategoryid)
                    .toPromise();
                console.log('*********' + JSON.stringify(response['subData']));
                return response['subData'];
            }
            catch (error) {
                yield this.handleError(error);
            }
        });
    }
    // Get all product details for menu page
    getProductsByCategoryId(categoryId) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            try {
                const response = yield this.http.post(`https://theflyingbasket.com/backend/api/getAllProductsOfCategory.php`, categoryId).toPromise();
                this.products = response['productData'];
                return this.products;
            }
            catch (error) {
                yield this.handleError(error);
            }
        });
    }
    // Get all product details for menu page
    getProductsBySubcategoryId(subcategoryId) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            try {
                const response = yield this.http.post(`https://theflyingbasket.com/backend/api/getAllProductsOfSubCategory.php`, subcategoryId).toPromise();
                this.products = response['productData'];
                return this.products;
            }
            catch (error) {
                yield this.handleError(error);
            }
        });
    }
    // Get all product details for menu page
    getProductsBySubcategoryId2(subcategoryId1, subcategoryId2) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            try {
                const jsonToSend = {
                    id1: subcategoryId1,
                    id2: subcategoryId2
                };
                const response = yield this.http.post(`https://theflyingbasket.com/backend/api/getAllProductsOfSubCategory2.php`, jsonToSend).toPromise();
                this.products = response['productData'];
                return this.products;
            }
            catch (error) {
                yield this.handleError(error);
            }
        });
    }
    // Get product for a search keyword
    getProductsBySearch(keyword) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            try {
                const response = yield this.http.post(`https://theflyingbasket.com/backend/api/searchBarResponse.php`, keyword).toPromise();
                this.products = response['productData'];
                return this.products;
            }
            catch (error) {
                yield this.handleError(error);
            }
        });
    }
    // Get product details.
    getProductByProductId(productId) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            try {
                const response = yield this.http.post(`https://theflyingbasket.com/backend/api/getProductByProductId.php`, productId).toPromise();
                return response['productData'];
            }
            catch (error) {
                yield this.handleError(error);
            }
        });
    }
    // Get Product Variety details.
    getProductVarietyByProductId(productId) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            try {
                const response = yield this.http.post(`https://theflyingbasket.com/backend/api/getProductVarietyByProductId.php`, productId).toPromise();
                return response['productVarietyData'];
            }
            catch (error) {
                this.handleError(error);
            }
        });
    }
    // Get product for people also bought
    peopleAlsoBought(category) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            try {
                const response = yield this.http.post(`https://theflyingbasket.com/backend/api/peopleAlsoBought.php`, category).toPromise();
                this.products = response['productData'];
                return this.products;
            }
            catch (error) {
                yield this.handleError(error);
            }
        });
    }
    // Get product for a search keyword
    //   getProductsBySearch2(keyword: string): Observable<Product[]> {
    //     if (keyword === '') { return null; }
    //     return this.http.post(`${this.baseUrl}/api/searchBarResponse.php`, keyword).pipe(
    //        map((res) => {
    //          return res['productData'] as Product[];
    //      }),
    //      catchError(this.handleError));\
    //  }
    handleError(error) {
        console.log(error);
        // return an observable with a user friendly message
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])('Error! something went wrong.');
    }
};
ShoppingService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
ShoppingService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
    // tslint:disable: no-string-literal
    ,
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
], ShoppingService);



/***/ })

}]);
//# sourceMappingURL=default~cart-cart-module~product-details-product-details-module~products-products-module-es2015.js.map