(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["sidePanel-privacy-policy-privacy-policy-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/sidePanel/privacy-policy/privacy-policy.page.html":
/*!***************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/sidePanel/privacy-policy/privacy-policy.page.html ***!
  \***************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>PrivacyPolicy</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"container myContainer\">\n    <ion-row class=\"header justify-content-center text-center\">\n      <h3>PRIVACY POLICY\n      </h3>\n    </ion-row>\n    <ion-row class=\"content justify-content\">\n    <p>\n    <br>    <b>1. Introduction</b>\n    <br>    1.1 This is the privacy policy of www.theflyingbasket.com our trading and registered offices and other contact details are specified on our website.\n    <br>    1.2 The purpose of this policy is to tell you how we process your “Personal Data” (i.e. data about any identified or identifiable living ? person). In particular:\n    <br>    a) What Personal Data we collect;\n    <br>    b) How we use it;\n    <br>    c) How we protect it;\n    <br>    d) To whom we disclose it;\n    <br>    e) How you can access and rectify it.\n    <br>    1.3 Please contact us if you have any queries concerning this policy.\u2028\u2028<br>\n    <br>    <b>2. What Personal Information do we collect?</b>\n    <br>    2.1 When you place an order, we may collect the following personally identifiable information about you like:\n    <br>    a) Username and password\n    <br>    b) Your First Name and Last Name\n    <br>    c) Your E Mail ID\n    <br>    d) Address\n    <br>    e) Phone / Mobile Number\n    <br>    f) Pin / Zip Code\n    <br>    g) Nearest Landmark\n    <br>    You may provide us with additional information if you communicate with us by phone / email or otherwise.\n    <br>    2.2 Like many websites we use cookies. A cookie is a small amount of data that is sent to your browser from a web server and stored on your computer’s hard drive. We use a session cookie which enables us to identify you (only) throughout a session on our site, so that you can use features such as the basket and are able to place orders. A session cookie is essential to our service.\u2028\u2028<br>\n    <br>    <b>3. How do we use your Personal Data?</b>\n    <br>    3.1 We use your Personal Data for processing, and communicating with you regarding, your order.\n    <br>    3.2 We may also send you Gift cards, Some special discount on your Birthday or Anniversary date.\n    <br>    3.3 We may use IP addresses for customer profiling purposes.\n    <br>    3.4 We may use your Personal Data to provide a more personalized and user-friendly visit to our website as follows: to streamline future orders, to help us track user traffic patterns, to communicate with you on our website about orders, goods, services, special offers and targeted promotions, to update our records and maintain your account with us, and also use this information to improve our website or to prevent or detect fraud or abuses.\u2028\u2028<br>\n    <br>    <b>4. How do we protect Personal Data?</b>\n    <br>    4.1 Security is a high priority for us. We take appropriate precautions to protect Personal Data from loss, misuse, unauthorized access or disclosure, alteration or destruction.\n    <br>    4.2 We store your information in a secure location. While we encourage you to take advantage of our personalized services.\u2028\u2028<br>\n    <br>    <b>5. To whom do we disclose personal data?</b>\n    <br>    5.1 Payment details including credit card numbers are supplied direct to our banking partner which is specified on our website. We do not receive such information.\u2028\u2028<br>\n    <br>    <b>6. How can you access and rectify Personal Data?</b>\n    <br>    6.1 You can access and rectify certain of your Personal Data by contacting us using the details provided on our website.\n    <br>    6.2 You can change your information at any time by editing your profile.\n          \n    </p>\n    </ion-row>\n  </div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/sidePanel/privacy-policy/privacy-policy-routing.module.ts":
/*!*********************************************************************************!*\
  !*** ./src/app/pages/sidePanel/privacy-policy/privacy-policy-routing.module.ts ***!
  \*********************************************************************************/
/*! exports provided: PrivacyPolicyPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PrivacyPolicyPageRoutingModule", function() { return PrivacyPolicyPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _privacy_policy_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./privacy-policy.page */ "./src/app/pages/sidePanel/privacy-policy/privacy-policy.page.ts");




const routes = [
    {
        path: '',
        component: _privacy_policy_page__WEBPACK_IMPORTED_MODULE_3__["PrivacyPolicyPage"]
    }
];
let PrivacyPolicyPageRoutingModule = class PrivacyPolicyPageRoutingModule {
};
PrivacyPolicyPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], PrivacyPolicyPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/sidePanel/privacy-policy/privacy-policy.module.ts":
/*!*************************************************************************!*\
  !*** ./src/app/pages/sidePanel/privacy-policy/privacy-policy.module.ts ***!
  \*************************************************************************/
/*! exports provided: PrivacyPolicyPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PrivacyPolicyPageModule", function() { return PrivacyPolicyPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _privacy_policy_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./privacy-policy-routing.module */ "./src/app/pages/sidePanel/privacy-policy/privacy-policy-routing.module.ts");
/* harmony import */ var _privacy_policy_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./privacy-policy.page */ "./src/app/pages/sidePanel/privacy-policy/privacy-policy.page.ts");







let PrivacyPolicyPageModule = class PrivacyPolicyPageModule {
};
PrivacyPolicyPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _privacy_policy_routing_module__WEBPACK_IMPORTED_MODULE_5__["PrivacyPolicyPageRoutingModule"]
        ],
        declarations: [_privacy_policy_page__WEBPACK_IMPORTED_MODULE_6__["PrivacyPolicyPage"]]
    })
], PrivacyPolicyPageModule);



/***/ }),

/***/ "./src/app/pages/sidePanel/privacy-policy/privacy-policy.page.scss":
/*!*************************************************************************!*\
  !*** ./src/app/pages/sidePanel/privacy-policy/privacy-policy.page.scss ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".myContainer {\n  border: 2px solid black;\n}\n\n.header, .content {\n  margin-top: 10px;\n  margin-right: 10px;\n  margin-left: 10px;\n  margin-bottom: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9hcHBsZS9EZXNrdG9wL1Nob3BwaW5nL3RmYl92Mi4wL3RoZWZseWluZ2Jhc2tldC9zcmMvYXBwL3BhZ2VzL3NpZGVQYW5lbC9wcml2YWN5LXBvbGljeS9wcml2YWN5LXBvbGljeS5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL3NpZGVQYW5lbC9wcml2YWN5LXBvbGljeS9wcml2YWN5LXBvbGljeS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSx1QkFBQTtBQ0NKOztBREVBO0VBQ0ksZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7QUNDSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3NpZGVQYW5lbC9wcml2YWN5LXBvbGljeS9wcml2YWN5LXBvbGljeS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubXlDb250YWluZXIge1xuICAgIGJvcmRlcjogMnB4IHNvbGlkIGJsYWNrO1xufVxuXG4uaGVhZGVyLCAuY29udGVudCB7XG4gICAgbWFyZ2luLXRvcDogMTBweDtcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gICAgbWFyZ2luLWJvdHRvbTogMTBweDtcbn0iLCIubXlDb250YWluZXIge1xuICBib3JkZXI6IDJweCBzb2xpZCBibGFjaztcbn1cblxuLmhlYWRlciwgLmNvbnRlbnQge1xuICBtYXJnaW4tdG9wOiAxMHB4O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/pages/sidePanel/privacy-policy/privacy-policy.page.ts":
/*!***********************************************************************!*\
  !*** ./src/app/pages/sidePanel/privacy-policy/privacy-policy.page.ts ***!
  \***********************************************************************/
/*! exports provided: PrivacyPolicyPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PrivacyPolicyPage", function() { return PrivacyPolicyPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let PrivacyPolicyPage = class PrivacyPolicyPage {
    constructor() { }
    ngOnInit() {
    }
};
PrivacyPolicyPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-privacy-policy',
        template: __webpack_require__(/*! raw-loader!./privacy-policy.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/sidePanel/privacy-policy/privacy-policy.page.html"),
        styles: [__webpack_require__(/*! ./privacy-policy.page.scss */ "./src/app/pages/sidePanel/privacy-policy/privacy-policy.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], PrivacyPolicyPage);



/***/ })

}]);
//# sourceMappingURL=sidePanel-privacy-policy-privacy-policy-module-es2015.js.map