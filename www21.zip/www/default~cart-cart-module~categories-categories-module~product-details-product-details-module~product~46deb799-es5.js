(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~cart-cart-module~categories-categories-module~product-details-product-details-module~product~46deb799"],{

/***/ "./src/app/services/shopping.service.ts":
/*!**********************************************!*\
  !*** ./src/app/services/shopping.service.ts ***!
  \**********************************************/
/*! exports provided: ShoppingService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ShoppingService", function() { return ShoppingService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");




var ShoppingService = /** @class */ (function () {
    function ShoppingService(http) {
        this.http = http;
    }
    // Get all categories
    ShoppingService.prototype.getAllCategories = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var response, error_1;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 4]);
                        console.log('hi');
                        return [4 /*yield*/, this.http.get("https://theflyingbasket.com/backend/api/getCategories.php").toPromise()];
                    case 1:
                        response = _a.sent();
                        return [2 /*return*/, response['categoryData']];
                    case 2:
                        error_1 = _a.sent();
                        return [4 /*yield*/, this.handleError(error_1)];
                    case 3:
                        _a.sent();
                        return [3 /*break*/, 4];
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    // Get all subcategories for a category
    ShoppingService.prototype.getAllSubcategories = function (categoryid) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var response, error_2;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 4]);
                        return [4 /*yield*/, this.http.post("https://theflyingbasket.com/backend/api/getSubcategoryByCategory.php", categoryid)
                                .toPromise()];
                    case 1:
                        response = _a.sent();
                        return [2 /*return*/, response['subcategoryData']];
                    case 2:
                        error_2 = _a.sent();
                        return [4 /*yield*/, this.handleError(error_2)];
                    case 3:
                        _a.sent();
                        return [3 /*break*/, 4];
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    // Get subcategory by id
    ShoppingService.prototype.getSubcategoryByID = function (subcategoryid) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var response, error_3;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 4]);
                        return [4 /*yield*/, this.http.post("https://theflyingbasket.com/backend/api/getSubcategoryNameById.php", subcategoryid)
                                .toPromise()];
                    case 1:
                        response = _a.sent();
                        console.log('*********' + JSON.stringify(response['subData']));
                        return [2 /*return*/, response['subData']];
                    case 2:
                        error_3 = _a.sent();
                        return [4 /*yield*/, this.handleError(error_3)];
                    case 3:
                        _a.sent();
                        return [3 /*break*/, 4];
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    // Get all product details for menu page
    ShoppingService.prototype.getProductsByCategoryId = function (categoryId) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var response, error_4;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 4]);
                        return [4 /*yield*/, this.http.post("https://theflyingbasket.com/backend/api/getAllProductsOfCategory.php", categoryId).toPromise()];
                    case 1:
                        response = _a.sent();
                        this.products = response['productData'];
                        return [2 /*return*/, this.products];
                    case 2:
                        error_4 = _a.sent();
                        return [4 /*yield*/, this.handleError(error_4)];
                    case 3:
                        _a.sent();
                        return [3 /*break*/, 4];
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    // Get all product details for menu page
    ShoppingService.prototype.getProductsBySubcategoryId = function (subcategoryId) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var response, error_5;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 4]);
                        return [4 /*yield*/, this.http.post("https://theflyingbasket.com/backend/api/getAllProductsOfSubCategory.php", subcategoryId).toPromise()];
                    case 1:
                        response = _a.sent();
                        this.products = response['productData'];
                        return [2 /*return*/, this.products];
                    case 2:
                        error_5 = _a.sent();
                        return [4 /*yield*/, this.handleError(error_5)];
                    case 3:
                        _a.sent();
                        return [3 /*break*/, 4];
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    // Get all product details for menu page
    ShoppingService.prototype.getProductsBySubcategoryId2 = function (subcategoryId1, subcategoryId2) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var jsonToSend, response, error_6;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 4]);
                        jsonToSend = {
                            id1: subcategoryId1,
                            id2: subcategoryId2
                        };
                        return [4 /*yield*/, this.http.post("https://theflyingbasket.com/backend/api/getAllProductsOfSubCategory2.php", jsonToSend).toPromise()];
                    case 1:
                        response = _a.sent();
                        this.products = response['productData'];
                        return [2 /*return*/, this.products];
                    case 2:
                        error_6 = _a.sent();
                        return [4 /*yield*/, this.handleError(error_6)];
                    case 3:
                        _a.sent();
                        return [3 /*break*/, 4];
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    // Get product for a search keyword
    ShoppingService.prototype.getProductsBySearch = function (keyword) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var response, error_7;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 4]);
                        return [4 /*yield*/, this.http.post("https://theflyingbasket.com/backend/api/searchBarResponse.php", keyword).toPromise()];
                    case 1:
                        response = _a.sent();
                        this.products = response['productData'];
                        return [2 /*return*/, this.products];
                    case 2:
                        error_7 = _a.sent();
                        return [4 /*yield*/, this.handleError(error_7)];
                    case 3:
                        _a.sent();
                        return [3 /*break*/, 4];
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    // Get product details.
    ShoppingService.prototype.getProductByProductId = function (productId) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var response, error_8;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 4]);
                        return [4 /*yield*/, this.http.post("https://theflyingbasket.com/backend/api/getProductByProductId.php", productId).toPromise()];
                    case 1:
                        response = _a.sent();
                        return [2 /*return*/, response['productData']];
                    case 2:
                        error_8 = _a.sent();
                        return [4 /*yield*/, this.handleError(error_8)];
                    case 3:
                        _a.sent();
                        return [3 /*break*/, 4];
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    // Get Product Variety details.
    ShoppingService.prototype.getProductVarietyByProductId = function (productId) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var response, error_9;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 3]);
                        return [4 /*yield*/, this.http.post("https://theflyingbasket.com/backend/api/getProductVarietyByProductId.php", productId).toPromise()];
                    case 1:
                        response = _a.sent();
                        return [2 /*return*/, response['productVarietyData']];
                    case 2:
                        error_9 = _a.sent();
                        this.handleError(error_9);
                        return [3 /*break*/, 3];
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    // Get product for people also bought
    ShoppingService.prototype.peopleAlsoBought = function (category) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var response, error_10;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 4]);
                        return [4 /*yield*/, this.http.post("https://theflyingbasket.com/backend/api/peopleAlsoBought.php", category).toPromise()];
                    case 1:
                        response = _a.sent();
                        this.products = response['productData'];
                        return [2 /*return*/, this.products];
                    case 2:
                        error_10 = _a.sent();
                        return [4 /*yield*/, this.handleError(error_10)];
                    case 3:
                        _a.sent();
                        return [3 /*break*/, 4];
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    // Get product for a search keyword
    //   getProductsBySearch2(keyword: string): Observable<Product[]> {
    //     if (keyword === '') { return null; }
    //     return this.http.post(`${this.baseUrl}/api/searchBarResponse.php`, keyword).pipe(
    //        map((res) => {
    //          return res['productData'] as Product[];
    //      }),
    //      catchError(this.handleError));\
    //  }
    ShoppingService.prototype.handleError = function (error) {
        console.log(error);
        // return an observable with a user friendly message
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])('Error! something went wrong.');
    };
    ShoppingService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
    ]; };
    ShoppingService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        })
        // tslint:disable: no-string-literal
        ,
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], ShoppingService);
    return ShoppingService;
}());



/***/ })

}]);
//# sourceMappingURL=default~cart-cart-module~categories-categories-module~product-details-product-details-module~product~46deb799-es5.js.map