(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["sidePanel-cancel-cancel-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/sidePanel/cancel/cancel.page.html":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/sidePanel/cancel/cancel.page.html ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>Cancel</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"container myContainer\">\n    <ion-row class=\"row header justify-content-center text-center\">\n      <h3>CANCEL & RETURN POLICY\n      </h3>\n    </ion-row>\n    <ion-row class=\"row content justify-content\">\n    <p>\n      ● Refund and Return :<br>\n      Once you purchase a product and it is delivered properly it couldn’t be returned.\n      Check the Loose product like vegetables and fruits and other grocery item Before \n      delivery if find something wrong don’t accept from delivery boy.We always check \n      thoroughly products to maintain proper quality and quantity and then send for the\n      shipping to the customer. At the time of shipping if any product will damage please\n      don’t accept the damaged product. Replacement only acceptable in case of wrong product\n      delivered . Otherwise no replacement no return will be acceptable . We won’t return \n      open packed product. We always accept bank transfer and Credit card & debit card \n      payment through Payment Gateway. Risk of credit & debit card is subjected to Payment Gateway.\n    </p>\n    </ion-row>\n  </div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/sidePanel/cancel/cancel-routing.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/pages/sidePanel/cancel/cancel-routing.module.ts ***!
  \*****************************************************************/
/*! exports provided: CancelPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CancelPageRoutingModule", function() { return CancelPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _cancel_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./cancel.page */ "./src/app/pages/sidePanel/cancel/cancel.page.ts");




const routes = [
    {
        path: '',
        component: _cancel_page__WEBPACK_IMPORTED_MODULE_3__["CancelPage"]
    }
];
let CancelPageRoutingModule = class CancelPageRoutingModule {
};
CancelPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CancelPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/sidePanel/cancel/cancel.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/sidePanel/cancel/cancel.module.ts ***!
  \*********************************************************/
/*! exports provided: CancelPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CancelPageModule", function() { return CancelPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _cancel_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./cancel-routing.module */ "./src/app/pages/sidePanel/cancel/cancel-routing.module.ts");
/* harmony import */ var _cancel_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./cancel.page */ "./src/app/pages/sidePanel/cancel/cancel.page.ts");







let CancelPageModule = class CancelPageModule {
};
CancelPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _cancel_routing_module__WEBPACK_IMPORTED_MODULE_5__["CancelPageRoutingModule"]
        ],
        declarations: [_cancel_page__WEBPACK_IMPORTED_MODULE_6__["CancelPage"]]
    })
], CancelPageModule);



/***/ }),

/***/ "./src/app/pages/sidePanel/cancel/cancel.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/pages/sidePanel/cancel/cancel.page.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".myContainer {\n  border: 2px solid black;\n}\n\n.header, .content {\n  margin-top: 10px;\n  margin-right: 10px;\n  margin-left: 10px;\n  margin-bottom: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9hcHBsZS9EZXNrdG9wL1Nob3BwaW5nL3RmYl92Mi4wL3RoZWZseWluZ2Jhc2tldC9zcmMvYXBwL3BhZ2VzL3NpZGVQYW5lbC9jYW5jZWwvY2FuY2VsLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGFnZXMvc2lkZVBhbmVsL2NhbmNlbC9jYW5jZWwucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksdUJBQUE7QUNDSjs7QURFQTtFQUNJLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0FDQ0oiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9zaWRlUGFuZWwvY2FuY2VsL2NhbmNlbC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubXlDb250YWluZXIge1xuICAgIGJvcmRlcjogMnB4IHNvbGlkIGJsYWNrO1xufVxuXG4uaGVhZGVyLCAuY29udGVudCB7XG4gICAgbWFyZ2luLXRvcDogMTBweDtcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gICAgbWFyZ2luLWJvdHRvbTogMTBweDtcbn0iLCIubXlDb250YWluZXIge1xuICBib3JkZXI6IDJweCBzb2xpZCBibGFjaztcbn1cblxuLmhlYWRlciwgLmNvbnRlbnQge1xuICBtYXJnaW4tdG9wOiAxMHB4O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/pages/sidePanel/cancel/cancel.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages/sidePanel/cancel/cancel.page.ts ***!
  \*******************************************************/
/*! exports provided: CancelPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CancelPage", function() { return CancelPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let CancelPage = class CancelPage {
    constructor() { }
    ngOnInit() {
    }
};
CancelPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-cancel',
        template: __webpack_require__(/*! raw-loader!./cancel.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/sidePanel/cancel/cancel.page.html"),
        styles: [__webpack_require__(/*! ./cancel.page.scss */ "./src/app/pages/sidePanel/cancel/cancel.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], CancelPage);



/***/ })

}]);
//# sourceMappingURL=sidePanel-cancel-cancel-module-es2015.js.map