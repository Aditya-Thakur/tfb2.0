(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["sidePanel-my-orders-my-orders-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/components/ordered-item/ordered-item.component.html":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/ordered-item/ordered-item.component.html ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-card>\n  <ion-item>\n    <ion-grid>\n      <ion-row>\n        <ion-col>\n          <!-- <ion-badge *ngIf=\"(cartItem.product.productPriceBeforeDiscount - cartItem.product.productPrice) >= 0\" color=\"danger\">{{cartItem.product.productPriceBeforeDiscount | discount:cartItem.product.productPrice}}</ion-badge> -->\n          <ion-img width=\"80\" height=\"80\"\n            src=\"http://theflyingbasket.com/assets/productimages/{{cartItem.product.id}}/{{cartItem.product.productImage1}}\"\n            (click)=\"showDetails(cartItem.product.id)\"></ion-img>\n        </ion-col>\n        <ion-col>\n          <ion-grid>\n              <ion-row\n                *ngIf=\"cartItem.productVariety.id == 0  && cartItem.product.productPriceBeforeDiscount!=cartItem.product.productPrice\"\n                class=\"ion-text-center\">\n                <span class=\"productPrice\" style=\"text-decoration: line-through;\">Rs.\n                  {{cartItem.product.productPriceBeforeDiscount}}/-</span>\n              </ion-row>\n              <ion-row *ngIf=\"cartItem.productVariety.id != 0; else priceActual\">\n                {{cartItem.productVariety.productQuantity}} {{cartItem.productVariety.quantityType}} - Rs.&nbsp;\n                {{cartItem.productVariety.productPrice}}\n              </ion-row>\n              <ng-template #priceActual>\n                <ion-row class=\"ion-text-center\">\n                  Rs. {{cartItem.product.productPrice}}/-\n                </ion-row>\n              </ng-template>\n            <!-- <ion-row *ngIf=\"cartItem.quantity == 1; else inCart\">\n              <ion-button color=\"danger\" (click)=\"removeFromBasket()\">Remove from &nbsp;<ion-icon name=\"basket\">\n                </ion-icon>\n              </ion-button>\n            </ion-row> -->\n            <!-- <ng-template #inCart>\n              <ion-row>\n                <ion-button (click)=\"changeQuantity(-1)\" color=\"warning\">\n                  <ion-text color=\"dark\">-</ion-text>\n                </ion-button>\n                <ion-text>\n                  {{cartItem.quantity}} in &nbsp;\n                  <ion-icon name=\"basket\"></ion-icon>\n                </ion-text>\n                <ion-button (click)=\"changeQuantity(1)\" color=\"secondary\">\n                  <ion-text color=\"dark\">+</ion-text>\n                </ion-button>\n              </ion-row>\n            </ng-template> -->\n            <ion-row>\n              Quantity - {{cartItem.quantity}}\n            </ion-row>\n          </ion-grid>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-item>\n\n  <ion-card-content (click)=\"showDetails(product.id)\">\n    {{cartItem.product.productName}}\n  </ion-card-content>\n</ion-card>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/sidePanel/my-orders/my-orders.page.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/sidePanel/my-orders/my-orders.page.html ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>MyOrders</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-header>\n    <ion-button expand=\"full\" color=\"secondary\">Your Orders:</ion-button>\n</ion-header>\n\n<ion-grid>\n  <ion-grid *ngFor = \"let order of myOrders\">\n    <ion-row *ngFor=\"let cartItem of order.cart.myCartItems\">\n        <app-ordered-item [cartItem]=\"cartItem\">\n          </app-ordered-item>\n    </ion-row>\n    <ion-button expand=\"full\" color=\"primary\">Older Orders:</ion-button>\n  </ion-grid>\n</ion-grid>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/components/ordered-item/ordered-item.component.scss":
/*!*********************************************************************!*\
  !*** ./src/app/components/ordered-item/ordered-item.component.scss ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvb3JkZXJlZC1pdGVtL29yZGVyZWQtaXRlbS5jb21wb25lbnQuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/components/ordered-item/ordered-item.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/components/ordered-item/ordered-item.component.ts ***!
  \*******************************************************************/
/*! exports provided: OrderedItemComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrderedItemComponent", function() { return OrderedItemComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_global__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/global */ "./src/app/global.ts");



var OrderedItemComponent = /** @class */ (function () {
    function OrderedItemComponent() {
        this.globalVariable = src_app_global__WEBPACK_IMPORTED_MODULE_2__["Global"];
    }
    OrderedItemComponent.prototype.ngOnInit = function () { };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('cartItem'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], OrderedItemComponent.prototype, "cartItem", void 0);
    OrderedItemComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-ordered-item',
            template: __webpack_require__(/*! raw-loader!./ordered-item.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/ordered-item/ordered-item.component.html"),
            styles: [__webpack_require__(/*! ./ordered-item.component.scss */ "./src/app/components/ordered-item/ordered-item.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], OrderedItemComponent);
    return OrderedItemComponent;
}());



/***/ }),

/***/ "./src/app/components/ordered-item/ordered-item.module.ts":
/*!****************************************************************!*\
  !*** ./src/app/components/ordered-item/ordered-item.module.ts ***!
  \****************************************************************/
/*! exports provided: OrderedItemModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrderedItemModule", function() { return OrderedItemModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _material_material_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../material/material.module */ "./src/app/material/material.module.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");





var OrderedItemModule = /** @class */ (function () {
    function OrderedItemModule() {
    }
    OrderedItemModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _material_material_module__WEBPACK_IMPORTED_MODULE_3__["MaterialModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ReactiveFormsModule"]
            ],
            exports: [
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ReactiveFormsModule"],
                _material_material_module__WEBPACK_IMPORTED_MODULE_3__["MaterialModule"]
            ]
        })
    ], OrderedItemModule);
    return OrderedItemModule;
}());



/***/ }),

/***/ "./src/app/pages/sidePanel/my-orders/my-orders-routing.module.ts":
/*!***********************************************************************!*\
  !*** ./src/app/pages/sidePanel/my-orders/my-orders-routing.module.ts ***!
  \***********************************************************************/
/*! exports provided: MyOrdersPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyOrdersPageRoutingModule", function() { return MyOrdersPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _my_orders_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./my-orders.page */ "./src/app/pages/sidePanel/my-orders/my-orders.page.ts");




var routes = [
    {
        path: '',
        component: _my_orders_page__WEBPACK_IMPORTED_MODULE_3__["MyOrdersPage"]
    }
];
var MyOrdersPageRoutingModule = /** @class */ (function () {
    function MyOrdersPageRoutingModule() {
    }
    MyOrdersPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], MyOrdersPageRoutingModule);
    return MyOrdersPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/pages/sidePanel/my-orders/my-orders.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/sidePanel/my-orders/my-orders.module.ts ***!
  \***************************************************************/
/*! exports provided: MyOrdersPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyOrdersPageModule", function() { return MyOrdersPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _my_orders_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./my-orders-routing.module */ "./src/app/pages/sidePanel/my-orders/my-orders-routing.module.ts");
/* harmony import */ var _my_orders_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./my-orders.page */ "./src/app/pages/sidePanel/my-orders/my-orders.page.ts");
/* harmony import */ var src_app_components_ordered_item_ordered_item_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/components/ordered-item/ordered-item.component */ "./src/app/components/ordered-item/ordered-item.component.ts");
/* harmony import */ var src_app_components_ordered_item_ordered_item_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/components/ordered-item/ordered-item.module */ "./src/app/components/ordered-item/ordered-item.module.ts");









var MyOrdersPageModule = /** @class */ (function () {
    function MyOrdersPageModule() {
    }
    MyOrdersPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _my_orders_routing_module__WEBPACK_IMPORTED_MODULE_5__["MyOrdersPageRoutingModule"],
                src_app_components_ordered_item_ordered_item_module__WEBPACK_IMPORTED_MODULE_8__["OrderedItemModule"]
            ],
            declarations: [_my_orders_page__WEBPACK_IMPORTED_MODULE_6__["MyOrdersPage"], src_app_components_ordered_item_ordered_item_component__WEBPACK_IMPORTED_MODULE_7__["OrderedItemComponent"]],
            exports: [src_app_components_ordered_item_ordered_item_component__WEBPACK_IMPORTED_MODULE_7__["OrderedItemComponent"], src_app_components_ordered_item_ordered_item_module__WEBPACK_IMPORTED_MODULE_8__["OrderedItemModule"]]
        })
    ], MyOrdersPageModule);
    return MyOrdersPageModule;
}());



/***/ }),

/***/ "./src/app/pages/sidePanel/my-orders/my-orders.page.scss":
/*!***************************************************************!*\
  !*** ./src/app/pages/sidePanel/my-orders/my-orders.page.scss ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3NpZGVQYW5lbC9teS1vcmRlcnMvbXktb3JkZXJzLnBhZ2Uuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/sidePanel/my-orders/my-orders.page.ts":
/*!*************************************************************!*\
  !*** ./src/app/pages/sidePanel/my-orders/my-orders.page.ts ***!
  \*************************************************************/
/*! exports provided: MyOrdersPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyOrdersPage", function() { return MyOrdersPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_order_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/order.service */ "./src/app/services/order.service.ts");
/* harmony import */ var src_app_global__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/global */ "./src/app/global.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");






var MyOrdersPage = /** @class */ (function () {
    function MyOrdersPage(orderService, router, toastController) {
        this.orderService = orderService;
        this.router = router;
        this.toastController = toastController;
        this.myOrders = [];
        this.globalVariable = src_app_global__WEBPACK_IMPORTED_MODULE_3__["Global"];
        this.showOrders = false;
    }
    MyOrdersPage.prototype.ngOnInit = function () {
        if (this.globalVariable.loggedIn) {
            console.log('bla bla in my-orders');
            this.getOrderByUserId();
        }
        else {
            this.presentToast('Please login first to view your orders.');
            this.router.navigateByUrl("/tabs/login");
        }
    };
    MyOrdersPage.prototype.presentToast = function (toastMessage) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var toast;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastController.create({
                            message: toastMessage,
                            duration: 2000
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    MyOrdersPage.prototype.getOrderByUserId = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _a;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_b) {
                switch (_b.label) {
                    case 0:
                        // this.myOrders = null;
                        this.showOrders = false;
                        if (!this.globalVariable.loggedIn) return [3 /*break*/, 2];
                        console.log('here ' + this.globalVariable.loggedInUser.id);
                        _a = this;
                        return [4 /*yield*/, this.orderService.getOrderByUserId(4)];
                    case 1:
                        _a.myOrders = _b.sent();
                        console.log(this.myOrders);
                        if (this.myOrders.length > 0) {
                            this.showOrders = true;
                        }
                        else {
                            this.error = 'Something bad happened in getOrderByUserId';
                        }
                        _b.label = 2;
                    case 2: return [2 /*return*/];
                }
            });
        });
    };
    MyOrdersPage.ctorParameters = function () { return [
        { type: src_app_services_order_service__WEBPACK_IMPORTED_MODULE_2__["OrderService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"] }
    ]; };
    MyOrdersPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-my-orders',
            template: __webpack_require__(/*! raw-loader!./my-orders.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/sidePanel/my-orders/my-orders.page.html"),
            styles: [__webpack_require__(/*! ./my-orders.page.scss */ "./src/app/pages/sidePanel/my-orders/my-orders.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_order_service__WEBPACK_IMPORTED_MODULE_2__["OrderService"], _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"]])
    ], MyOrdersPage);
    return MyOrdersPage;
}());



/***/ })

}]);
//# sourceMappingURL=sidePanel-my-orders-my-orders-module-es5.js.map