(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["sidePanel-contact-us-contact-us-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/sidePanel/contact-us/contact-us.page.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/sidePanel/contact-us/contact-us.page.html ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>ContactUs</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"myContainer justify-content-center text-center\">\n    <ion-row>\n          <img class=\"img\" src=\"../../../../assets/images/get-to-know-us.jpg\">\n    </ion-row>\n    <ion-row>\n          <div class=\"col\">\n            <b class=\"copyright\">We are available 24/7 at +91 8759661054 </b> \n          </div>\n          <img class=\"img\" src=\"../../../../assets/images/contact-us.png\">\n      </ion-row>\n    <ion-row class=\"bg-secondary text-white\">\n        <b class=\"copyright\">&copy; 2019 The Flying Basket </b> \n    </ion-row>\n    <ion-row class=\"bg-secondary text-white\">\n          <b> &nbsp; All rights reserved.</b>\n    </ion-row>\n  </div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/sidePanel/contact-us/contact-us-routing.module.ts":
/*!*************************************************************************!*\
  !*** ./src/app/pages/sidePanel/contact-us/contact-us-routing.module.ts ***!
  \*************************************************************************/
/*! exports provided: ContactUsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContactUsPageRoutingModule", function() { return ContactUsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _contact_us_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./contact-us.page */ "./src/app/pages/sidePanel/contact-us/contact-us.page.ts");




const routes = [
    {
        path: '',
        component: _contact_us_page__WEBPACK_IMPORTED_MODULE_3__["ContactUsPage"]
    }
];
let ContactUsPageRoutingModule = class ContactUsPageRoutingModule {
};
ContactUsPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ContactUsPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/sidePanel/contact-us/contact-us.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/pages/sidePanel/contact-us/contact-us.module.ts ***!
  \*****************************************************************/
/*! exports provided: ContactUsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContactUsPageModule", function() { return ContactUsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _contact_us_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./contact-us-routing.module */ "./src/app/pages/sidePanel/contact-us/contact-us-routing.module.ts");
/* harmony import */ var _contact_us_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./contact-us.page */ "./src/app/pages/sidePanel/contact-us/contact-us.page.ts");







let ContactUsPageModule = class ContactUsPageModule {
};
ContactUsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _contact_us_routing_module__WEBPACK_IMPORTED_MODULE_5__["ContactUsPageRoutingModule"]
        ],
        declarations: [_contact_us_page__WEBPACK_IMPORTED_MODULE_6__["ContactUsPage"]]
    })
], ContactUsPageModule);



/***/ }),

/***/ "./src/app/pages/sidePanel/contact-us/contact-us.page.scss":
/*!*****************************************************************!*\
  !*** ./src/app/pages/sidePanel/contact-us/contact-us.page.scss ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".copyright {\n  padding-top: 10px;\n}\n\n.img {\n  -o-object-fit: contain;\n     object-fit: contain;\n  padding: 2px;\n  max-width: 100%;\n  height: 400px;\n}\n\n.myContainer {\n  border: 2px solid black;\n}\n\n.header, .content {\n  margin-top: 10px;\n  margin-right: 10px;\n  margin-left: 10px;\n  margin-bottom: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9hcHBsZS9EZXNrdG9wL1Nob3BwaW5nL3RmYiB2Mi4wL3RoZWZseWluZ2Jhc2tldC9zcmMvYXBwL3BhZ2VzL3NpZGVQYW5lbC9jb250YWN0LXVzL2NvbnRhY3QtdXMucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9zaWRlUGFuZWwvY29udGFjdC11cy9jb250YWN0LXVzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGlCQUFBO0FDQ0o7O0FERUE7RUFDSSxzQkFBQTtLQUFBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxhQUFBO0FDQ0o7O0FERUE7RUFDSSx1QkFBQTtBQ0NKOztBREVBO0VBQ0ksZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7QUNDSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3NpZGVQYW5lbC9jb250YWN0LXVzL2NvbnRhY3QtdXMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvcHlyaWdodCB7XG4gICAgcGFkZGluZy10b3A6IDEwcHg7XG59XG5cbi5pbWcge1xuICAgIG9iamVjdC1maXQ6IGNvbnRhaW47IFxuICAgIHBhZGRpbmc6MnB4OyBcbiAgICBtYXgtd2lkdGg6MTAwJTsgXG4gICAgaGVpZ2h0OjQwMHB4OyBcbn1cblxuLm15Q29udGFpbmVyIHtcbiAgICBib3JkZXI6IDJweCBzb2xpZCBibGFjaztcbn1cblxuLmhlYWRlciwgLmNvbnRlbnQge1xuICAgIG1hcmdpbi10b3A6IDEwcHg7XG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XG59IiwiLmNvcHlyaWdodCB7XG4gIHBhZGRpbmctdG9wOiAxMHB4O1xufVxuXG4uaW1nIHtcbiAgb2JqZWN0LWZpdDogY29udGFpbjtcbiAgcGFkZGluZzogMnB4O1xuICBtYXgtd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogNDAwcHg7XG59XG5cbi5teUNvbnRhaW5lciB7XG4gIGJvcmRlcjogMnB4IHNvbGlkIGJsYWNrO1xufVxuXG4uaGVhZGVyLCAuY29udGVudCB7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG59Il19 */"

/***/ }),

/***/ "./src/app/pages/sidePanel/contact-us/contact-us.page.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/sidePanel/contact-us/contact-us.page.ts ***!
  \***************************************************************/
/*! exports provided: ContactUsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContactUsPage", function() { return ContactUsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let ContactUsPage = class ContactUsPage {
    constructor() { }
    ngOnInit() {
    }
};
ContactUsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-contact-us',
        template: __webpack_require__(/*! raw-loader!./contact-us.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/sidePanel/contact-us/contact-us.page.html"),
        styles: [__webpack_require__(/*! ./contact-us.page.scss */ "./src/app/pages/sidePanel/contact-us/contact-us.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], ContactUsPage);



/***/ })

}]);
//# sourceMappingURL=sidePanel-contact-us-contact-us-module-es2015.js.map