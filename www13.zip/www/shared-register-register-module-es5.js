(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["shared-register-register-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/shared/register/register.page.html":
/*!************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/shared/register/register.page.html ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>register</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <form  #form=\"ngForm\" [formGroup]=\"signupForm\">\n    <ion-grid>\n      <ion-row justify-content-center>\n        <ion-col align-self-center size-md=\"6\" size-lg=\"5\" size-xs=\"12\">\n          <div text-center>\n            <h3>Create your account!</h3>\n          </div>\n          <div padding>\n            <ion-item>\n              <ion-input  formControlName=\"name\" name=\"name\" type=\"text\" placeholder=\"Name\" ngModel required></ion-input>\n            </ion-item>\n            <div\n                 *ngIf=\"signupForm.controls.name.invalid && (signupForm.controls.name.dirty || signupForm.controls.name.touched)\"\n                 class=\"alert alert-danger\">\n                 <div *ngIf=\"signupForm.controls.name.errors.required\">\n                   Name is required.\n                 </div>\n                 <div *ngIf=\"signupForm.controls.name.errors.minlength\">\n                   Name must be at least 4 characters long.\n                 </div>\n                 <div *ngIf=\"signupForm.controls.name.errors.pattern\">\n                   Name must be valid.\n                 </div>\n               </div>\n            <ion-item>\n              <ion-input formControlName=\"email\" name=\"email\" type=\"email\" placeholder=\"your@email.com\" ngModel required></ion-input>\n            </ion-item>\n            <div\n                 *ngIf=\"signupForm.controls.email.invalid && (signupForm.controls.email.dirty || signupForm.controls.email.touched)\"\n                 class=\"alert alert-danger\">\n                 <div *ngIf=\"signupForm.controls.email.errors.required\">\n                   Email is required.\n                 </div>\n                 <div *ngIf=\"signupForm.controls.email.errors.pattern\">\n                   Email must be valid.\n                 </div>\n               </div>\n            <ion-item>\n              <ion-input name=\"contactNo\" formControlName=\"contactNo\" type=\"number\" placeholder=\"9999999999\" ngModel required></ion-input>\n            </ion-item>\n            <div\n                 *ngIf=\"signupForm.controls.contactNo.invalid && (signupForm.controls.contactNo.dirty || signupForm.controls.contactNo.touched)\"\n                 class=\"alert alert-danger\">\n                 <div *ngIf=\"signupForm.controls.contactNo.errors.required\">\n                   Contact number is required.\n                 </div>\n                 <div *ngIf=\"signupForm.controls.contactNo.errors.pattern\">\n                   Contact No must be of 10 digit and valid.\n                 </div>\n               </div>\n            <ion-item>\n              <ion-input name=\"password\" formControlName=\"password\" type=\"password\" placeholder=\"Password\" ngModel required></ion-input>\n            </ion-item>\n            <div\n                 *ngIf=\"signupForm.controls.password.invalid && (signupForm.controls.password.dirty || signupForm.controls.password.touched)\"\n                 class=\"alert alert-danger\">\n                 <div *ngIf=\"signupForm.controls.password.errors.required\">\n                   Password is required.\n                 </div>\n                 <div *ngIf=\"signupForm.controls.password.errors.pattern\">\n                   Password should be atleast 6 characters long and of valid characters.\n                 </div>\n               </div>\n          </div>\n          <div padding>\n            <ion-button  size=\"large\" type=\"submit\" [disabled]=\"form.invalid\" (click)=\"signup()\" expand=\"block\">Register</ion-button>\n          </div>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </form>\n  <div text-center>\n    If you already have an account, please <a (click)=\"openLogin()\" style=\"color: red; text-decoration: underline;\">\n      login</a> here!\n      </div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/shared/register/register-routing.module.ts":
/*!******************************************************************!*\
  !*** ./src/app/pages/shared/register/register-routing.module.ts ***!
  \******************************************************************/
/*! exports provided: RegisterPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterPageRoutingModule", function() { return RegisterPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./register.page */ "./src/app/pages/shared/register/register.page.ts");




var routes = [
    {
        path: '',
        component: _register_page__WEBPACK_IMPORTED_MODULE_3__["RegisterPage"]
    }
];
var RegisterPageRoutingModule = /** @class */ (function () {
    function RegisterPageRoutingModule() {
    }
    RegisterPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], RegisterPageRoutingModule);
    return RegisterPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/pages/shared/register/register.module.ts":
/*!**********************************************************!*\
  !*** ./src/app/pages/shared/register/register.module.ts ***!
  \**********************************************************/
/*! exports provided: RegisterPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterPageModule", function() { return RegisterPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _register_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./register-routing.module */ "./src/app/pages/shared/register/register-routing.module.ts");
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./register.page */ "./src/app/pages/shared/register/register.page.ts");







var RegisterPageModule = /** @class */ (function () {
    function RegisterPageModule() {
    }
    RegisterPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _register_routing_module__WEBPACK_IMPORTED_MODULE_5__["RegisterPageRoutingModule"]
            ],
            declarations: [_register_page__WEBPACK_IMPORTED_MODULE_6__["RegisterPage"]]
        })
    ], RegisterPageModule);
    return RegisterPageModule;
}());



/***/ }),

/***/ "./src/app/pages/shared/register/register.page.scss":
/*!**********************************************************!*\
  !*** ./src/app/pages/shared/register/register.page.scss ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-item {\n  --background: #3cdb2e9d;\n  --color: rgb(0, 0, 0);\n}\n\nion-button {\n  --background: #3cdb2ed8;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9hcHBsZS9EZXNrdG9wL1Nob3BwaW5nL3RmYiB2Mi4wL3RoZWZseWluZ2Jhc2tldC9zcmMvYXBwL3BhZ2VzL3NoYXJlZC9yZWdpc3Rlci9yZWdpc3Rlci5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL3NoYXJlZC9yZWdpc3Rlci9yZWdpc3Rlci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSx1QkFBQTtFQUNBLHFCQUFBO0FDQ0o7O0FEQ0E7RUFDSSx1QkFBQTtBQ0VKIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvc2hhcmVkL3JlZ2lzdGVyL3JlZ2lzdGVyLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1pdGVte1xuICAgIC0tYmFja2dyb3VuZDogIzNjZGIyZTlkO1xuICAgIC0tY29sb3I6IHJnYigwLCAwLCAwKTtcbn1cbmlvbi1idXR0b257XG4gICAgLS1iYWNrZ3JvdW5kOiAjM2NkYjJlZDg7XG59IiwiaW9uLWl0ZW0ge1xuICAtLWJhY2tncm91bmQ6ICMzY2RiMmU5ZDtcbiAgLS1jb2xvcjogcmdiKDAsIDAsIDApO1xufVxuXG5pb24tYnV0dG9uIHtcbiAgLS1iYWNrZ3JvdW5kOiAjM2NkYjJlZDg7XG59Il19 */"

/***/ }),

/***/ "./src/app/pages/shared/register/register.page.ts":
/*!********************************************************!*\
  !*** ./src/app/pages/shared/register/register.page.ts ***!
  \********************************************************/
/*! exports provided: RegisterPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterPage", function() { return RegisterPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_app_services_login_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/login.service */ "./src/app/services/login.service.ts");
/* harmony import */ var src_app_global__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/global */ "./src/app/global.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/storage.service */ "./src/app/services/storage.service.ts");








var RegisterPage = /** @class */ (function () {
    function RegisterPage(router, toastController, loginService, storage) {
        this.router = router;
        this.toastController = toastController;
        this.loginService = loginService;
        this.storage = storage;
        this.signupForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroup"]({
            name: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required,
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(4),
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern('[a-zA-Z ]+')
            ]),
            email: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required,
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern('[a-z0-9._]+@[a-z]+.com|.co.in')
            ]),
            contactNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required,
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern('[6-9][0-9]{9}')
            ]),
            password: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required,
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern('[A-Za-z0-9!@#$%^&*()-=_+]{6,20}')
            ])
        });
    }
    RegisterPage.prototype.ngOnInit = function () {
    };
    RegisterPage.prototype.presentToast = function (toastMessage) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var toast;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastController.create({
                            message: toastMessage,
                            duration: 2000
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    RegisterPage.prototype.signup = function () {
        var _this = this;
        this.loginService.signup(this.signupForm.value).subscribe(function (res) {
            _this.user = res;
            if (_this.user.message == null) {
                src_app_global__WEBPACK_IMPORTED_MODULE_5__["Global"].loggedIn = true;
                src_app_global__WEBPACK_IMPORTED_MODULE_5__["Global"].loggedInUser = _this.user;
                _this.storage.saveInLocal('loggedInUser', _this.user);
                _this.presentToast('Welcome ' + src_app_global__WEBPACK_IMPORTED_MODULE_5__["Global"].loggedInUser.name);
                _this.router.navigate(['']);
            }
            else {
                _this.presentToast(_this.user.message);
            }
        }, function (err) {
            _this.error = err;
        });
    };
    RegisterPage.prototype.openLogin = function () {
        this.router.navigateByUrl("/tabs/login");
    };
    RegisterPage.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] },
        { type: src_app_services_login_service__WEBPACK_IMPORTED_MODULE_4__["LoginService"] },
        { type: src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_7__["StorageService"] }
    ]; };
    RegisterPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-register',
            template: __webpack_require__(/*! raw-loader!./register.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/shared/register/register.page.html"),
            styles: [__webpack_require__(/*! ./register.page.scss */ "./src/app/pages/shared/register/register.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"],
            src_app_services_login_service__WEBPACK_IMPORTED_MODULE_4__["LoginService"], src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_7__["StorageService"]])
    ], RegisterPage);
    return RegisterPage;
}());



/***/ })

}]);
//# sourceMappingURL=shared-register-register-module-es5.js.map