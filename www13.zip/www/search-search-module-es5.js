(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["search-search-module"],{

/***/ "./node_modules/ionic4-auto-complete/fesm5/ionic4-auto-complete.js":
/*!*************************************************************************!*\
  !*** ./node_modules/ionic4-auto-complete/fesm5/ionic4-auto-complete.js ***!
  \*************************************************************************/
/*! exports provided: AutoCompleteComponent, AutoCompleteModule, AutoCompleteOptions, BoldPrefix */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AutoCompleteComponent", function() { return AutoCompleteComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AutoCompleteModule", function() { return AutoCompleteModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AutoCompleteOptions", function() { return AutoCompleteOptions; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BoldPrefix", function() { return BoldPrefix; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");








var AutoCompleteOptions = /** @class */ (function () {
    function AutoCompleteOptions() {
        this.animated = false;
        this.color = null;
        this.autocomplete = 'off';
        this.autocorrect = 'off';
        this.cancelButtonIcon = 'arrow-round-back';
        this.cancelButtonText = 'Cancel';
        this.clearIcon = 'close-circle';
        this.clearInput = false;
        this.clearOnEdit = false;
        this.debounce = 250;
        this.mode = 'md';
        this.noItems = 'No items found.';
        this.placeholder = 'Search';
        this.searchIcon = 'search';
        this.showCancelButton = false;
        this.spellcheck = 'off';
        this.type = 'search';
        this.value = '';
    }
    return AutoCompleteOptions;
}());

var AutoCompleteComponent = /** @class */ (function () {
    /**
     * Create a new instance
     */
    function AutoCompleteComponent() {
        this.enableBrowserAutoComplete = false;
        this.clearInvalidInput = true;
        this.disabled = false;
        this.exclude = [];
        this.frontIcon = false;
        this.hideListOnSelection = true;
        this.location = 'auto';
        this.maxResults = 8;
        this.maxSelected = null;
        this.multi = false;
        this.name = '';
        this.options = new AutoCompleteOptions();
        this.removeButtonClasses = '';
        this.removeButtonColor = 'primary';
        this.removeButtonIcon = 'close-circle';
        this.removeButtonSlot = 'end';
        this.removeDuplicateSuggestions = true;
        this.onTouchedCallback = false;
        this.onChangeCallback = false;
        this.hasFocus = false;
        this.isLoading = false;
        this.showListChanged = false;
        this.autoBlur = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.autoFocus = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.blur = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.focus = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.ionAutoInput = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.itemsChange = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.itemsHidden = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.itemRemoved = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.itemSelected = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.itemsShown = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.modelChange = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.keyword = '';
        this.suggestions = [];
        this._showList = false;
        this.options = new AutoCompleteOptions();
        this.defaultOpts = new AutoCompleteOptions();
        this.selected = [];
    }
    AutoCompleteComponent_1 = AutoCompleteComponent;
    Object.defineProperty(AutoCompleteComponent.prototype, "model", {
        get: function () {
            var model = this.selected;
            if (!this.multi && typeof this.selected.length !== 'undefined') {
                if (this.selected.length === 0) {
                    model = null;
                }
                else {
                    model = this.selected[0];
                }
            }
            return model;
        },
        set: function (selected) {
            if (typeof selected !== 'undefined') {
                this.selected = selected;
                this.keyword = this.getLabel(selected);
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AutoCompleteComponent.prototype, "eager", {
        set: function (eager) {
            if (eager) {
                this.getItems(null, false);
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AutoCompleteComponent.prototype, "showList", {
        get: function () {
            return this._showList;
        },
        set: function (value) {
            if (this._showList === value) {
                return;
            }
            this._showList = value;
            this.showListChanged = true;
        },
        enumerable: true,
        configurable: true
    });
    /**
     *
     */
    AutoCompleteComponent.prototype.ngAfterViewChecked = function () {
        if (this.showListChanged) {
            this.showListChanged = false;
            this.showList ? this.itemsShown.emit() : this.itemsHidden.emit();
        }
    };
    AutoCompleteComponent.prototype.ngDoCheck = function () {
        if (!this.hasFocus) {
            if (this.clearInvalidInput && (this.selected === null || this.multi)) {
                if (this.keyword !== '') {
                    this.keyword = '';
                }
                if (this.inputElem && this.inputElem.nativeElement) {
                    if (this.inputElem.nativeElement.children && this.inputElem.nativeElement.children.length !== 0) {
                        if (this.inputElem.nativeElement.children[0].children && this.inputElem.nativeElement.children[0].children.length !== 0) {
                            if (this.inputElem.nativeElement.children[0].children[0].value) {
                                this.inputElem.nativeElement.children[0].children[0].value = '';
                            }
                        }
                    }
                }
                if (this.searchbarElem && this.searchbarElem.nativeElement) {
                    if (this.searchbarElem.nativeElement.children && this.searchbarElem.nativeElement.children.length !== 0) {
                        if (this.searchbarElem.nativeElement.children[0].children && this.searchbarElem.nativeElement.children[0].children.length !== 0) {
                            if (this.searchbarElem.nativeElement.children[0].children[0].value) {
                                this.searchbarElem.nativeElement.children[0].children[0].value = '';
                            }
                        }
                    }
                }
            }
        }
    };
    /**
     * Handle document click
     *
     * @param event
     *
     * @private
     */
    AutoCompleteComponent.prototype.documentClickHandler = function (event) {
        if ((this.searchbarElem && this.searchbarElem.nativeElement && !this.searchbarElem.nativeElement.contains(event.target))
            ||
                (!this.inputElem && this.inputElem.nativeElement && this.inputElem.nativeElement.contains(event.target))) {
            this.hideItemList();
        }
    };
    /**
     * Get value from form
     *
     * @param selection
     *
     * @private
     */
    AutoCompleteComponent.prototype.getFormValue = function (selection) {
        if (selection == null || typeof this.dataProvider === 'function') {
            return null;
        }
        var attr = this.dataProvider.formValueAttribute == null ?
            this.dataProvider.labelAttribute : this.dataProvider.formValueAttribute;
        if (typeof selection === 'object' && attr) {
            return selection[attr];
        }
        return selection;
    };
    /**
     * Get element's position on screen
     *
     * @param el
     *
     * @private
     */
    AutoCompleteComponent.prototype._getPosition = function (el) {
        var xPos = 0;
        var yPos = 0;
        while (el) {
            if (el.tagName === 'BODY') {
                var xScroll = el.scrollLeft || document.documentElement.scrollLeft;
                var yScroll = el.scrollTop || document.documentElement.scrollTop;
                xPos += (el.offsetLeft - xScroll + el.clientLeft);
                yPos += (el.offsetTop - yScroll + el.clientTop);
            }
            else {
                xPos += (el.offsetLeft - el.scrollLeft + el.clientLeft);
                yPos += (el.offsetTop - el.scrollTop + el.clientTop);
            }
            el = el.offsetParent;
        }
        return {
            x: xPos,
            y: yPos
        };
    };
    /**
     * Clear current input value
     *
     * @param hideItemList
     */
    AutoCompleteComponent.prototype.clearValue = function (hideItemList) {
        if (hideItemList === void 0) { hideItemList = false; }
        this.keyword = '';
        this.selection = null;
        this.formValue = null;
        if (hideItemList) {
            this.hideItemList();
        }
        return;
    };
    /**
     * Get items for auto-complete
     *
     * @param event
     * @param show
     */
    AutoCompleteComponent.prototype.getItems = function (event, show) {
        var _this = this;
        if (this.promise) {
            clearTimeout(this.promise);
        }
        this.promise = setTimeout(function () {
            if (event) {
                _this.keyword = event.detail.target.value;
            }
            var result;
            if (_this.showResultsFirst && _this.keyword.trim() === '') {
                _this.keyword = '';
            }
            result = (typeof _this.dataProvider === 'function') ?
                _this.dataProvider(_this.keyword) : _this.dataProvider.getResults(_this.keyword);
            if (result instanceof rxjs__WEBPACK_IMPORTED_MODULE_5__["Subject"]) {
                result = result.asObservable();
            }
            if (result instanceof Promise) {
                result = Object(rxjs__WEBPACK_IMPORTED_MODULE_5__["from"])(result);
            }
            if (result instanceof rxjs__WEBPACK_IMPORTED_MODULE_5__["Observable"]) {
                _this.isLoading = true;
                result.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["finalize"])(function () {
                    _this.isLoading = false;
                })).subscribe(function (results) {
                    _this.setSuggestions(results, show);
                }, function (error) { return console.error(error); });
            }
            else {
                _this.setSuggestions(result, show);
            }
            _this.ionAutoInput.emit(_this.keyword);
        }, this.options.debounce);
    };
    /**
     * Get an item's label
     *
     * @param selection
     */
    AutoCompleteComponent.prototype.getLabel = function (selection) {
        if (selection == null || typeof this.dataProvider === 'function') {
            return '';
        }
        var attr = this.dataProvider.formValueAttribute == null ?
            this.dataProvider.labelAttribute : this.dataProvider.formValueAttribute;
        var value = selection;
        if (this.dataProvider.getItemLabel) {
            value = this.dataProvider.getItemLabel(value);
        }
        if (!this.multi && typeof value !== 'undefined' && Object.prototype.toString.call(value) === '[object Array]') {
            if (value.length === 0) {
                return '';
            }
            else {
                value = value[0];
            }
        }
        if (typeof value === 'object' && attr) {
            return value[attr] || '';
        }
        return value || '';
    };
    /**
     * Get current selection
     */
    AutoCompleteComponent.prototype.getSelection = function () {
        if (this.multi) {
            return this.selection;
        }
        else {
            return this.selected;
        }
    };
    /**
     * Get menu style
     */
    AutoCompleteComponent.prototype.getStyle = function () {
        var location = this.location;
        if (this.location === 'auto') {
            var elementY = this._getPosition(this.searchbarElem.nativeElement).y;
            var windowY = window.innerHeight;
            if (elementY > windowY - elementY) {
                location = 'top';
            }
            else {
                location = 'bottom';
            }
        }
        if (location === 'bottom') {
            return {};
        }
        else {
            return {
                'bottom': '37px'
            };
        }
    };
    /**
     * Get current input value
     */
    AutoCompleteComponent.prototype.getValue = function () {
        return this.formValue;
    };
    /**
     * Handle tap
     *
     * @param event
     */
    AutoCompleteComponent.prototype.handleTap = function (event) {
        if (this.showResultsFirst || this.keyword.length > 0) {
            this.getItems();
        }
    };
    /**
     * Handle tap when selecting an item
     *
     * @param $event
     * @param suggestion
     */
    AutoCompleteComponent.prototype.handleSelectTap = function ($event, suggestion) {
        this.selectItem(suggestion);
        if ($event.srcEvent) {
            if ($event.srcEvent.stopPropagation) {
                $event.srcEvent.stopPropagation();
            }
            if ($event.srcEvent.preventDefault) {
                $event.srcEvent.preventDefault();
            }
        }
        else if ($event.preventDefault) {
            $event.preventDefault();
        }
        return false;
    };
    /**
     * Hide item list
     */
    AutoCompleteComponent.prototype.hideItemList = function () {
        this.showList = this.alwaysShowList;
    };
    /**
     * Fired when the input focused
     */
    AutoCompleteComponent.prototype.onFocus = function (event) {
        this.hasFocus = true;
        this.getItems();
        event = this._reflectName(event);
        this.autoFocus.emit(event);
        this.focus.emit(event);
    };
    /**
     * Fired when the input focused
     */
    AutoCompleteComponent.prototype.onBlur = function (event) {
        this.hasFocus = false;
        event = this._reflectName(event);
        this.autoBlur.emit(event);
        this.blur.emit(event);
    };
    AutoCompleteComponent.prototype._reflectName = function (event) {
        if (typeof event.srcElement.attributes['ng-reflect-name'] === 'object') {
            event.srcElement.name = event.srcElement.attributes['ng-reflect-name'].value;
        }
        return event;
    };
    /**
     * Register onChangeCallback
     *
     * @param fn
     */
    AutoCompleteComponent.prototype.registerOnChange = function (fn) {
        this.onChangeCallback = fn;
    };
    /**
     * Register onTouchedCallback
     *
     * @param fn
     */
    AutoCompleteComponent.prototype.registerOnTouched = function (fn) {
        this.onTouchedCallback = fn;
    };
    /**
     * Remove already selected suggestions
     *
     * @param suggestions
     */
    AutoCompleteComponent.prototype.removeDuplicates = function (suggestions) {
        var selectedCount = this.selected ? this.selected.length : 0;
        var suggestionCount = suggestions.length;
        for (var i = 0; i < selectedCount; i++) {
            var selectedLabel = this.getLabel(this.selected[i]);
            for (var j = 0; j < suggestionCount; j++) {
                var suggestedLabel = this.getLabel(suggestions[j]);
                if (selectedLabel === suggestedLabel) {
                    suggestions.splice(j, 1);
                }
            }
        }
        return suggestions;
    };
    AutoCompleteComponent.prototype.removeExcluded = function (suggestions) {
        var excludedCount = this.exclude.length;
        for (var i = 0; i < excludedCount; i++) {
            var excludeLabel = this.exclude[i];
            if (typeof excludeLabel === 'object') {
                excludeLabel = this.getLabel(excludeLabel);
            }
            var suggestionCount = suggestions.length;
            for (var j = 0; j < suggestionCount; j++) {
                var suggestedLabel = this.getLabel(suggestions[j]);
                if (excludeLabel === suggestedLabel) {
                    suggestions.splice(j, 1);
                    break;
                }
            }
        }
        return suggestions;
    };
    /**
     * Remove item from selected
     *
     * @param selection
     * @param notify?
     */
    AutoCompleteComponent.prototype.removeItem = function (selection, notify) {
        var count = this.selected ? this.selected.length : 0;
        for (var i = 0; i < count; i++) {
            var item = this.selected[i];
            var selectedLabel = this.getLabel(selection);
            var itemLabel = this.getLabel(item);
            if (selectedLabel === itemLabel) {
                this.selected.splice(i, 1);
            }
        }
        notify = typeof notify === 'undefined' ? true : notify;
        if (notify) {
            this.itemRemoved.emit(selection);
            this.itemsChange.emit(this.selected);
        }
        this.modelChange.emit(this.selected);
    };
    /**
     * Select item from list
     *
     * @param selection
     **/
    AutoCompleteComponent.prototype.selectItem = function (selection) {
        this.keyword = this.getLabel(selection);
        this.formValue = this.getFormValue(selection);
        this.hideItemList();
        this.updateModel(this.formValue);
        if (this.hideListOnSelection) {
            this.hideItemList();
        }
        if (this.multi) {
            if (this.maxSelected === null || this.selected.length <= this.maxSelected) {
                this.clearValue();
                this.selected.push(selection);
                this.itemsChange.emit(this.selected);
            }
            else {
                return;
            }
        }
        else {
            this.selection = selection;
            this.selected = [selection];
            this.itemsChange.emit(selection);
        }
        this.itemSelected.emit(selection);
        this.modelChange.emit(this.selected);
    };
    /**
     * Set focus of searchbar
     */
    AutoCompleteComponent.prototype.setFocus = function () {
        if (this.searchbarElem) {
            this.searchbarElem.nativeElement.setFocus();
        }
    };
    /**
     * Set suggestions
     *
     * @param suggestions
     * @param show
     */
    AutoCompleteComponent.prototype.setSuggestions = function (suggestions, show) {
        if (this.removeDuplicateSuggestions) {
            suggestions = this.removeDuplicates(suggestions);
            suggestions = this.removeExcluded(suggestions);
        }
        this.suggestions = suggestions;
        if (show || typeof show === 'undefined') {
            this.showItemList();
        }
    };
    /**
     * Set current input value
     *
     * @param selection
     */
    AutoCompleteComponent.prototype.setValue = function (selection) {
        this.formValue = this.getFormValue(selection);
        this.keyword = this.getLabel(selection);
        return;
    };
    /**
     * Show item list
     */
    AutoCompleteComponent.prototype.showItemList = function () {
        this.showList = true;
    };
    /**
     * Update the model
     */
    AutoCompleteComponent.prototype.updateModel = function (enteredText) {
        if (enteredText !== this.formValue) {
            this.formValue = enteredText;
            if (!this.multi) {
                this.selected = null;
            }
        }
        if (this.onChangeCallback) {
            this.onChangeCallback(this.formValue);
        }
        this.modelChange.emit(this.selected);
    };
    /**
     * Write value
     *
     * @param value
     */
    AutoCompleteComponent.prototype.writeValue = function (value) {
        if (value !== this.selection) {
            this.selection = value || null;
            this.formValue = this.getFormValue(this.selection);
            this.keyword = this.getLabel(this.selection);
        }
    };
    var AutoCompleteComponent_1;
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
    ], AutoCompleteComponent.prototype, "alwaysShowList", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
    ], AutoCompleteComponent.prototype, "enableBrowserAutoComplete", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
    ], AutoCompleteComponent.prototype, "clearInvalidInput", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
    ], AutoCompleteComponent.prototype, "dataProvider", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
    ], AutoCompleteComponent.prototype, "disabled", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
    ], AutoCompleteComponent.prototype, "emptyTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
    ], AutoCompleteComponent.prototype, "exclude", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
    ], AutoCompleteComponent.prototype, "frontIcon", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
    ], AutoCompleteComponent.prototype, "hideListOnSelection", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
    ], AutoCompleteComponent.prototype, "keyword", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
    ], AutoCompleteComponent.prototype, "location", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
    ], AutoCompleteComponent.prototype, "maxResults", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
    ], AutoCompleteComponent.prototype, "maxSelected", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
    ], AutoCompleteComponent.prototype, "multi", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
    ], AutoCompleteComponent.prototype, "name", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
    ], AutoCompleteComponent.prototype, "options", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
    ], AutoCompleteComponent.prototype, "removeButtonClasses", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
    ], AutoCompleteComponent.prototype, "removeButtonColor", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
    ], AutoCompleteComponent.prototype, "removeButtonIcon", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
    ], AutoCompleteComponent.prototype, "removeButtonSlot", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
    ], AutoCompleteComponent.prototype, "removeDuplicateSuggestions", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
    ], AutoCompleteComponent.prototype, "selectionTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
    ], AutoCompleteComponent.prototype, "showResultsFirst", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
    ], AutoCompleteComponent.prototype, "template", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
    ], AutoCompleteComponent.prototype, "useIonInput", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
    ], AutoCompleteComponent.prototype, "model", null);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()
    ], AutoCompleteComponent.prototype, "modelChange", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
    ], AutoCompleteComponent.prototype, "eager", null);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()
    ], AutoCompleteComponent.prototype, "blur", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()
    ], AutoCompleteComponent.prototype, "autoFocus", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()
    ], AutoCompleteComponent.prototype, "autoBlur", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()
    ], AutoCompleteComponent.prototype, "focus", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()
    ], AutoCompleteComponent.prototype, "ionAutoInput", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()
    ], AutoCompleteComponent.prototype, "itemsChange", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()
    ], AutoCompleteComponent.prototype, "itemsHidden", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()
    ], AutoCompleteComponent.prototype, "itemRemoved", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()
    ], AutoCompleteComponent.prototype, "itemSelected", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()
    ], AutoCompleteComponent.prototype, "itemsShown", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('searchbarElem', {
            read: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"],
            static: false
        })
    ], AutoCompleteComponent.prototype, "searchbarElem", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('inputElem', {
            read: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"],
            static: false
        })
    ], AutoCompleteComponent.prototype, "inputElem", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostListener"])('document:click', ['$event'])
    ], AutoCompleteComponent.prototype, "documentClickHandler", null);
    AutoCompleteComponent = AutoCompleteComponent_1 = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            providers: [
                {
                    provide: _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"],
                    useExisting: AutoCompleteComponent_1,
                    multi: true
                }
            ],
            selector: 'ion-auto-complete',
            template: "<ng-template #defaultSelection\n             let-attrs=\"attrs\">\n    <ion-chip class=\"{{ attrs.removeButtonClasses }}\"\n              [color]=\"attrs.removeButtonColor\"\n              [outline]=\"true\">\n        <ion-icon *ngIf=\"frontIcon\"\n                  [name]=\"frontIcon\"\n                  [slot]=\"'start'\"\n                  color=\"primary\"></ion-icon>\n\n        <ion-label>{{ attrs.label }}</ion-label>\n\n        <ion-icon *ngIf=\"attrs.removeButtonIcon\"\n                  [name]=\"attrs.removeButtonIcon\"\n                  [slot]=\"attrs.removeButtonSlot\"></ion-icon>\n    </ion-chip>\n</ng-template>\n\n<div *ngIf=\"multi\">\n    <div *ngFor=\"let item of selected\"\n         class=\"selected-items\"\n         (click)=\"removeItem(item)\">\n        <ng-template [ngTemplateOutlet]=\"selectionTemplate || defaultSelection\"\n                     [ngTemplateOutletContext]=\"{\n                            attrs: {\n                              data:                item,\n                              label:               getLabel(item),\n                              removeButtonClasses: removeButtonClasses,\n                              removeButtonColor:   removeButtonColor,\n                              removeButtonIcon:    removeButtonIcon,\n                              removeButtonSlot:    removeButtonSlot\n                            }\n                         }\"></ng-template>\n    </div>\n</div>\n\n<ion-input #inputElem\n           [autocomplete]=\"enableBrowserAutoComplete ? 'on' : 'off'\"\n           [name]=\"name\"\n           (keyup)=\"getItems($event)\"\n           (tap)=\"handleTap($event)\"\n           [(ngModel)]=\"keyword\"\n           (ngModelChange)=\"updateModel($event)\"\n           [placeholder]=\"options.placeholder == null ? defaultOpts.placeholder : options.placeholder\"\n           [type]=\"options.type == null ? defaultOpts.type : options.type\"\n           [clearOnEdit]=\"options.clearOnEdit == null ? defaultOpts.clearOnEdit : options.clearOnEdit\"\n           [clearInput]=\"options.clearInput == null ? defaultOpts.clearInput : options.clearInput\"\n           [color]=\"options.color == null ? null : options.color\"\n           [mode]=\"options.mode == null ? defaultOpts.mode : options.mode\"\n           [disabled]=\"disabled || (this.maxSelected !== null && this.selected.length >= this.maxSelected)\"\n           [ngClass]=\"{ 'hidden': !useIonInput, 'loading': isLoading }\"\n           (ionFocus)=\"onFocus($event)\"\n           (ionBlur)=\"onBlur($event)\"></ion-input>\n\n<ion-searchbar #searchbarElem\n               [autocomplete]=\"enableBrowserAutoComplete ? 'on' : 'off'\"\n               [name]=\"name\"\n               [animated]=\"options.animated == null ? defaultOpts.animated : options.animated\"\n               (ionInput)=\"getItems($event)\"\n               (tap)=\"handleTap($event)\"\n               [(ngModel)]=\"keyword\"\n               (ngModelChange)=\"updateModel($event)\"\n               [cancelButtonIcon]=\"options.cancelButtonIcon == null ? defaultOpts.cancelButtonIcon : options.cancelButtonIcon\"\n               [cancelButtonText]=\"options.cancelButtonText == null ? defaultOpts.cancelButtonText : options.cancelButtonText\"\n               [clearIcon]=\"options.clearIcon == null ? defaultOpts.clearIcon : options.clearIcon\"\n               [color]=\"options.color == null ? null : options.color\"\n               [showCancelButton]=\"options.showCancelButton == null ?\n                                        (defaultOpts.showCancelButton ? 'always' : 'never') :\n                                        (options.showCancelButton ? 'always' : 'never')\"\n               [debounce]=\"options.debounce == null ? defaultOpts.debounce : options.debounce\"\n               [placeholder]=\"options.placeholder == null ? defaultOpts.placeholder : options.placeholder\"\n               [autocorrect]=\"options.autocorrect == null ? defaultOpts.autocorrect : options.autocorrect\"\n               [mode]=\"options.mode == null ? defaultOpts.mode : options.mode\"\n               [searchIcon]=\"options.searchIcon == null ? defaultOpts.searchIcon : options.searchIcon\"\n               [spellcheck]=\"options.spellcheck == null ? defaultOpts.spellcheck : options.spellcheck\"\n               [type]=\"options.type == null ? defaultOpts.type : options.type\"\n               [ngClass]=\"{ 'hidden': useIonInput, 'loading': isLoading, 'disabled': disabled || (this.maxSelected !== null && this.selected.length >= this.maxSelected) }\"\n               (ionClear)=\"clearValue(true)\"\n               (ionFocus)=\"onFocus($event)\"\n               (ionBlur)=\"onBlur($event)\"></ion-searchbar>\n\n<ng-template #defaultTemplate\n             let-attrs=\"attrs\">\n    <span [innerHTML]='attrs.label | boldprefix:attrs.keyword'></span>\n</ng-template>\n\n<ng-template #defaultEmptyTemplate\n             let-attrs=\"attrs\"\n             class=\"ion-text-center\">\n    {{ options.noItems }}\n</ng-template>\n\n<ul *ngIf=\"!(disabled || (this.maxSelected !== null && this.selected.length >= this.maxSelected)) && suggestions.length > 0 && showList\"\n    [ngStyle]=\"getStyle()\">\n    <li *ngFor=\"let suggestion of suggestions| slice:0:maxResults;\"\n        (click)=\"handleSelectTap($event, suggestion)\"\n        (tap)=\"handleSelectTap($event, suggestion)\">\n        <ng-template [ngTemplateOutlet]=\"template || defaultTemplate\"\n                     [ngTemplateOutletContext]=\"{\n                        attrs:{\n                          data:               suggestion,\n                          label:              getLabel(suggestion),\n                          keyword:            keyword,\n                          formValue:          getFormValue(suggestion),\n                          labelAttribute:     getLabel(suggestion),\n                          formValueAttribute: getFormValue(suggestion)\n                        }\n                     }\"></ng-template>\n    </li>\n</ul>\n\n<ul *ngIf=\"suggestions.length === 0 && showList && options.noItems\"\n    [ngStyle]=\"getStyle()\">\n    <li>\n        <ng-template [ngTemplateOutlet]=\"emptyTemplate || defaultEmptyTemplate\"\n                     [ngTemplateOutletContext]=\"{\n                        attrs:{\n                          keyword: keyword\n                        }\n                     }\"></ng-template>\n    </li>\n</ul>\n"
        })
    ], AutoCompleteComponent);
    return AutoCompleteComponent;
}());

/**
 * Bolds the beginning of the matching string in the item
 */
var BoldPrefix = /** @class */ (function () {
    function BoldPrefix() {
    }
    BoldPrefix.prototype.transform = function (value, keyword) {
        if (!keyword) {
            return value;
        }
        var escaped_keyword = keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        return value.replace(new RegExp(escaped_keyword, 'gi'), function (str) {
            return str.bold();
        });
    };
    BoldPrefix = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
            name: 'boldprefix'
        }),
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()
    ], BoldPrefix);
    return BoldPrefix;
}());

var AutoCompleteModule = /** @class */ (function () {
    function AutoCompleteModule() {
    }
    AutoCompleteModule_1 = AutoCompleteModule;
    AutoCompleteModule.forRoot = function () {
        return {
            ngModule: AutoCompleteModule_1,
            providers: []
        };
    };
    var AutoCompleteModule_1;
    AutoCompleteModule = AutoCompleteModule_1 = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [
                AutoCompleteComponent,
                BoldPrefix
            ],
            exports: [
                AutoCompleteComponent,
                BoldPrefix
            ],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"]
            ]
        })
    ], AutoCompleteModule);
    return AutoCompleteModule;
}());

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=ionic4-auto-complete.js.map


/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/search/search.page.html":
/*!*************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/search/search.page.html ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>search</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <form [formGroup]=\"searchForm\" \n  (ngSubmit)=\"search()\" >\n    <ion-searchbar showCancelButton=\"focus\" formControlName=\"keyword\" #searchMe></ion-searchbar>\n  </form>\n    <!-- <form [formGroup]=\"searchForm\" \n      (ngSubmit)=\"submit()\" \n      novalidate>\n  <div class=\"ion-form-group\">\n    <ion-auto-complete [dataProvider]=\"searchService\" \n                       formControlName=\"product\"></ion-auto-complete>\n  </div>\n  \n  <button ion-button \n          type=\"submit\" \n          block>\n      search\n  </button>\n</form> -->\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/search/search-routing.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages/search/search-routing.module.ts ***!
  \*******************************************************/
/*! exports provided: SearchPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchPageRoutingModule", function() { return SearchPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _search_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./search.page */ "./src/app/pages/search/search.page.ts");




var routes = [
    {
        path: '',
        component: _search_page__WEBPACK_IMPORTED_MODULE_3__["SearchPage"]
    }
];
var SearchPageRoutingModule = /** @class */ (function () {
    function SearchPageRoutingModule() {
    }
    SearchPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], SearchPageRoutingModule);
    return SearchPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/pages/search/search.module.ts":
/*!***********************************************!*\
  !*** ./src/app/pages/search/search.module.ts ***!
  \***********************************************/
/*! exports provided: SearchPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchPageModule", function() { return SearchPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var ionic4_auto_complete__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ionic4-auto-complete */ "./node_modules/ionic4-auto-complete/fesm5/ionic4-auto-complete.js");
/* harmony import */ var _search_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./search-routing.module */ "./src/app/pages/search/search-routing.module.ts");
/* harmony import */ var _search_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./search.page */ "./src/app/pages/search/search.page.ts");








var SearchPageModule = /** @class */ (function () {
    function SearchPageModule() {
    }
    SearchPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _search_routing_module__WEBPACK_IMPORTED_MODULE_6__["SearchPageRoutingModule"],
                ionic4_auto_complete__WEBPACK_IMPORTED_MODULE_5__["AutoCompleteModule"]
            ],
            declarations: [_search_page__WEBPACK_IMPORTED_MODULE_7__["SearchPage"]]
        })
    ], SearchPageModule);
    return SearchPageModule;
}());



/***/ }),

/***/ "./src/app/pages/search/search.page.scss":
/*!***********************************************!*\
  !*** ./src/app/pages/search/search.page.scss ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-auto-complete {\n  overflow: hidden !important;\n  width: 90vw;\n  display: inline-block;\n}\nion-auto-complete ion-searchbar {\n  padding: 1px !important;\n}\nion-auto-complete .disabled input.searchbar-input {\n  pointer-events: none;\n  cursor: default;\n}\nion-auto-complete ul {\n  position: absolute;\n  width: 90vw;\n  margin-top: 0;\n  background: #FFF;\n  list-style-type: none;\n  padding: 0;\n  left: 16px;\n  z-index: 999;\n  box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.14), 0 3px 1px -2px rgba(0, 0, 0, 0.2), 0 1px 5px 0 rgba(0, 0, 0, 0.12);\n}\nion-auto-complete ul li {\n  padding: 15px;\n  border-bottom: 1px solid #c1c1c1;\n}\nion-auto-complete ul ion-auto-complete-item {\n  height: 40px;\n  width: 100%;\n}\nion-auto-complete ul li:last-child {\n  border: none;\n}\nion-auto-complete ul li:hover {\n  cursor: pointer;\n  background: #f1f1f1;\n}\nion-auto-complete .hidden {\n  display: none;\n}\nion-auto-complete .loading input.searchbar-input {\n  background: white url(/assets/loading.gif) no-repeat right center;\n  background-size: 25px 25px;\n}\nion-auto-complete .selected-items {\n  float: left;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9hcHBsZS9EZXNrdG9wL1Nob3BwaW5nL3RmYiB2Mi4wL3RoZWZseWluZ2Jhc2tldC9zcmMvYXBwL3BhZ2VzL3NlYXJjaC9zZWFyY2gucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9zZWFyY2gvc2VhcmNoLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLDJCQUFBO0VBQ0EsV0FBQTtFQUNBLHFCQUFBO0FDQ0Y7QURDRTtFQUNFLHVCQUFBO0FDQ0o7QURFRTtFQUNFLG9CQUFBO0VBQ0EsZUFBQTtBQ0FKO0FER0U7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0VBQ0EsZ0JBQUE7RUFDQSxxQkFBQTtFQUNBLFVBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtFQUNBLCtHQUFBO0FDREo7QURHSTtFQUNFLGFBQUE7RUFDQSxnQ0FBQTtBQ0ROO0FESUk7RUFDRSxZQUFBO0VBQ0EsV0FBQTtBQ0ZOO0FES0k7RUFDRSxZQUFBO0FDSE47QURNSTtFQUNFLGVBQUE7RUFDQSxtQkFBQTtBQ0pOO0FEUUU7RUFDRSxhQUFBO0FDTko7QURTRTtFQUNFLGlFQUFBO0VBQ0EsMEJBQUE7QUNQSjtBRFVFO0VBQ0UsV0FBQTtBQ1JKIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvc2VhcmNoL3NlYXJjaC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tYXV0by1jb21wbGV0ZSB7XG4gIG92ZXJmbG93OiBoaWRkZW4gIWltcG9ydGFudDtcbiAgd2lkdGg6ICAgIDkwdnc7XG4gIGRpc3BsYXk6ICBpbmxpbmUtYmxvY2s7XG5cbiAgaW9uLXNlYXJjaGJhciB7XG4gICAgcGFkZGluZzogMXB4ICFpbXBvcnRhbnQ7XG4gIH1cblxuICAuZGlzYWJsZWQgaW5wdXQuc2VhcmNoYmFyLWlucHV0IHtcbiAgICBwb2ludGVyLWV2ZW50czogbm9uZTtcbiAgICBjdXJzb3I6IGRlZmF1bHQ7XG4gIH1cblxuICB1bCB7XG4gICAgcG9zaXRpb246ICAgICAgICBhYnNvbHV0ZTtcbiAgICB3aWR0aDogICAgICAgICAgIDkwdnc7XG4gICAgbWFyZ2luLXRvcDogICAgICAwO1xuICAgIGJhY2tncm91bmQ6ICAgICAgI0ZGRjtcbiAgICBsaXN0LXN0eWxlLXR5cGU6IG5vbmU7XG4gICAgcGFkZGluZzogICAgICAgICAwO1xuICAgIGxlZnQ6ICAgICAgICAgICAgMTZweDtcbiAgICB6LWluZGV4OiAgICAgICAgIDk5OTtcbiAgICBib3gtc2hhZG93OiAgICAgIDAgMnB4IDJweCAwIHJnYmEoMCwgMCwgMCwgMC4xNCksIDAgM3B4IDFweCAtMnB4IHJnYmEoMCwgMCwgMCwgMC4yKSwgMCAxcHggNXB4IDAgcmdiYSgwLCAwLCAwLCAwLjEyKTtcblxuICAgIGxpIHtcbiAgICAgIHBhZGRpbmc6ICAgICAgIDE1cHg7XG4gICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2MxYzFjMTtcbiAgICB9XG5cbiAgICBpb24tYXV0by1jb21wbGV0ZS1pdGVtIHtcbiAgICAgIGhlaWdodDogNDBweDtcbiAgICAgIHdpZHRoOiAgMTAwJTtcbiAgICB9XG5cbiAgICBsaTpsYXN0LWNoaWxkIHtcbiAgICAgIGJvcmRlcjogbm9uZTtcbiAgICB9XG5cbiAgICBsaTpob3ZlciB7XG4gICAgICBjdXJzb3I6ICAgICBwb2ludGVyO1xuICAgICAgYmFja2dyb3VuZDogI2YxZjFmMVxuICAgIH1cbiAgfVxuXG4gIC5oaWRkZW4ge1xuICAgIGRpc3BsYXk6IG5vbmU7XG4gIH1cblxuICAubG9hZGluZyBpbnB1dC5zZWFyY2hiYXItaW5wdXQge1xuICAgIGJhY2tncm91bmQ6ICAgICAgd2hpdGUgdXJsKC9hc3NldHMvbG9hZGluZy5naWYpIG5vLXJlcGVhdCByaWdodCBjZW50ZXI7XG4gICAgYmFja2dyb3VuZC1zaXplOiAyNXB4IDI1cHg7XG4gIH1cblxuICAuc2VsZWN0ZWQtaXRlbXMge1xuICAgIGZsb2F0OiBsZWZ0O1xuICB9XG59XG4iLCJpb24tYXV0by1jb21wbGV0ZSB7XG4gIG92ZXJmbG93OiBoaWRkZW4gIWltcG9ydGFudDtcbiAgd2lkdGg6IDkwdnc7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbn1cbmlvbi1hdXRvLWNvbXBsZXRlIGlvbi1zZWFyY2hiYXIge1xuICBwYWRkaW5nOiAxcHggIWltcG9ydGFudDtcbn1cbmlvbi1hdXRvLWNvbXBsZXRlIC5kaXNhYmxlZCBpbnB1dC5zZWFyY2hiYXItaW5wdXQge1xuICBwb2ludGVyLWV2ZW50czogbm9uZTtcbiAgY3Vyc29yOiBkZWZhdWx0O1xufVxuaW9uLWF1dG8tY29tcGxldGUgdWwge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHdpZHRoOiA5MHZ3O1xuICBtYXJnaW4tdG9wOiAwO1xuICBiYWNrZ3JvdW5kOiAjRkZGO1xuICBsaXN0LXN0eWxlLXR5cGU6IG5vbmU7XG4gIHBhZGRpbmc6IDA7XG4gIGxlZnQ6IDE2cHg7XG4gIHotaW5kZXg6IDk5OTtcbiAgYm94LXNoYWRvdzogMCAycHggMnB4IDAgcmdiYSgwLCAwLCAwLCAwLjE0KSwgMCAzcHggMXB4IC0ycHggcmdiYSgwLCAwLCAwLCAwLjIpLCAwIDFweCA1cHggMCByZ2JhKDAsIDAsIDAsIDAuMTIpO1xufVxuaW9uLWF1dG8tY29tcGxldGUgdWwgbGkge1xuICBwYWRkaW5nOiAxNXB4O1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2MxYzFjMTtcbn1cbmlvbi1hdXRvLWNvbXBsZXRlIHVsIGlvbi1hdXRvLWNvbXBsZXRlLWl0ZW0ge1xuICBoZWlnaHQ6IDQwcHg7XG4gIHdpZHRoOiAxMDAlO1xufVxuaW9uLWF1dG8tY29tcGxldGUgdWwgbGk6bGFzdC1jaGlsZCB7XG4gIGJvcmRlcjogbm9uZTtcbn1cbmlvbi1hdXRvLWNvbXBsZXRlIHVsIGxpOmhvdmVyIHtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBiYWNrZ3JvdW5kOiAjZjFmMWYxO1xufVxuaW9uLWF1dG8tY29tcGxldGUgLmhpZGRlbiB7XG4gIGRpc3BsYXk6IG5vbmU7XG59XG5pb24tYXV0by1jb21wbGV0ZSAubG9hZGluZyBpbnB1dC5zZWFyY2hiYXItaW5wdXQge1xuICBiYWNrZ3JvdW5kOiB3aGl0ZSB1cmwoL2Fzc2V0cy9sb2FkaW5nLmdpZikgbm8tcmVwZWF0IHJpZ2h0IGNlbnRlcjtcbiAgYmFja2dyb3VuZC1zaXplOiAyNXB4IDI1cHg7XG59XG5pb24tYXV0by1jb21wbGV0ZSAuc2VsZWN0ZWQtaXRlbXMge1xuICBmbG9hdDogbGVmdDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/pages/search/search.page.ts":
/*!*********************************************!*\
  !*** ./src/app/pages/search/search.page.ts ***!
  \*********************************************/
/*! exports provided: SearchPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchPage", function() { return SearchPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");




var SearchPage = /** @class */ (function () {
    function SearchPage(
    // private searchService: SearchService,
    router) {
        this.router = router;
    }
    SearchPage.prototype.ngAfterViewInit = function () {
        this.elementRef.nativeElement.focus();
    };
    SearchPage.prototype.ngOnInit = function () {
        // this.searchForm = new FormGroup({
        //   product: new FormControl('', [
        //     Validators.required
        //   ])
        // });
        this.searchForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroup"]({
            keyword: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required
            ])
        });
        this.searchForm.reset();
    };
    SearchPage.prototype.search = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.router.navigate(['tabs/products'], { queryParams: { pSearch: this.searchForm.value.keyword } });
                return [2 /*return*/];
            });
        });
    };
    SearchPage.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('searchMe', { read: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], static: false }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
    ], SearchPage.prototype, "elementRef", void 0);
    SearchPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-search',
            template: __webpack_require__(/*! raw-loader!./search.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/search/search.page.html"),
            styles: [__webpack_require__(/*! ./search.page.scss */ "./src/app/pages/search/search.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]])
    ], SearchPage);
    return SearchPage;
}());



/***/ })

}]);
//# sourceMappingURL=search-search-module-es5.js.map