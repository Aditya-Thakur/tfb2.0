(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-tabs-tabs-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/tabs/tabs.page.html":
/*!*********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/tabs/tabs.page.html ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-menu side=\"start\">\n  <ion-header>\n    <ion-toolbar translucent>\n      <ion-title *ngIf=\"globalVariable.loggedIn\" style=\"color: #4aad77;\">Hello {{globalVariable.loggedInUser.name}}</ion-title>\n    </ion-toolbar>\n  </ion-header>\n  <ion-content style=\"color: #4aad77;\">\n    <ion-list>\n      <ion-item>\n        <ion-icon style=\"color: #4aad77;\" name=\"home\" slot=\"start\"></ion-icon>\n        <ion-label style=\"color: #4aad77;\" (click)=\"openHome()\" menuToggle>Home</ion-label>\n      </ion-item>\n      <ion-item>\n        <ion-icon style=\"color: #4aad77;\" name=\"person\" slot=\"start\"></ion-icon>\n        <ion-label style=\"color: #4aad77;\" (click)=\"openPage('myProfile')\">My Profile</ion-label>\n      </ion-item>\n      <ion-item>\n        <ion-icon style=\"color: #4aad77;\" name=\"pricetags\" slot=\"start\"></ion-icon>\n        <ion-label style=\"color: #4aad77;\" (click)=\"openPage('myOrders')\">My orders</ion-label>\n      </ion-item>\n      <ion-item>\n        <ion-icon style=\"color: #4aad77;\" name=\"contact\" slot=\"start\"></ion-icon>\n        <ion-label style=\"color: #4aad77;\" (click)=\"openPage('aboutUs')\">About Us</ion-label>\n      </ion-item>\n      <ion-item>\n          <ion-icon style=\"color: #4aad77;\" name=\"help-buoy\" slot=\"start\"></ion-icon>\n          <ion-label style=\"color: #4aad77;\" (click)=\"openPage('contactUs')\">Contact Us</ion-label>\n        </ion-item>\n      <ion-item>\n        <ion-icon style=\"color: #4aad77;\" name=\"bicycle\" slot=\"start\"></ion-icon>\n        <ion-label style=\"color: #4aad77;\" (click)=\"openPage('deliveryPolicy')\">Delivery Policy</ion-label>\n      </ion-item>\n      <ion-item>\n        <ion-icon style=\"color: #4aad77;\" name=\"return-left\" slot=\"start\"></ion-icon>\n        <ion-label style=\"color: #4aad77;\" (click)=\"openPage('cancel')\">Cancel & Return Policy</ion-label>\n      </ion-item>\n      <ion-item>\n          <ion-icon style=\"color: #4aad77;\" name=\"lock\" slot=\"start\"></ion-icon>\n          <ion-label style=\"color: #4aad77;\" (click)=\"openPage('privacyPolicy')\">Privacy Policy</ion-label>\n      </ion-item>\n      <ion-item slot=\"end\">\n        <ion-icon style=\"color: #4aad77;\" name=\"person\" slot=\"start\"></ion-icon>\n        <ion-label *ngIf=\"!globalVariable.loggedIn\" style=\"color: #4aad77;\" (click)=\"openLogin()\">\n          Login/Register\n        </ion-label>\n        <ion-label *ngIf=\"globalVariable.loggedIn\" style=\"color: #4aad77;\" (click)=\"logout()\">\n          Logout\n        </ion-label>\n    </ion-item>\n    </ion-list>\n  </ion-content>\n</ion-menu>\n<div class=\"ion-page\" main>\n  <ion-toolbar [color]=\"currentColor\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-buttons>\n      <ion-button (click)=\"openHomeByIcon()\">\n        <img class=\"icon-img\" src=\"../../../assets/icon/favicon.png\">\n      </ion-button>\n      <ion-title slot=\"primary\">The Flying Basket</ion-title>\n      <!-- <ion-button (click)=\"openSearch()\">\n        <ion-icon slot=\"icon-only\" name=\"search\"></ion-icon>\n      </ion-button> -->\n    </ion-buttons>\n  </ion-toolbar>\n  <ion-content>\n    <ion-header collapse=\"condense\">\n      <ion-toolbar>\n        <ion-title size=\"large\">My Navigation Bar</ion-title>\n      </ion-toolbar>\n    </ion-header>\n  </ion-content>\n  <ion-tabs>\n    <ion-tab-bar [color]=\"currentColor\" slot=\"bottom\">\n      <ion-tab-button tab=\"main\">\n        <ion-icon name=\"home\"></ion-icon>\n        <ion-label>Home</ion-label>\n      </ion-tab-button>\n\n      <ion-tab-button tab=\"Categories\">\n        <ion-icon name=\"apps\"></ion-icon>\n        <ion-label>Categories</ion-label>\n      </ion-tab-button>\n\n      <ion-tab-button tab=\"search\">\n        <ion-icon name=\"search\"></ion-icon>\n        <ion-label>Search</ion-label>\n      </ion-tab-button>\n\n      <ion-tab-button tab=\"cart\">\n        <ion-icon name=\"basket\"></ion-icon>\n        <ion-label>Basket</ion-label>\n        <ion-badge>{{globalVariable.myCart.getTotalItemCount()}}</ion-badge>\n      </ion-tab-button>\n    </ion-tab-bar>\n  </ion-tabs>\n</div>\n<!-- \n<ion-menu-controller></ion-menu-controller> -->"

/***/ }),

/***/ "./src/app/pages/tabs/tabs-routing.module.ts":
/*!***************************************************!*\
  !*** ./src/app/pages/tabs/tabs-routing.module.ts ***!
  \***************************************************/
/*! exports provided: TabsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabsPageRoutingModule", function() { return TabsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _tabs_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./tabs.page */ "./src/app/pages/tabs/tabs.page.ts");




const routes = [
    {
        path: 'tabs',
        component: _tabs_page__WEBPACK_IMPORTED_MODULE_3__["TabsPage"],
        children: [
            {
                path: 'cart',
                children: [
                    {
                        path: '',
                        loadChildren: () => Promise.all(/*! import() | cart-cart-module */[__webpack_require__.e("default~cart-cart-module~product-details-product-details-module~products-products-module"), __webpack_require__.e("cart-cart-module")]).then(__webpack_require__.bind(null, /*! ./../cart/cart.module */ "./src/app/pages/cart/cart.module.ts")).then(m => m.CartPageModule)
                    }
                ]
            },
            {
                path: 'Categories',
                children: [
                    {
                        path: '',
                        loadChildren: () => __webpack_require__.e(/*! import() | categories-categories-module */ "categories-categories-module").then(__webpack_require__.bind(null, /*! ./../categories/categories.module */ "./src/app/pages/categories/categories.module.ts")).then(m => m.CategoriesPageModule)
                    }
                ]
            },
            {
                path: 'main',
                children: [
                    {
                        path: '',
                        loadChildren: () => __webpack_require__.e(/*! import() | main-main-module */ "main-main-module").then(__webpack_require__.bind(null, /*! ./../main/main.module */ "./src/app/pages/main/main.module.ts")).then(m => m.MainPageModule)
                    }
                ]
            },
            {
                path: 'details',
                children: [
                    {
                        path: '',
                        loadChildren: () => Promise.all(/*! import() | product-details-product-details-module */[__webpack_require__.e("default~cart-cart-module~product-details-product-details-module~products-products-module"), __webpack_require__.e("product-details-product-details-module")]).then(__webpack_require__.bind(null, /*! ./../product-details/product-details.module */ "./src/app/pages/product-details/product-details.module.ts")).then(m => m.ProductDetailsPageModule)
                    }
                ]
            },
            {
                path: 'products',
                children: [
                    {
                        path: '',
                        loadChildren: () => __webpack_require__.e(/*! import() | products-products-module */ "default~cart-cart-module~product-details-product-details-module~products-products-module").then(__webpack_require__.bind(null, /*! ./../products/products.module */ "./src/app/pages/products/products.module.ts")).then(m => m.ProductsPageModule)
                    }
                ]
            },
            {
                path: 'search',
                children: [
                    {
                        path: '',
                        loadChildren: () => __webpack_require__.e(/*! import() | search-search-module */ "search-search-module").then(__webpack_require__.bind(null, /*! ./../search/search.module */ "./src/app/pages/search/search.module.ts")).then(m => m.SearchPageModule)
                    }
                ]
            },
            {
                path: 'register',
                children: [
                    {
                        path: '',
                        loadChildren: () => Promise.all(/*! import() | shared-register-register-module */[__webpack_require__.e("common"), __webpack_require__.e("shared-register-register-module")]).then(__webpack_require__.bind(null, /*! ../shared/register/register.module */ "./src/app/pages/shared/register/register.module.ts")).then(m => m.RegisterPageModule)
                    }
                ]
            },
            {
                path: 'login',
                children: [
                    {
                        path: '',
                        loadChildren: () => Promise.all(/*! import() | shared-login-login-module */[__webpack_require__.e("common"), __webpack_require__.e("shared-login-login-module")]).then(__webpack_require__.bind(null, /*! ../shared/login/login.module */ "./src/app/pages/shared/login/login.module.ts")).then(m => m.LoginPageModule)
                    }
                ]
            },
            {
                path: 'aboutUs',
                children: [
                    {
                        path: '',
                        loadChildren: () => __webpack_require__.e(/*! import() | sidePanel-about-us-about-us-module */ "sidePanel-about-us-about-us-module").then(__webpack_require__.bind(null, /*! ../sidePanel/about-us/about-us.module */ "./src/app/pages/sidePanel/about-us/about-us.module.ts")).then(m => m.AboutUsPageModule)
                    }
                ]
            },
            {
                path: 'contactUs',
                children: [
                    {
                        path: '',
                        loadChildren: () => __webpack_require__.e(/*! import() | sidePanel-contact-us-contact-us-module */ "sidePanel-contact-us-contact-us-module").then(__webpack_require__.bind(null, /*! ../sidePanel/contact-us/contact-us.module */ "./src/app/pages/sidePanel/contact-us/contact-us.module.ts")).then(m => m.ContactUsPageModule)
                    }
                ]
            },
            {
                path: 'cancel',
                children: [
                    {
                        path: '',
                        loadChildren: () => __webpack_require__.e(/*! import() | sidePanel-cancel-cancel-module */ "sidePanel-cancel-cancel-module").then(__webpack_require__.bind(null, /*! ../sidePanel/cancel/cancel.module */ "./src/app/pages/sidePanel/cancel/cancel.module.ts")).then(m => m.CancelPageModule)
                    }
                ]
            },
            {
                path: 'deliveryPolicy',
                children: [
                    {
                        path: '',
                        loadChildren: () => __webpack_require__.e(/*! import() | sidePanel-delivery-policy-delivery-policy-module */ "sidePanel-delivery-policy-delivery-policy-module").then(__webpack_require__.bind(null, /*! ../sidePanel/delivery-policy/delivery-policy.module */ "./src/app/pages/sidePanel/delivery-policy/delivery-policy.module.ts")).then(m => m.DeliveryPolicyPageModule)
                    }
                ]
            },
            {
                path: 'privacyPolicy',
                children: [
                    {
                        path: '',
                        loadChildren: () => __webpack_require__.e(/*! import() | sidePanel-privacy-policy-privacy-policy-module */ "sidePanel-privacy-policy-privacy-policy-module").then(__webpack_require__.bind(null, /*! ../sidePanel/privacy-policy/privacy-policy.module */ "./src/app/pages/sidePanel/privacy-policy/privacy-policy.module.ts")).then(m => m.PrivacyPolicyPageModule)
                    }
                ]
            },
            {
                path: 'myProfile',
                children: [
                    {
                        path: '',
                        loadChildren: () => __webpack_require__.e(/*! import() | sidePanel-my-profile-my-profile-module */ "sidePanel-my-profile-my-profile-module").then(__webpack_require__.bind(null, /*! ../sidePanel/my-profile/my-profile.module */ "./src/app/pages/sidePanel/my-profile/my-profile.module.ts")).then(m => m.MyProfilePageModule)
                    }
                ]
            },
            {
                path: 'myOrders',
                children: [
                    {
                        path: '',
                        loadChildren: () => Promise.all(/*! import() | sidePanel-my-orders-my-orders-module */[__webpack_require__.e("common"), __webpack_require__.e("sidePanel-my-orders-my-orders-module")]).then(__webpack_require__.bind(null, /*! ../sidePanel/my-orders/my-orders.module */ "./src/app/pages/sidePanel/my-orders/my-orders.module.ts")).then(m => m.MyOrdersPageModule)
                    }
                ]
            },
            {
                path: 'checkout',
                children: [
                    {
                        path: '',
                        loadChildren: () => Promise.all(/*! import() | order-checkout-checkout-module */[__webpack_require__.e("common"), __webpack_require__.e("order-checkout-checkout-module")]).then(__webpack_require__.bind(null, /*! ../order/checkout/checkout.module */ "./src/app/pages/order/checkout/checkout.module.ts")).then(m => m.CheckoutPageModule)
                    }
                ]
            }
        ]
    },
    {
        path: '',
        redirectTo: 'tabs/main',
        pathMatch: 'full'
    }
];
let TabsPageRoutingModule = class TabsPageRoutingModule {
};
TabsPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], TabsPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/tabs/tabs.module.ts":
/*!*******************************************!*\
  !*** ./src/app/pages/tabs/tabs.module.ts ***!
  \*******************************************/
/*! exports provided: TabsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabsPageModule", function() { return TabsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _tabs_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./tabs-routing.module */ "./src/app/pages/tabs/tabs-routing.module.ts");
/* harmony import */ var _tabs_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./tabs.page */ "./src/app/pages/tabs/tabs.page.ts");
/* harmony import */ var src_app_material_material_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/material/material.module */ "./src/app/material/material.module.ts");








let TabsPageModule = class TabsPageModule {
};
TabsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _tabs_routing_module__WEBPACK_IMPORTED_MODULE_5__["TabsPageRoutingModule"],
            src_app_material_material_module__WEBPACK_IMPORTED_MODULE_7__["MaterialModule"]
        ],
        declarations: [_tabs_page__WEBPACK_IMPORTED_MODULE_6__["TabsPage"]]
    })
], TabsPageModule);



/***/ }),

/***/ "./src/app/pages/tabs/tabs.page.scss":
/*!*******************************************!*\
  !*** ./src/app/pages/tabs/tabs.page.scss ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".icon-img {\n  height: 25px !important;\n  width: auto !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9hcHBsZS9EZXNrdG9wL1Nob3BwaW5nL3RmYiB2Mi4wL3RoZWZseWluZ2Jhc2tldC9zcmMvYXBwL3BhZ2VzL3RhYnMvdGFicy5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL3RhYnMvdGFicy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSx1QkFBQTtFQUNBLHNCQUFBO0FDQ0oiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy90YWJzL3RhYnMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmljb24taW1nIHtcbiAgICBoZWlnaHQ6IDI1cHggIWltcG9ydGFudDtcbiAgICB3aWR0aDogYXV0byAhaW1wb3J0YW50O1xufSIsIi5pY29uLWltZyB7XG4gIGhlaWdodDogMjVweCAhaW1wb3J0YW50O1xuICB3aWR0aDogYXV0byAhaW1wb3J0YW50O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/pages/tabs/tabs.page.ts":
/*!*****************************************!*\
  !*** ./src/app/pages/tabs/tabs.page.ts ***!
  \*****************************************/
/*! exports provided: TabsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabsPage", function() { return TabsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var src_app_global__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/global */ "./src/app/global.ts");
/* harmony import */ var src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/storage.service */ "./src/app/services/storage.service.ts");






let TabsPage = class TabsPage {
    constructor(router, menu, storage) {
        this.router = router;
        this.menu = menu;
        this.storage = storage;
        this.globalVariable = src_app_global__WEBPACK_IMPORTED_MODULE_4__["Global"];
        this.currentColor = 'success';
    }
    openFirst() {
        this.menu.enable(true, 'first');
        this.menu.open('first');
    }
    openEnd() {
        this.menu.open('end');
    }
    openCustom() {
        this.menu.enable(true, 'custom');
        this.menu.open('custom');
    }
    ngOnInit() {
    }
    openSearch() {
        this.router.navigateByUrl(`/tabs/search`);
    }
    openLogin() {
        this.router.navigateByUrl(`/tabs/login`);
        this.menu.toggle();
    }
    openHome() {
        this.router.navigateByUrl(`/tabs/main`);
        this.menu.toggle();
    }
    openHomeByIcon() {
        this.router.navigateByUrl(`/tabs/main`);
    }
    openPage(pageName) {
        this.router.navigateByUrl(`/tabs/` + pageName);
        this.menu.toggle();
    }
    logout() {
        this.globalVariable.loggedIn = false;
        this.storage.clearAll();
    }
};
TabsPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"] },
    { type: src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_5__["StorageService"] }
];
TabsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-tabs',
        template: __webpack_require__(/*! raw-loader!./tabs.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/tabs/tabs.page.html"),
        styles: [__webpack_require__(/*! ./tabs.page.scss */ "./src/app/pages/tabs/tabs.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"], src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_5__["StorageService"]])
], TabsPage);



/***/ })

}]);
//# sourceMappingURL=pages-tabs-tabs-module-es2015.js.map