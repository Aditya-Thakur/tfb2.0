(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["categories-categories-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/categories/categories.page.html":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/categories/categories.page.html ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>Categories</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-toolbar>\n    <ion-title size=\"large\">Shop by Category</ion-title>\n  </ion-toolbar>\n<ion-content>\n    <!-- <mat-nav-list>\n        <mat-list-item *ngFor=\"let category of categoryDict | keyvalue\">\n           <mat-accordion>\n              <mat-expansion-panel>\n                <mat-expansion-panel-header>\n                  <mat-panel-title>\n                      {{category.key}}\n                  </mat-panel-title>\n                </mat-expansion-panel-header>\n                <ion-list>\n                    <ion-item *ngFor=\"let subcategory of categoryDict.get(category.key)\">\n                      <ion-label>{{ subcategory }}</ion-label>\n                    </ion-item>\n                  </ion-list>\n              </mat-expansion-panel>\n            </mat-accordion>\n        </mat-list-item>\n      </mat-nav-list> -->\n      \n      <ion-list>\n        <ion-item *ngFor=\"let category of categoryDict | keyvalue\">\n          <ion-label>\n            <mat-accordion style=\"color: green;\">\n              <mat-expansion-panel>\n                <mat-expansion-panel-header>\n                  <mat-panel-title style=\"color: rgb(255, 255, 255);\">\n                      {{category.key}}\n                  </mat-panel-title>\n                </mat-expansion-panel-header>\n                <ion-list>\n                    <ion-item *ngFor=\"let subcategory of categoryDict.get(category.key)\">\n                      <ion-label (click)=\"getProducts(subcategory.id)\">{{ subcategory.subCategory }}</ion-label>\n                    </ion-item>\n                  </ion-list>\n              </mat-expansion-panel>\n            </mat-accordion>\n          </ion-label>\n        </ion-item>\n      </ion-list>\n      \n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/categories/categories-routing.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/categories/categories-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: CategoriesPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CategoriesPageRoutingModule", function() { return CategoriesPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _categories_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./categories.page */ "./src/app/pages/categories/categories.page.ts");




const routes = [
    {
        path: '',
        component: _categories_page__WEBPACK_IMPORTED_MODULE_3__["CategoriesPage"]
    }
];
let CategoriesPageRoutingModule = class CategoriesPageRoutingModule {
};
CategoriesPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CategoriesPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/categories/categories.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages/categories/categories.module.ts ***!
  \*******************************************************/
/*! exports provided: CategoriesPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CategoriesPageModule", function() { return CategoriesPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _material_material_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../material/material.module */ "./src/app/material/material.module.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _categories_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./categories-routing.module */ "./src/app/pages/categories/categories-routing.module.ts");
/* harmony import */ var _categories_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./categories.page */ "./src/app/pages/categories/categories.page.ts");








let CategoriesPageModule = class CategoriesPageModule {
};
CategoriesPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _material_material_module__WEBPACK_IMPORTED_MODULE_4__["MaterialModule"],
            _categories_routing_module__WEBPACK_IMPORTED_MODULE_6__["CategoriesPageRoutingModule"]
        ],
        declarations: [_categories_page__WEBPACK_IMPORTED_MODULE_7__["CategoriesPage"]]
    })
], CategoriesPageModule);



/***/ }),

/***/ "./src/app/pages/categories/categories.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/pages/categories/categories.page.scss ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".mat-expansion-panel-header, .mat-expanded {\n  background: rgba(146, 230, 36, 0.644);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9hcHBsZS9EZXNrdG9wL1Nob3BwaW5nL3RmYl92Mi4wL3RoZWZseWluZ2Jhc2tldC9zcmMvYXBwL3BhZ2VzL2NhdGVnb3JpZXMvY2F0ZWdvcmllcy5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2NhdGVnb3JpZXMvY2F0ZWdvcmllcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxxQ0FBQTtBQ0NKIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvY2F0ZWdvcmllcy9jYXRlZ29yaWVzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tYXQtZXhwYW5zaW9uLXBhbmVsLWhlYWRlciwgLm1hdC1leHBhbmRlZCB7XG4gICAgYmFja2dyb3VuZDogcmdiYSgxNDYsIDIzMCwgMzYsIDAuNjQ0KTtcbiAgfSIsIi5tYXQtZXhwYW5zaW9uLXBhbmVsLWhlYWRlciwgLm1hdC1leHBhbmRlZCB7XG4gIGJhY2tncm91bmQ6IHJnYmEoMTQ2LCAyMzAsIDM2LCAwLjY0NCk7XG59Il19 */"

/***/ }),

/***/ "./src/app/pages/categories/categories.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/pages/categories/categories.page.ts ***!
  \*****************************************************/
/*! exports provided: CategoriesPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CategoriesPage", function() { return CategoriesPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_app_services_shopping_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/shopping.service */ "./src/app/services/shopping.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");





let CategoriesPage = class CategoriesPage {
    constructor(shoppingService, router, loading) {
        this.shoppingService = shoppingService;
        this.router = router;
        this.loading = loading;
        this.Categories = [];
        this.categoryDict = new Map();
    }
    ngOnInit() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = yield this.loading.create({
                message: 'Getting category',
            });
            yield loading.present();
            yield this.getAllCategories();
            this.Categories.forEach((element) => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
                const subcategories = yield this.shoppingService.getAllSubcategories(element.id);
                const subcategoriesTemp = [];
                subcategories.forEach(element2 => {
                    subcategoriesTemp.push(element2);
                });
                this.categoryDict.set(element.categoryName, subcategoriesTemp);
            }));
            // console.log(this.categoryDict);
            loading.dismiss();
        });
    }
    getAllCategories() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.Categories = null;
            // console.log('here');
            this.Categories = yield this.shoppingService.getAllCategories();
            // console.log(this.Categories);
        });
    }
    presentLoading() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = yield this.loading.create({
                message: 'Getting category',
            });
            yield loading.present();
            const { role, data } = yield loading.onDidDismiss();
            // console.log('Loading dismissed!');
        });
    }
    getProducts(id) {
        this.router.navigate(['tabs/products'], { queryParams: { subid: id } });
    }
};
CategoriesPage.ctorParameters = () => [
    { type: src_app_services_shopping_service__WEBPACK_IMPORTED_MODULE_2__["ShoppingService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"] }
];
CategoriesPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-categories',
        template: __webpack_require__(/*! raw-loader!./categories.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/categories/categories.page.html"),
        styles: [__webpack_require__(/*! ./categories.page.scss */ "./src/app/pages/categories/categories.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_shopping_service__WEBPACK_IMPORTED_MODULE_2__["ShoppingService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"]])
], CategoriesPage);



/***/ }),

/***/ "./src/app/services/shopping.service.ts":
/*!**********************************************!*\
  !*** ./src/app/services/shopping.service.ts ***!
  \**********************************************/
/*! exports provided: ShoppingService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ShoppingService", function() { return ShoppingService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");




let ShoppingService = 
// tslint:disable: no-string-literal
class ShoppingService {
    constructor(http) {
        this.http = http;
    }
    // Get all categories
    getAllCategories() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            try {
                console.log('hi');
                const response = yield this.http.get(`https://theflyingbasket.com/backend/api/getCategories.php`).toPromise();
                return response['categoryData'];
            }
            catch (error) {
                yield this.handleError(error);
            }
        });
    }
    // Get all subcategories for a category
    getAllSubcategories(categoryid) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            try {
                const response = yield this.http.post(`https://theflyingbasket.com/backend/api/getSubcategoryByCategory.php`, categoryid)
                    .toPromise();
                return response['subcategoryData'];
            }
            catch (error) {
                yield this.handleError(error);
            }
        });
    }
    // Get subcategory by id
    getSubcategoryByID(subcategoryid) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            try {
                const response = yield this.http.post(`https://theflyingbasket.com/backend/api/getSubcategoryNameById.php`, subcategoryid)
                    .toPromise();
                console.log('*********' + JSON.stringify(response['subData']));
                return response['subData'];
            }
            catch (error) {
                yield this.handleError(error);
            }
        });
    }
    // Get all product details for menu page
    getProductsByCategoryId(categoryId) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            try {
                const response = yield this.http.post(`https://theflyingbasket.com/backend/api/getAllProductsOfCategory.php`, categoryId).toPromise();
                this.products = response['productData'];
                return this.products;
            }
            catch (error) {
                yield this.handleError(error);
            }
        });
    }
    // Get all product details for menu page
    getProductsBySubcategoryId(subcategoryId) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            try {
                const response = yield this.http.post(`https://theflyingbasket.com/backend/api/getAllProductsOfSubCategory.php`, subcategoryId).toPromise();
                this.products = response['productData'];
                return this.products;
            }
            catch (error) {
                yield this.handleError(error);
            }
        });
    }
    // Get all product details for menu page
    getProductsBySubcategoryId2(subcategoryId1, subcategoryId2) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            try {
                const jsonToSend = {
                    id1: subcategoryId1,
                    id2: subcategoryId2
                };
                const response = yield this.http.post(`https://theflyingbasket.com/backend/api/getAllProductsOfSubCategory2.php`, jsonToSend).toPromise();
                this.products = response['productData'];
                return this.products;
            }
            catch (error) {
                yield this.handleError(error);
            }
        });
    }
    // Get product for a search keyword
    getProductsBySearch(keyword) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            try {
                const response = yield this.http.post(`https://theflyingbasket.com/backend/api/searchBarResponse.php`, keyword).toPromise();
                this.products = response['productData'];
                return this.products;
            }
            catch (error) {
                yield this.handleError(error);
            }
        });
    }
    // Get product details.
    getProductByProductId(productId) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            try {
                const response = yield this.http.post(`https://theflyingbasket.com/backend/api/getProductByProductId.php`, productId).toPromise();
                return response['productData'];
            }
            catch (error) {
                yield this.handleError(error);
            }
        });
    }
    // Get Product Variety details.
    getProductVarietyByProductId(productId) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            try {
                const response = yield this.http.post(`https://theflyingbasket.com/backend/api/getProductVarietyByProductId.php`, productId).toPromise();
                return response['productVarietyData'];
            }
            catch (error) {
                this.handleError(error);
            }
        });
    }
    // Get product for people also bought
    peopleAlsoBought(category) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            try {
                const response = yield this.http.post(`https://theflyingbasket.com/backend/api/peopleAlsoBought.php`, category).toPromise();
                this.products = response['productData'];
                return this.products;
            }
            catch (error) {
                yield this.handleError(error);
            }
        });
    }
    // Get product for a search keyword
    //   getProductsBySearch2(keyword: string): Observable<Product[]> {
    //     if (keyword === '') { return null; }
    //     return this.http.post(`${this.baseUrl}/api/searchBarResponse.php`, keyword).pipe(
    //        map((res) => {
    //          return res['productData'] as Product[];
    //      }),
    //      catchError(this.handleError));\
    //  }
    handleError(error) {
        console.log(error);
        // return an observable with a user friendly message
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])('Error! something went wrong.');
    }
};
ShoppingService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
ShoppingService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
    // tslint:disable: no-string-literal
    ,
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
], ShoppingService);



/***/ })

}]);
//# sourceMappingURL=categories-categories-module-es2015.js.map