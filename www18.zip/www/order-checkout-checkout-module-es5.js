(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["order-checkout-checkout-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/order/checkout/checkout.page.html":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/order/checkout/checkout.page.html ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>checkout</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-title>Check your delivery location: </ion-title>\n  <form (ngSubmit)=\"logForm()\">\n    <ion-list>\n\n      <ion-item>\n        <ion-label floating>Name: </ion-label>\n        <ion-input type=\"text\" value=\"\" name=\"name\" [(ngModel)]=\"globalVariable.loggedInUser.name\"></ion-input>\n      </ion-item>\n\n      <ion-item>\n        <ion-label floating>Shipping Address: </ion-label>\n        <ion-input name=\"shippingAddress\" type=\"text\"\n          [(ngModel)]=\"globalVariable.loggedInUser.shippingAddress\"></ion-input>\n      </ion-item>\n\n      <ion-item>\n        <ion-label floating>Landmark: </ion-label>\n        <ion-input type=\"text\" name=\"landMark\" [(ngModel)]=\"globalVariable.loggedInUser.landMark\">\n        </ion-input>\n      </ion-item>\n\n      <ion-item>\n        <ion-label floating>City: </ion-label>\n        <ion-input type=\"text\" name=\"shippingCity\" [(ngModel)]=\"globalVariable.loggedInUser.shippingCity\">\n        </ion-input>\n      </ion-item>\n\n      <ion-item>\n        <ion-label floating>State: </ion-label>\n        <ion-input type=\"text\" name=\"shippingState\" [(ngModel)]=\"globalVariable.loggedInUser.shippingState\">\n        </ion-input>\n      </ion-item>\n\n      <ion-item>\n        <ion-label floating>Pincode: </ion-label>\n        <ion-input type=\"number\" name=\"shippingPincode\"\n          [(ngModel)]=\"globalVariable.loggedInUser.shippingPincode\"></ion-input>\n      </ion-item>\n      <ion-item-divider slot=\"end\">\n        <ion-button shape=\"round\" type=\"submit\" color=\"success\">Place\n          Order</ion-button>\n      </ion-item-divider>\n    </ion-list>\n  </form>\n</ion-content>\n<!-- <div *ngIf=\"globalVariable.myCart.getTotalItemCount() != 0; else noItemFound\" class=\"container\">\n  <div class=\"row\">\n    <h3>Step 1 of 3</h3>\n  </div>\n  <div class=\"row\">\n    <h4>You have following items in your cart: </h4>\n  </div>\n  <div class=\"row cart-table\">\n    <table *ngIf=\"globalVariable.myCart!=null\" class=\"table table-striped table-dark\">\n      <thead>\n        <tr>\n          <th scope=\"col\">\n            <i class=\"fa fa-shopping-cart cart-icon\"></i><span *ngIf=\"myCart!=null\"\n              class=\"badge\">{{globalVariable.myCart.getTotalItemCount()}}</span>\n          </th>\n          <th scope=\"col\">Product Name</th>\n          <th scope=\"col\">Price</th>\n          <th scope=\"col\">Quantity</th>\n        </tr>\n      </thead>\n      <tbody>\n        <tr *ngFor=\"let cartItem of globalVariable.myCart.myCartItems\">\n          <td>\n            <img class=\"cart-image\"\n              src=\"https://theflyingbasket.com/assets/productimages/{{cartItem.product.productId}}/{{cartItem.product.productImage1}}\"\n              alt=\"{{cartItem.product.productName}}\" (click)=\"showDetails(cartItem.product.productId)\" />\n          </td>\n          <td>{{cartItem.product.productName}}</td>\n\n          <td>Rs. {{cartItem.product.productPrice}}</td>\n          <td>\n            {{cartItem.quantity}}\n          </td>\n        </tr>\n      </tbody>\n    </table>\n  </div>\n  <div class=\"row text-center justify-content-center\">\n    <div class=\"col-md-6\" style=\"float: right; padding-top: 10px;\">\n      <h5 class=\"cart-value\">Total Cart Value : Rs. {{globalVariable.myCart.getTotalCartPrice()}}</h5>\n    </div>\n    <div class=\"col-md-2\" style=\"padding-top: 10px;\">\n        <button class=\"btn btn-small btn-dark\" (click)=\"clearCart()\">Clear Cart</button>\n    </div>\n    <div class=\"col-md-4\" style=\"padding-top: 10px;\">\n      <button (click)=\"triggerShippingForm()\" class=\"btn btn-info\">See delivery options</button>\n    </div>\n  </div>\n</div>\n<ng-template #noItemFound>\n  <div class=\"container card-body\">\n    <div class=\"row\">\n      <h5>There are no item in your cart right now: </h5>\n    </div>\n    <div class=\"row\">\n      <div class=\"col-md-4\">\n        <h4>Let's buy something now -></h4>\n      </div>\n      <div class=\"col-md-4\">\n        <button class=\"btn btn-block btn-outline-warning\" [routerLink]='[\"/\"]' routerLinkActive=\"active\">Buy Now</button>\n      </div>\n    </div>\n  </div>\n</ng-template>  -->"

/***/ }),

/***/ "./src/app/pages/order/checkout/checkout-routing.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/pages/order/checkout/checkout-routing.module.ts ***!
  \*****************************************************************/
/*! exports provided: CheckoutPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CheckoutPageRoutingModule", function() { return CheckoutPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _checkout_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./checkout.page */ "./src/app/pages/order/checkout/checkout.page.ts");




var routes = [
    {
        path: '',
        component: _checkout_page__WEBPACK_IMPORTED_MODULE_3__["CheckoutPage"]
    }
];
var CheckoutPageRoutingModule = /** @class */ (function () {
    function CheckoutPageRoutingModule() {
    }
    CheckoutPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], CheckoutPageRoutingModule);
    return CheckoutPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/pages/order/checkout/checkout.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/order/checkout/checkout.module.ts ***!
  \*********************************************************/
/*! exports provided: CheckoutPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CheckoutPageModule", function() { return CheckoutPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _checkout_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./checkout-routing.module */ "./src/app/pages/order/checkout/checkout-routing.module.ts");
/* harmony import */ var _checkout_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./checkout.page */ "./src/app/pages/order/checkout/checkout.page.ts");







var CheckoutPageModule = /** @class */ (function () {
    function CheckoutPageModule() {
    }
    CheckoutPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _checkout_routing_module__WEBPACK_IMPORTED_MODULE_5__["CheckoutPageRoutingModule"]
            ],
            declarations: [_checkout_page__WEBPACK_IMPORTED_MODULE_6__["CheckoutPage"]]
        })
    ], CheckoutPageModule);
    return CheckoutPageModule;
}());



/***/ }),

/***/ "./src/app/pages/order/checkout/checkout.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/pages/order/checkout/checkout.page.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL29yZGVyL2NoZWNrb3V0L2NoZWNrb3V0LnBhZ2Uuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/order/checkout/checkout.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages/order/checkout/checkout.page.ts ***!
  \*******************************************************/
/*! exports provided: CheckoutPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CheckoutPage", function() { return CheckoutPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_global__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/global */ "./src/app/global.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var src_app_services_order_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/order.service */ "./src/app/services/order.service.ts");
/* harmony import */ var src_app_models_cart__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/models/cart */ "./src/app/models/cart.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/storage.service */ "./src/app/services/storage.service.ts");









var CheckoutPage = /** @class */ (function () {
    function CheckoutPage(toastController, router, storage, orderService) {
        this.toastController = toastController;
        this.router = router;
        this.storage = storage;
        this.orderService = orderService;
        this.order = {
            id: 0,
            userId: 0,
            cart: new src_app_models_cart__WEBPACK_IMPORTED_MODULE_6__["Cart"]({
                myCartItems: [{
                        product: {
                            id: '',
                            category: '',
                            subcategory: '',
                            productName: '',
                            productCompany: '',
                            productPrice: '',
                            productPriceBeforeDiscount: '',
                            productDescription: '',
                            productImage1: '',
                            productImage2: '',
                            productImage3: '',
                            shippingCharge: '',
                            productAvailability: '',
                            postingDate: new Date(),
                            updationDate: new Date()
                        },
                        productVariety: {
                            id: '',
                            productId: '',
                            quantityType: '',
                            productQuantity: '',
                            productPrice: ''
                        },
                        quantity: 0
                    }],
                getTotalCartPrice: function () { return 0; },
                getQuantity: function (product) { return 0; },
                getTotalItemCount: function () { return 0; },
                getTotalDiscountPrice: function () { return 0; }
            }),
            orderDate: '',
            paymentMethod: '',
            shippingAddress: '',
            landMark: '',
            shippingState: '',
            shippingCity: '',
            shippingPincode: 0,
            contactno: 0,
            orderStatus: '',
            totalCartPrice: 0
        };
        this.globalVariable = src_app_global__WEBPACK_IMPORTED_MODULE_2__["Global"];
        this.shippingForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormGroup"]({
            shippingAddress: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('', [
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required
            ]),
            landMark: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('', [
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required,
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].pattern('[a-zA-Z& -]+')
            ]),
            shippingState: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('', [
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required,
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].pattern('[a-zA-Z& -]+')
            ]),
            shippingCity: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('', [
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required,
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].pattern('[a-zA-Z& -]+')
            ]),
            shippingPincode: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('', [
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required,
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].pattern('7216+[0-9]{2}')
            ])
        });
    }
    CheckoutPage.prototype.ngOnInit = function () {
    };
    CheckoutPage.prototype.presentToast = function (toastMessage) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var toast;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastController.create({
                            message: toastMessage,
                            duration: 2000
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    CheckoutPage.prototype.logForm = function () {
        // console.log(this.globalVariable.loggedInUser);
        if (this.globalVariable.loggedInUser.name === '') {
            this.presentToast('Name can not be empty :(');
        }
        else if (this.globalVariable.loggedInUser.shippingAddress === '') {
            this.presentToast('Shipping Address can not be empty :(');
        }
        else if (this.globalVariable.loggedInUser.landMark === '') {
            this.presentToast('Landmark can not be empty :(');
        }
        else if (this.globalVariable.loggedInUser.shippingCity === '') {
            this.presentToast('City can not be empty :(');
        }
        else if (this.globalVariable.loggedInUser.shippingState === '') {
            this.presentToast('State can not be empty :(');
        }
        else if (!(this.globalVariable.availableLocation.includes(this.globalVariable.loggedInUser.shippingPincode))) {
            this.presentToast('Sorry we do not serve on this location yet. :(');
        }
        else {
            // console.log('lets order!' + JSON.stringify(this.globalVariable.myCart, null, 2)
            // + ' ********************************' + JSON.stringify(this.shippingForm.value, null, 2));
            this.placeOrder();
        }
    };
    CheckoutPage.prototype.placeOrder = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var orderMsg, myCartItems;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.order.userId = this.globalVariable.loggedInUser.id;
                        // this.order.paymentMethod = this.placeOrderForm.value.paymentMethod;
                        this.order.paymentMethod = 'Cash On Delivery';
                        this.order.cart = this.globalVariable.myCart;
                        this.order.contactno = this.globalVariable.loggedInUser.contactno;
                        this.order.landMark = this.globalVariable.loggedInUser.landMark;
                        this.order.shippingAddress = this.globalVariable.loggedInUser.shippingAddress;
                        this.order.shippingCity = this.globalVariable.loggedInUser.shippingCity;
                        this.order.shippingPincode = this.globalVariable.loggedInUser.shippingPincode;
                        this.order.shippingState = this.globalVariable.loggedInUser.shippingState;
                        return [4 /*yield*/, this.orderService.placeOrder(this.order)];
                    case 1:
                        orderMsg = _a.sent();
                        myCartItems = [];
                        this.globalVariable.myCart = new src_app_models_cart__WEBPACK_IMPORTED_MODULE_6__["Cart"](myCartItems);
                        this.storage.saveInLocal('myCart', this.globalVariable.myCart);
                        this.presentToast(orderMsg);
                        this.router.navigateByUrl("/tabs/myProfile");
                        return [2 /*return*/];
                }
            });
        });
    };
    CheckoutPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"] },
        { type: src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_8__["StorageService"] },
        { type: src_app_services_order_service__WEBPACK_IMPORTED_MODULE_5__["OrderService"] }
    ]; };
    CheckoutPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-checkout',
            template: __webpack_require__(/*! raw-loader!./checkout.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/order/checkout/checkout.page.html"),
            styles: [__webpack_require__(/*! ./checkout.page.scss */ "./src/app/pages/order/checkout/checkout.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"],
            _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"],
            src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_8__["StorageService"],
            src_app_services_order_service__WEBPACK_IMPORTED_MODULE_5__["OrderService"]])
    ], CheckoutPage);
    return CheckoutPage;
}());



/***/ })

}]);
//# sourceMappingURL=order-checkout-checkout-module-es5.js.map