(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["product-details-product-details-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/product-details/product-details.page.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/product-details/product-details.page.html ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>product-details</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <!-- <ion-grid>\n        <ion-row>\n            <ion-slides pager=\"true\" [options]=\"slideOpts\">\n                <ion-slide>\n                  <img src=\"http://theflyingbasket.com/assets/productimages/{{product.id}}/{{product.productImage1}}\" alt=\"First slide\">\n                </ion-slide>\n                <ion-slide>\n                  <img src=\"http://theflyingbasket.com/assets/productimages/{{product.id}}/{{product.productImage2}}\" alt=\"Second slide\">\n                </ion-slide>\n                <ion-slide>\n                  <img src=\"http://theflyingbasket.com/assets/productimages/{{product.id}}/{{product.productImage3}}\" alt=\"Third slide\">\n                </ion-slide>\n              </ion-slides>\n        </ion-row>\n        <ion-row class=\"ion-text-center\">\n            <span class=\"productPrice\" style=\"text-decoration: line-through;\">Rs.\n              {{product.productPriceBeforeDiscount}}</span>\n          </ion-row>\n          <ion-row *ngIf=\"productVarieties.length != 0; else priceActual\">\n            <mat-label style=\"padding-top: 2px;\">Choose Quantity</mat-label>\n            <mat-form-field>\n            <mat-label>Choose Quantity</mat-label> \n              <select matNativeControl required>\n                <option *ngFor=\"let productVariety of productVarieties\" value=\"productVariety.id\">\n                  {{productVariety.productQuantity}} {{productVariety.quantityType}} - Rs. {{productVariety.productPrice}}/-\n                </option>\n              </select>\n            </mat-form-field>\n          </ion-row>\n          <ng-template #priceActual>\n            <ion-row class=\"ion-text-center\">\n              Rs. {{product.productPrice}}/-\n            </ion-row>\n          </ng-template>\n          <ion-row *ngIf=\"globalVariable.myCart.getQuantity(product) == 0; else inCart\">\n            <ion-button (click)=\"addToBasket()\">Add to basket <ion-icon name=\"basket\"></ion-icon>\n            </ion-button>\n          </ion-row>\n          <ng-template #inCart>\n            <ion-row>\n              <ion-button (click)=\"changeQuantity(-1)\" color=\"warning\"><ion-text color=\"dark\">-</ion-text></ion-button>\n              <ion-text>{{globalVariable.myCart.getQuantity(product)}} in &nbsp;<ion-icon name=\"basket\"></ion-icon></ion-text>\n              <ion-button (click)=\"changeQuantity(1)\" color=\"secondary\"><ion-text color=\"dark\">+</ion-text></ion-button>\n            </ion-row>\n          </ng-template>\n            <ion-row>\n                <b>Description:</b>\n                <div [innerHTML]=\"product.productDescription\"></div>\n            </ion-row>\n      </ion-grid> -->\n\n      <ion-card>\n        <ion-item>\n          <ion-slides pager=\"true\" [options]=\"slideOpts\">\n            <ion-slide>\n              <img src=\"http://theflyingbasket.com/assets/productimages/{{product.id}}/{{product.productImage1}}\" alt=\"First slide\">\n            </ion-slide>\n            <ion-slide>\n              <img src=\"http://theflyingbasket.com/assets/productimages/{{product.id}}/{{product.productImage2}}\" alt=\"Second slide\">\n            </ion-slide>\n            <ion-slide>\n              <img src=\"http://theflyingbasket.com/assets/productimages/{{product.id}}/{{product.productImage3}}\" alt=\"Third slide\">\n            </ion-slide>\n          </ion-slides>\n        </ion-item>\n      \n        <ion-item>\n          <span class=\"productPrice\" style=\"text-decoration: line-through;\">Rs.\n            {{product.productPriceBeforeDiscount}}</span>\n        </ion-item>\n      \n        <ion-item class=\"activated\">\n          <ion-row *ngIf=\"productVarieties.length != 0; else priceActual\">\n            <mat-label style=\"padding-top: 2px;\">Choose Quantity</mat-label>\n            <mat-form-field>\n              <!-- <mat-label>Choose Quantity</mat-label> -->\n              <select matNativeControl required>\n                <option *ngFor=\"let productVariety of productVarieties\" value=\"productVariety.id\">\n                  {{productVariety.productQuantity}} {{productVariety.quantityType}} - Rs. {{productVariety.productPrice}}/-\n                </option>\n              </select>\n            </mat-form-field>\n          </ion-row>\n          <ng-template #priceActual>\n            <ion-row class=\"ion-text-center\">\n              Rs. {{product.productPrice}}/-\n            </ion-row>\n          </ng-template>\n          <ion-row *ngIf=\"globalVariable.myCart.getQuantity(product) == 0; else inCart\">\n            <ion-button (click)=\"addToBasket()\">Add to basket <ion-icon name=\"basket\"></ion-icon>\n            </ion-button>\n          </ion-row>\n          <ng-template #inCart>\n              <ion-button (click)=\"changeQuantity(-1)\" color=\"warning\"><ion-text color=\"dark\">-</ion-text></ion-button>\n              <ion-text>{{globalVariable.myCart.getQuantity(product)}} in &nbsp;<ion-icon name=\"basket\"></ion-icon></ion-text>\n              <ion-button (click)=\"changeQuantity(1)\" color=\"secondary\"><ion-text color=\"dark\">+</ion-text></ion-button>\n          </ng-template>\n        </ion-item>\n      \n        <ion-item>\n          <ion-row>\n            <b>Description:</b>\n            <div [innerHTML]=\"product.productDescription\"></div>\n          </ion-row>\n        </ion-item>\n        <ion-item>\n          <ion-title>People also bought:</ion-title>\n        </ion-item>\n      <ion-item>\n        <div class=\"otherProduct\">\n          <ng-container *ngFor=\"let product of items\">\n            <div class=\"product-card\">\n              <app-product-card [product]=\"product\">\n              </app-product-card>\n            </div>\n          </ng-container>\n        </div>\n      </ion-item>\n      </ion-card>\n      <!-- <ion-item>\n        <ion-virtual-scroll [items]=\"items\">\n          <ion-item *virtualItem=\"let item\">\n            <app-product-card [product]=\"item\">\n            </app-product-card>\n          </ion-item>\n        </ion-virtual-scroll>\n      </ion-item> -->\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/product-details/product-details-routing.module.ts":
/*!*************************************************************************!*\
  !*** ./src/app/pages/product-details/product-details-routing.module.ts ***!
  \*************************************************************************/
/*! exports provided: ProductDetailsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductDetailsPageRoutingModule", function() { return ProductDetailsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _product_details_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./product-details.page */ "./src/app/pages/product-details/product-details.page.ts");




var routes = [
    {
        path: '',
        component: _product_details_page__WEBPACK_IMPORTED_MODULE_3__["ProductDetailsPage"]
    }
];
var ProductDetailsPageRoutingModule = /** @class */ (function () {
    function ProductDetailsPageRoutingModule() {
    }
    ProductDetailsPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], ProductDetailsPageRoutingModule);
    return ProductDetailsPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/pages/product-details/product-details.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/pages/product-details/product-details.module.ts ***!
  \*****************************************************************/
/*! exports provided: ProductDetailsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductDetailsPageModule", function() { return ProductDetailsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _product_details_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./product-details-routing.module */ "./src/app/pages/product-details/product-details-routing.module.ts");
/* harmony import */ var _product_details_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./product-details.page */ "./src/app/pages/product-details/product-details.page.ts");
/* harmony import */ var src_app_components_product_card_product_card_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/components/product-card/product-card.module */ "./src/app/components/product-card/product-card.module.ts");
/* harmony import */ var _products_products_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../products/products.module */ "./src/app/pages/products/products.module.ts");









var ProductDetailsPageModule = /** @class */ (function () {
    function ProductDetailsPageModule() {
    }
    ProductDetailsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _product_details_routing_module__WEBPACK_IMPORTED_MODULE_5__["ProductDetailsPageRoutingModule"],
                src_app_components_product_card_product_card_module__WEBPACK_IMPORTED_MODULE_7__["ProductCardModule"],
                _products_products_module__WEBPACK_IMPORTED_MODULE_8__["ProductsPageModule"]
            ],
            declarations: [_product_details_page__WEBPACK_IMPORTED_MODULE_6__["ProductDetailsPage"]],
            exports: [
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                src_app_components_product_card_product_card_module__WEBPACK_IMPORTED_MODULE_7__["ProductCardModule"]
            ]
        })
    ], ProductDetailsPageModule);
    return ProductDetailsPageModule;
}());



/***/ }),

/***/ "./src/app/pages/product-details/product-details.page.scss":
/*!*****************************************************************!*\
  !*** ./src/app/pages/product-details/product-details.page.scss ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".otherProduct {\n  overflow-x: scroll;\n  overflow-y: hidden;\n  white-space: nowrap;\n  -webkit-overflow-scrolling: touch;\n}\n\n.product-card {\n  margin-right: 10px;\n  display: inline-block;\n}\n\n.otherProduct ::-webkit-scrollbar {\n  display: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9hcHBsZS9EZXNrdG9wL1Nob3BwaW5nL3RmYiB2Mi4wL3RoZWZseWluZ2Jhc2tldC9zcmMvYXBwL3BhZ2VzL3Byb2R1Y3QtZGV0YWlscy9wcm9kdWN0LWRldGFpbHMucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9wcm9kdWN0LWRldGFpbHMvcHJvZHVjdC1kZXRhaWxzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGlDQUFBO0FDQ0o7O0FEQ0U7RUFDRSxrQkFBQTtFQUNBLHFCQUFBO0FDRUo7O0FEQ0U7RUFDRSxhQUFBO0FDRUoiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9wcm9kdWN0LWRldGFpbHMvcHJvZHVjdC1kZXRhaWxzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5vdGhlclByb2R1Y3Qge1xuICAgIG92ZXJmbG93LXg6IHNjcm9sbDtcbiAgICBvdmVyZmxvdy15OiBoaWRkZW47XG4gICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgICAtd2Via2l0LW92ZXJmbG93LXNjcm9sbGluZzogdG91Y2g7XG4gIH1cbiAgLnByb2R1Y3QtY2FyZCB7XG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgfVxuICBcbiAgLm90aGVyUHJvZHVjdCA6Oi13ZWJraXQtc2Nyb2xsYmFyIHtcbiAgICBkaXNwbGF5OiBub25lO1xuICB9IiwiLm90aGVyUHJvZHVjdCB7XG4gIG92ZXJmbG93LXg6IHNjcm9sbDtcbiAgb3ZlcmZsb3cteTogaGlkZGVuO1xuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICAtd2Via2l0LW92ZXJmbG93LXNjcm9sbGluZzogdG91Y2g7XG59XG5cbi5wcm9kdWN0LWNhcmQge1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbn1cblxuLm90aGVyUHJvZHVjdCA6Oi13ZWJraXQtc2Nyb2xsYmFyIHtcbiAgZGlzcGxheTogbm9uZTtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/pages/product-details/product-details.page.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/product-details/product-details.page.ts ***!
  \***************************************************************/
/*! exports provided: ProductDetailsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductDetailsPage", function() { return ProductDetailsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_shopping_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/shopping.service */ "./src/app/services/shopping.service.ts");
/* harmony import */ var src_app_services_cart_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/cart.service */ "./src/app/services/cart.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_app_global__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/global */ "./src/app/global.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");








var ProductDetailsPage = /** @class */ (function () {
    function ProductDetailsPage(shoppingService, toastController, route, cart) {
        this.shoppingService = shoppingService;
        this.toastController = toastController;
        this.route = route;
        this.cart = cart;
        this.slideOpts = {
            initialSlide: 0,
            speed: 400
        };
        this.items = [
            {
                id: 0,
                category: 0,
                subCategory: 0,
                productName: '',
                productCompany: '',
                productPrice: 0,
                productPriceBeforeDiscount: 0,
                productDescription: '',
                productImage1: '',
                productImage2: '',
                productImage3: '',
                shippingCharge: 0,
                productAvailability: '',
                postingDate: new Date(),
                updationDate: new Date(),
                priceVarietyAvailable: false
            }
        ];
        this.product = {
            id: 0,
            category: 0,
            subCategory: 0,
            productName: '',
            productCompany: '',
            productPrice: 0,
            productPriceBeforeDiscount: 0,
            productDescription: '',
            productImage1: '',
            productImage2: '',
            productImage3: '',
            shippingCharge: 0,
            productAvailability: '',
            postingDate: new Date(),
            updationDate: new Date(),
            priceVarietyAvailable: false
        };
        this.globalVariable = src_app_global__WEBPACK_IMPORTED_MODULE_6__["Global"];
        this.productVarieties = [];
        this.quantityForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormGroup"]({
            quantity: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('', [
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required
            ])
        });
    }
    ProductDetailsPage.prototype.presentToast = function (toastMessage) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var toast;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastController.create({
                            message: toastMessage,
                            duration: 2000
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    ProductDetailsPage.prototype.ngOnInit = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.route.queryParams.subscribe(function (queryParams) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                            var pId, _a;
                            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_b) {
                                switch (_b.label) {
                                    case 0:
                                        pId = Number(queryParams['thisId']);
                                        _a = this;
                                        return [4 /*yield*/, this.shoppingService.getProductByProductId(pId)];
                                    case 1:
                                        _a.product = _b.sent();
                                        console.log(this.product);
                                        return [4 /*yield*/, this.getProductVariety()];
                                    case 2:
                                        _b.sent();
                                        return [4 /*yield*/, this.peopleAlsoBought()];
                                    case 3:
                                        _b.sent();
                                        return [2 /*return*/];
                                }
                            });
                        }); })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    ProductDetailsPage.prototype.getProductVariety = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _a;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_b) {
                switch (_b.label) {
                    case 0:
                        _a = this;
                        return [4 /*yield*/, this.shoppingService.getProductVarietyByProductId(this.product.id)];
                    case 1:
                        _a.productVarieties = _b.sent();
                        console.log(this.productVarieties);
                        return [2 /*return*/];
                }
            });
        });
    };
    ProductDetailsPage.prototype.peopleAlsoBought = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _a, e_1;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_b) {
                switch (_b.label) {
                    case 0:
                        _b.trys.push([0, 2, , 3]);
                        _a = this;
                        return [4 /*yield*/, this.shoppingService.peopleAlsoBought(this.product.category)];
                    case 1:
                        _a.items = _b.sent();
                        return [3 /*break*/, 3];
                    case 2:
                        e_1 = _b.sent();
                        console.log(e_1);
                        return [3 /*break*/, 3];
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    ProductDetailsPage.prototype.addToBasket = function () {
        // this.cartItem.product = this.product;
        // this.cartItem.productVariety = this.quantityForm.quantity;
        // this.cartItem.quantity = 1;
        // // if (this.cartItem.productVariety == null) {
        // //   // toast message
        // //   console.log('Please choose quantity for the item.');
        // // } else {
        // this.cart.addToCart(this.cartItem);
        // // }
    };
    ProductDetailsPage.ctorParameters = function () { return [
        { type: src_app_services_shopping_service__WEBPACK_IMPORTED_MODULE_2__["ShoppingService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ToastController"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
        { type: src_app_services_cart_service__WEBPACK_IMPORTED_MODULE_3__["CartService"] }
    ]; };
    ProductDetailsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-product-details',
            template: __webpack_require__(/*! raw-loader!./product-details.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/product-details/product-details.page.html"),
            styles: [__webpack_require__(/*! ./product-details.page.scss */ "./src/app/pages/product-details/product-details.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_shopping_service__WEBPACK_IMPORTED_MODULE_2__["ShoppingService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ToastController"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"],
            src_app_services_cart_service__WEBPACK_IMPORTED_MODULE_3__["CartService"]])
    ], ProductDetailsPage);
    return ProductDetailsPage;
}());



/***/ })

}]);
//# sourceMappingURL=product-details-product-details-module-es5.js.map