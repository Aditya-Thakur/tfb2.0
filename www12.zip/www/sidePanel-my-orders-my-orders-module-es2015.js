(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["sidePanel-my-orders-my-orders-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/sidePanel/my-orders/my-orders.page.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/sidePanel/my-orders/my-orders.page.html ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>MyOrders</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-header>\n    <ion-button expand=\"full\" color=\"secondary\">Your Orders:</ion-button>\n</ion-header>\n\n<ion-grid>\n  <ion-grid *ngFor = \"let order of myOrders\">\n    <ion-row *ngFor=\"let cartItem of order.cart.myCartItems\">\n        <app-product-card-order-item [cartItem]=\"cartItem\">\n          </app-product-card-order-item>\n    </ion-row>\n    <ion-button expand=\"full\" color=\"primary\">Older Orders:</ion-button>\n  </ion-grid>\n</ion-grid>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/sidePanel/my-orders/my-orders-routing.module.ts":
/*!***********************************************************************!*\
  !*** ./src/app/pages/sidePanel/my-orders/my-orders-routing.module.ts ***!
  \***********************************************************************/
/*! exports provided: MyOrdersPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyOrdersPageRoutingModule", function() { return MyOrdersPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _my_orders_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./my-orders.page */ "./src/app/pages/sidePanel/my-orders/my-orders.page.ts");




const routes = [
    {
        path: '',
        component: _my_orders_page__WEBPACK_IMPORTED_MODULE_3__["MyOrdersPage"]
    }
];
let MyOrdersPageRoutingModule = class MyOrdersPageRoutingModule {
};
MyOrdersPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], MyOrdersPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/sidePanel/my-orders/my-orders.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/sidePanel/my-orders/my-orders.module.ts ***!
  \***************************************************************/
/*! exports provided: MyOrdersPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyOrdersPageModule", function() { return MyOrdersPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _my_orders_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./my-orders-routing.module */ "./src/app/pages/sidePanel/my-orders/my-orders-routing.module.ts");
/* harmony import */ var _my_orders_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./my-orders.page */ "./src/app/pages/sidePanel/my-orders/my-orders.page.ts");







let MyOrdersPageModule = class MyOrdersPageModule {
};
MyOrdersPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _my_orders_routing_module__WEBPACK_IMPORTED_MODULE_5__["MyOrdersPageRoutingModule"]
        ],
        declarations: [_my_orders_page__WEBPACK_IMPORTED_MODULE_6__["MyOrdersPage"]]
    })
], MyOrdersPageModule);



/***/ }),

/***/ "./src/app/pages/sidePanel/my-orders/my-orders.page.scss":
/*!***************************************************************!*\
  !*** ./src/app/pages/sidePanel/my-orders/my-orders.page.scss ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3NpZGVQYW5lbC9teS1vcmRlcnMvbXktb3JkZXJzLnBhZ2Uuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/sidePanel/my-orders/my-orders.page.ts":
/*!*************************************************************!*\
  !*** ./src/app/pages/sidePanel/my-orders/my-orders.page.ts ***!
  \*************************************************************/
/*! exports provided: MyOrdersPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyOrdersPage", function() { return MyOrdersPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_app_services_order_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/order.service */ "./src/app/services/order.service.ts");
/* harmony import */ var src_app_global__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/global */ "./src/app/global.ts");




let MyOrdersPage = class MyOrdersPage {
    constructor(orderService) {
        this.orderService = orderService;
        this.myOrders = [];
        this.globalVariable = src_app_global__WEBPACK_IMPORTED_MODULE_3__["Global"];
        this.showOrders = false;
    }
    ngOnInit() {
        console.log('bla bla in my-orders');
        this.getOrderByUserId();
    }
    getOrderByUserId() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            // this.myOrders = null;
            this.showOrders = false;
            if (this.globalVariable.loggedIn) {
                console.log('here ' + this.globalVariable.loggedInUser.id);
                this.myOrders = yield this.orderService.getOrderByUserId(4);
                console.log(this.myOrders);
                if (this.myOrders.length > 0) {
                    this.showOrders = true;
                }
                else {
                    this.error = 'Something bad happened in getOrderByUserId';
                }
            }
        });
    }
};
MyOrdersPage.ctorParameters = () => [
    { type: src_app_services_order_service__WEBPACK_IMPORTED_MODULE_2__["OrderService"] }
];
MyOrdersPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-my-orders',
        template: __webpack_require__(/*! raw-loader!./my-orders.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/sidePanel/my-orders/my-orders.page.html"),
        styles: [__webpack_require__(/*! ./my-orders.page.scss */ "./src/app/pages/sidePanel/my-orders/my-orders.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_order_service__WEBPACK_IMPORTED_MODULE_2__["OrderService"]])
], MyOrdersPage);



/***/ })

}]);
//# sourceMappingURL=sidePanel-my-orders-my-orders-module-es2015.js.map